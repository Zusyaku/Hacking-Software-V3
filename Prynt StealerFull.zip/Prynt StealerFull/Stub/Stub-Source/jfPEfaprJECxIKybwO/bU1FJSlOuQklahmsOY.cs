using System.Runtime.CompilerServices;

namespace jfPEfaprJECxIKybwO;

internal class bU1FJSlOuQklahmsOY
{
	private static bool XA1xrD3g5u;

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void xWjn6pazmLWZg()
	{
	}//Discarded unreachable code: IL_0002
	//IL_0003: Incompatible stack heights: 0 vs 1


	[MethodImpl(MethodImplOptions.NoInlining)]
	public bU1FJSlOuQklahmsOY()
	{
		//Discarded unreachable code: IL_0002, IL_0006
		//IL_0003: Incompatible stack heights: 0 vs 1
		//IL_0007: Incompatible stack heights: 0 vs 1
		T4CluWcSwrtApHR3AXB(this);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void T4CluWcSwrtApHR3AXB(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		P_0._002Ector();
	}
}
