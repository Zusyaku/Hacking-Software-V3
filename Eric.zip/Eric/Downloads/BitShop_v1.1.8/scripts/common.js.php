<script src="scripts/jquery.min.js"></script>
<script src="scripts/plugins.js"></script>
<script src="scripts/bootstrap.min.js"></script>
<script src="scripts/general.lib.js"></script>
<script src="scripts/base64.lib.js"></script>
<script src="scripts/ajax.lib.js"></script>
<script src="scripts/CryptoJS/sha256.js"></script>
<?php if (admin_valid(false,false)) { ?>
<script src="scripts/tinymce/tinymce.min.js"></script>
<script src="scripts/rsa/prng4.js"></script>
<script src="scripts/rsa/rng.js"></script>
<script src="scripts/rsa/rsa.js"></script>
<script src="scripts/rsa/rsa2.js"></script>
<script src="scripts/rsa/base64.js"></script>
<script src="scripts/rsa/jsbn.js"></script>
<script src="scripts/rsa/jsbn2.js"></script>
<?php } ?>