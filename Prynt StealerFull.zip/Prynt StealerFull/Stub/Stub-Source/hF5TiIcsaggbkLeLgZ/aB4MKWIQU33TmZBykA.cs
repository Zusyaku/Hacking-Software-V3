using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using jfPEfaprJECxIKybwO;

namespace hF5TiIcsaggbkLeLgZ;

internal class aB4MKWIQU33TmZBykA
{
	internal delegate void hlA3LjPgHjksCflcjg(object o);

	internal static object rkAr1F5Ti;

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void nrOn6paa1j5ru(int typemdt)
	{
		//Discarded unreachable code: IL_0002, IL_009e
		//IL_0003: Incompatible stack heights: 0 vs 1
		_ = 0;
		int num = ((!Qr5WttcGNYdtWJhRb9s()) ? 1 : 3);
		int num2 = default(int);
		FieldInfo[] fields = default(FieldInfo[]);
		FieldInfo fieldInfo = default(FieldInfo);
		Type type = default(Type);
		MethodInfo methodInfo = default(MethodInfo);
		while (true)
		{
			switch (num)
			{
			case 5:
			case 8:
				if (num2 >= fields.Length)
				{
					num = 10;
					break;
				}
				fieldInfo = fields[num2];
				goto case 1;
			case 7:
				num2++;
				num = 5;
				if (true)
				{
					break;
				}
				goto case 9;
			case 9:
				LCGDy0cOj6IZkdjkoi1(fieldInfo, null, (MulticastDelegate)sclidVckU1x3G9rebUk(type, methodInfo));
				num = 7;
				break;
			case 6:
				fields = type.GetFields();
				num = 2;
				break;
			case 2:
				num2 = 0;
				num = 8;
				if (true)
				{
					break;
				}
				goto case 1;
			case 1:
			case 4:
				methodInfo = (MethodInfo)t8NRtJcv0DUGa8JX3Z3(rkAr1F5Ti, XKKtfacW1IDgYogsLOI(fieldInfo) + 100663296);
				goto case 9;
			default:
				num = 9;
				break;
			case 0:
			case 3:
				type = zkoW5EchIkdoP0KD1sv(rkAr1F5Ti, 33554432 + typemdt);
				num = 6;
				break;
			case 10:
				return;
			}
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public aB4MKWIQU33TmZBykA()
	{
		//Discarded unreachable code: IL_0002, IL_0006
		//IL_0003: Incompatible stack heights: 0 vs 1
		//IL_0007: Incompatible stack heights: 0 vs 1
		PAVAvscyiXFM8n6Ny7X();
		Syau1ccqk9or2LKyHwi(this);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	static aB4MKWIQU33TmZBykA()
	{
		//Discarded unreachable code: IL_0002, IL_0006
		//IL_0003: Incompatible stack heights: 0 vs 1
		//IL_0007: Incompatible stack heights: 0 vs 1
		PAVAvscyiXFM8n6Ny7X();
		rkAr1F5Ti = XFWrgRcueeHbsjBEhTv(zDOT3YcYbZb5Jv2R4L6(typeof(aB4MKWIQU33TmZBykA).TypeHandle).Assembly);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static Type zkoW5EchIkdoP0KD1sv(object P_0, int P_1)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return ((Module)P_0).ResolveType(P_1);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static int XKKtfacW1IDgYogsLOI(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return ((MemberInfo)P_0).MetadataToken;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object t8NRtJcv0DUGa8JX3Z3(object P_0, int P_1)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return ((Module)P_0).ResolveMethod(P_1);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object sclidVckU1x3G9rebUk(Type P_0, object P_1)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return Delegate.CreateDelegate(P_0, (MethodInfo)P_1);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void LCGDy0cOj6IZkdjkoi1(object P_0, object P_1, object P_2)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		((FieldInfo)P_0).SetValue(P_1, P_2);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static bool Qr5WttcGNYdtWJhRb9s()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return true;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static bool Gtu8GJcpHi0uPk7nqwA()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return false;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void PAVAvscyiXFM8n6Ny7X()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		bU1FJSlOuQklahmsOY.xWjn6pazmLWZg();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void Syau1ccqk9or2LKyHwi(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		P_0._002Ector();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static Type zDOT3YcYbZb5Jv2R4L6(RuntimeTypeHandle P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return Type.GetTypeFromHandle(P_0);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object XFWrgRcueeHbsjBEhTv(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return ((Assembly)P_0).ManifestModule;
	}
}
