namespace PEGASUS
{
	public static class NgrokSettings
	{
		public static string token = "";

		public static string port = "";

		public static string proto = "";
	}
}
