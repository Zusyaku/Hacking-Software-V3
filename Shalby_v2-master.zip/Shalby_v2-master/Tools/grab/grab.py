import os
def priv8():
    print("Thanks for \"Ka1tx\" For your help")
    print("This Tool Not Avalible!")
    input("press enter to continue\n")
    os.system(".\.\main.py")
priv8()