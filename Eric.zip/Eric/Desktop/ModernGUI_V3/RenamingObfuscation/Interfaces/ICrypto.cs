﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModernGUI_V3.RenamingObfuscation.Interfaces
{
    public interface ICrypto
    {
        string Encrypt(string dataPlain);
    }
}
