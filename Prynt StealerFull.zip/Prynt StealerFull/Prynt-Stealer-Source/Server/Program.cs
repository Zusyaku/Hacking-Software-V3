using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using Server.Forms;
using Server.Properties;

namespace Server;

internal static class Program
{
	public static Login active;

	public static Form1 form1;

	[STAThread]
	private static void Main()
	{
		
		Application.EnableVisualStyles();
		Application.SetCompatibleTextRenderingDefault(defaultValue: false);
		
		/*
		try
		{
			string path = Path.Combine(Application.StartupPath, "Fixer.bat");
			if (!File.Exists(path))
			{
				File.WriteAllText(path, Resources.Fixer);
			}
		}
		catch
		{
		}
		*/
		form1 = new Form1();
		//Process.Start(Path.Combine(Application.StartupPath, "Stub", "Prynt.exe"));
		Application.Run(form1);
	}
}
