
 ===============================================

  Readme 

  1. WindowsActivator.exe Run the program as administrator or it will not work.

  2. That's it!!

 ===============================================