using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: ComVisible(false)]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCopyright("Copyright ©  2021")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: Guid("2949c256-c1c7-4d3d-a18a-9a89713d3e02")]
[assembly: AssemblyProduct("Prynt")]
[assembly: AssemblyTitle("Prynt")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyVersion("1.0.0.0")]
