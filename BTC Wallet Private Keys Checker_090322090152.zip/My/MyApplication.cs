using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;

namespace PV_Key_Scraper_and_Checker.My
{
	[EditorBrowsable(EditorBrowsableState.Never)]
	[GeneratedCode("MyTemplate", "11.0.0.0")]
	internal class MyApplication : ConsoleApplicationBase
	{
		public MyApplication()
		{
		}
	}
}