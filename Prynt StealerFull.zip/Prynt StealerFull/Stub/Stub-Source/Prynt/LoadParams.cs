using System.Runtime.CompilerServices;
using jfPEfaprJECxIKybwO;

namespace Prynt;

public sealed class LoadParams
{
	[CompilerGenerated]
	private byte[] yWtcWZ5ZR;

	[CompilerGenerated]
	private string CZsPB4MKW;

	public byte[] Body
	{
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		get
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			return yWtcWZ5ZR;
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		internal set
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			yWtcWZ5ZR = value;
		}
	}

	public string AppPath
	{
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		get
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			return CZsPB4MKW;
		}
		[MethodImpl(MethodImplOptions.NoInlining)]
		[CompilerGenerated]
		internal set
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			CZsPB4MKW = value;
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static LoadParams Create(byte[] SystemDataCommonIntStorageg, string ApplicationPath)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		LoadParams loadParams = new LoadParams();
		ikjK2BBJuw07VhTXGc(loadParams, ApplicationPath);
		pf4JXHI1dpOeq6MteD(loadParams, SystemDataCommonIntStorageg);
		return loadParams;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public LoadParams()
	{
		//Discarded unreachable code: IL_0002, IL_0006
		//IL_0003: Incompatible stack heights: 0 vs 1
		//IL_0007: Incompatible stack heights: 0 vs 1
		Xs01wXDVTiWe3Od8EL();
		VZiftXsvGCCRkTuFtH(this);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static bool BBMA0uolLMaPSOtpRx()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return true;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static bool pDkeRBxg2bPLGsypBP()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return false;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void ikjK2BBJuw07VhTXGc(object P_0, object P_1)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		((LoadParams)P_0).AppPath = (string)P_1;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void pf4JXHI1dpOeq6MteD(object P_0, object P_1)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		((LoadParams)P_0).Body = (byte[])P_1;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void Xs01wXDVTiWe3Od8EL()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		bU1FJSlOuQklahmsOY.xWjn6pazmLWZg();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void VZiftXsvGCCRkTuFtH(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		P_0._002Ector();
	}
}
