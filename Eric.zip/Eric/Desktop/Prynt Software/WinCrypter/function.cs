﻿using System.Diagnostics;

namespace WinCrypter
{
    public static class function
    {
        public static void GenShell(string args)
        {
            ProcessStartInfo processStart = new ProcessStartInfo()
            {
                FileName = "cmd.exe",
                Arguments = "/C " + args,
                WindowStyle = ProcessWindowStyle.Hidden,
                CreateNoWindow = true,
                UseShellExecute = false
            };
            Process.Start(processStart);
        }
    }
}