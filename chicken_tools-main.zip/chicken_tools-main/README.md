<p align="center">
    <img src="https://img.shields.io/static/v1?logo=linux&label=Language&message=bash&color=yellow">
     <img src="https://img.shields.io/static/v1?logo=json&label=Author&message=Polygon&color=green"><br>
     <img src="https://img.shields.io/static/v1?logo=github&label=maintance&message=yes&color=yellow">
      <img src="https://img.shields.io/static/v1?logo=apache&label=open%20source&message=yes&color=yellow"><br>
       <img src="https://img.shields.io/static/v1?logo=java&label=made&message=indonesia&color=gray">

</p>

## how to install
```bash
apt update
apt full-upgrade
apt install ncurses-utils lynx curl
apt install toilet figlet git tor
git clone https://github.com/Bayu12345677/chicken_tools
make setup
make run
```

## to update
```makefile
make update
cd .
```
--------------------------

`depencies`<br>

`IO.FUNC`
`IO.SYSTEM.var`
`IO.TYPE`
`IO.ECHO`
`colorama`
`urlparser`
`HTTP.UA`
`IO.SYSTEM.log`

----------------------------

## update
> feature<br>
```bash
$ new menu web views bot
```
------------------------------


- [![](https://img.shields.io/static/v1?logo=youtube&label=subscribe&message=my%20youtube&color=green)](https://youtube.com/channel/UCtu-GcxKL8kJBXpR1wfMgWg)
