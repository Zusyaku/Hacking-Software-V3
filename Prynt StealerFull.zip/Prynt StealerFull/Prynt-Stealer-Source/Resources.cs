// Server.Forms.Form1.resources (Embedded, Public)


// Server.Forms.Form2.resources (Embedded, Public)


// Server.Forms.FormAbout.resources (Embedded, Public)


// Server.Forms.FormBlockClients.resources (Embedded, Public)


// Server.Forms.FormBuilder.resources (Embedded, Public)


// Server.Forms.FormCertificate.resources (Embedded, Public)


// Server.Forms.FormChat.resources (Embedded, Public)


// Server.Forms.FormDOS.resources (Embedded, Public)


// Server.Forms.FormDotNetEditor.resources (Embedded, Public)

// Server.Forms.FormDownloadFile.resources (Embedded, Public)


// Server.Forms.FormFileManager.resources (Embedded, Public)


// Server.Forms.FormFileSearcher.resources (Embedded, Public)


// Server.Forms.FormKeylogger.resources (Embedded, Public)


// Server.Forms.FormMiner.resources (Embedded, Public)


// Server.Forms.FormPassword.resources (Embedded, Public)


// Server.Forms.FormPorts.resources (Embedded, Public)


// Server.Forms.FormProcessManager.resources (Embedded, Public)


// Server.Forms.FormRemoteDesktop.resources (Embedded, Public)


// Server.Forms.FormSendFileToMemory.resources (Embedded, Public)


// Server.Forms.FormShell.resources (Embedded, Public)


// Server.Forms.FormTorrent.resources (Embedded, Public)


// Server.Forms.FormWebcam.resources (Embedded, Public)


// Server.Forms.Login.resources (Embedded, Public)


// Server.Forms.Register.resources (Embedded, Public)


// Server.Properties.Resources.resources (Embedded, Public)




