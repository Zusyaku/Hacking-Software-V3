<?php
// enable/disable gocoin
$enable_gocoin = false;

// enable debug mode (no sandbox)
$debug_gocoin = false;

// Coinbase API setup
$gocoin_merch_id = '';
$gocoin_api_secret = '';
$gocoin_call_secret = '';
?>