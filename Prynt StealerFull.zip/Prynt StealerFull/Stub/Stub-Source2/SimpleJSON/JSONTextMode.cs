namespace SimpleJSON;

public enum JSONTextMode
{
	Compact,
	Indent
}
