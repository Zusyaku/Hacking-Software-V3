using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Server.Properties;

[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
internal class Resources
{
	private static ResourceManager resourceMan;

	private static CultureInfo resourceCulture;

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static ResourceManager ResourceManager
	{
		get
		{
			if (resourceMan == null)
			{
				resourceMan = new ResourceManager("Server.Properties.Resources", typeof(Resources).Assembly);
			}
			return resourceMan;
		}
	}

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static CultureInfo Culture
	{
		get
		{
			return resourceCulture;
		}
		set
		{
			resourceCulture = value;
		}
	}

	internal static byte[] _7z => (byte[])ResourceManager.GetObject("_7z", resourceCulture);

	internal static byte[] _7z1 => (byte[])ResourceManager.GetObject("_7z1", resourceCulture);

	internal static Bitmap arrow_down => (Bitmap)ResourceManager.GetObject("arrow_down", resourceCulture);

	internal static Bitmap arrow_up => (Bitmap)ResourceManager.GetObject("arrow_up", resourceCulture);

	internal static Bitmap blank_screen => (Bitmap)ResourceManager.GetObject("blank-screen", resourceCulture);

	internal static Bitmap botkiller => (Bitmap)ResourceManager.GetObject("botkiller", resourceCulture);

	internal static Bitmap builder => (Bitmap)ResourceManager.GetObject("builder", resourceCulture);

	internal static string builder1 => ResourceManager.GetString("builder1", resourceCulture);

	internal static string builder2 => ResourceManager.GetString("builder2", resourceCulture);

	internal static Bitmap chat => (Bitmap)ResourceManager.GetObject("chat", resourceCulture);

	internal static Bitmap client => (Bitmap)ResourceManager.GetObject("client", resourceCulture);

	internal static Bitmap coding => (Bitmap)ResourceManager.GetObject("coding", resourceCulture);

	internal static Bitmap ddos => (Bitmap)ResourceManager.GetObject("ddos", resourceCulture);

	internal static Bitmap disabled => (Bitmap)ResourceManager.GetObject("disabled", resourceCulture);

	internal static Bitmap extra => (Bitmap)ResourceManager.GetObject("extra", resourceCulture);

	internal static Bitmap filemanager => (Bitmap)ResourceManager.GetObject("filemanager", resourceCulture);

	internal static string Fixer => ResourceManager.GetString("Fixer", resourceCulture);

	internal static Bitmap iconfinder_32_171485__1_ => (Bitmap)ResourceManager.GetObject("iconfinder_32_171485 (1)", resourceCulture);

	internal static Bitmap info => (Bitmap)ResourceManager.GetObject("info", resourceCulture);

	internal static Bitmap key => (Bitmap)ResourceManager.GetObject("key", resourceCulture);

	internal static Bitmap keyboard => (Bitmap)ResourceManager.GetObject("keyboard", resourceCulture);

	internal static Bitmap keyboard_on => (Bitmap)ResourceManager.GetObject("keyboard-on", resourceCulture);

	internal static Bitmap logger => (Bitmap)ResourceManager.GetObject("logger", resourceCulture);

	internal static Bitmap Miscellaneous => (Bitmap)ResourceManager.GetObject("Miscellaneous", resourceCulture);

	internal static Bitmap monitoring_system => (Bitmap)ResourceManager.GetObject("monitoring-system", resourceCulture);

	internal static Bitmap mouse => (Bitmap)ResourceManager.GetObject("mouse", resourceCulture);

	internal static Bitmap mouse_enable => (Bitmap)ResourceManager.GetObject("mouse_enable", resourceCulture);

	internal static Bitmap msgbox => (Bitmap)ResourceManager.GetObject("msgbox", resourceCulture);

	internal static Bitmap netstat => (Bitmap)ResourceManager.GetObject("netstat", resourceCulture);

	internal static Bitmap pc => (Bitmap)ResourceManager.GetObject("pc", resourceCulture);

	internal static Bitmap play_button => (Bitmap)ResourceManager.GetObject("play-button", resourceCulture);

	internal static Bitmap process => (Bitmap)ResourceManager.GetObject("process", resourceCulture);

	internal static Bitmap remotedesktop => (Bitmap)ResourceManager.GetObject("remotedesktop", resourceCulture);

	internal static Bitmap report => (Bitmap)ResourceManager.GetObject("report", resourceCulture);

	internal static Bitmap save_image => (Bitmap)ResourceManager.GetObject("save-image", resourceCulture);

	internal static Bitmap save_image2 => (Bitmap)ResourceManager.GetObject("save-image2", resourceCulture);

	internal static string sct => ResourceManager.GetString("sct", resourceCulture);

	internal static Bitmap server => (Bitmap)ResourceManager.GetObject("server", resourceCulture);

	internal static Bitmap settings => (Bitmap)ResourceManager.GetObject("settings", resourceCulture);

	internal static Bitmap shell => (Bitmap)ResourceManager.GetObject("shell", resourceCulture);

	internal static Bitmap stop__1_ => (Bitmap)ResourceManager.GetObject("stop (1)", resourceCulture);

	internal static Bitmap system => (Bitmap)ResourceManager.GetObject("system", resourceCulture);

	internal static Bitmap tomem => (Bitmap)ResourceManager.GetObject("tomem", resourceCulture);

	internal static Bitmap tomem1 => (Bitmap)ResourceManager.GetObject("tomem1", resourceCulture);

	internal static Bitmap u_torrent_logo => (Bitmap)ResourceManager.GetObject("u-torrent-logo", resourceCulture);

	internal static Bitmap uac => (Bitmap)ResourceManager.GetObject("uac", resourceCulture);

	internal static Bitmap usb => (Bitmap)ResourceManager.GetObject("usb", resourceCulture);

	internal static Bitmap visit => (Bitmap)ResourceManager.GetObject("visit", resourceCulture);

	internal static Bitmap webcam => (Bitmap)ResourceManager.GetObject("webcam", resourceCulture);

	internal static Bitmap xmr => (Bitmap)ResourceManager.GetObject("xmr", resourceCulture);

	internal static byte[] xmrig => (byte[])ResourceManager.GetObject("xmrig", resourceCulture);

	internal Resources()
	{
	}
}
