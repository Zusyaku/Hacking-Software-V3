// Server.Forms.Login
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Server;
using Server.Forms;
using Siticone.UI.AnimatorNS;
using Siticone.UI.WinForms;

public class Login : Form
{
	private IContainer components;

	private SiticoneDragControl siticoneDragControl1;

	private SiticoneControlBox siticoneControlBox1;

	private SiticoneTransition siticoneTransition1;

	private Label label1;

	private Label label2;

	private SiticoneRoundedButton siticoneRoundedButton1;

	private SiticoneShadowForm siticoneShadowForm;

	private SiticoneRoundedButton siticoneRoundedButton2;

	private SiticoneRoundedTextBox password;

	private SiticoneRoundedTextBox username;

	private SiticoneImageButton siticoneImageButton1;

	private PictureBox pictureBox1;

	private PictureBox pictureBox2;

	public Login()
	{
		InitializeComponent();
	}

	private void siticoneRoundedButton2_Click(object sender, EventArgs e)
	{
		Hide();
		new Register().Show();
	}

	private void siticoneControlBox1_Click(object sender, EventArgs e)
	{
		Environment.Exit(0);
	}

	private void siticoneRoundedButton1_Click(object sender, EventArgs e)
	{
		if (1 == 1)
		{
			MessageBox.Show("Login successful!", "Prynt", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			Program.form1 = new Form1();
			Program.form1.Show();
			Hide();
		}
	}

	private void Login_Load(object sender, EventArgs e)
	{
	}

	private void pictureBox1_Click(object sender, EventArgs e)
	{
		if (1 == 1)
		{
			MessageBox.Show("Login successful!", "Prynt", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			Program.form1 = new Form1();
			Program.form1.Show();
			Hide();
		}
	}

	private void pictureBox2_Click(object sender, EventArgs e)
	{
		Hide();
		new Register().Show();
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.components = new System.ComponentModel.Container();
		Siticone.UI.AnimatorNS.Animation animation = new Siticone.UI.AnimatorNS.Animation();
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Server.Forms.Login));
		this.siticoneDragControl1 = new Siticone.UI.WinForms.SiticoneDragControl(this.components);
		this.siticoneControlBox1 = new Siticone.UI.WinForms.SiticoneControlBox();
		this.siticoneTransition1 = new Siticone.UI.WinForms.SiticoneTransition();
		this.label1 = new System.Windows.Forms.Label();
		this.label2 = new System.Windows.Forms.Label();
		this.siticoneRoundedButton1 = new Siticone.UI.WinForms.SiticoneRoundedButton();
		this.siticoneRoundedButton2 = new Siticone.UI.WinForms.SiticoneRoundedButton();
		this.password = new Siticone.UI.WinForms.SiticoneRoundedTextBox();
		this.username = new Siticone.UI.WinForms.SiticoneRoundedTextBox();
		this.siticoneImageButton1 = new Siticone.UI.WinForms.SiticoneImageButton();
		this.pictureBox1 = new System.Windows.Forms.PictureBox();
		this.pictureBox2 = new System.Windows.Forms.PictureBox();
		this.siticoneShadowForm = new Siticone.UI.WinForms.SiticoneShadowForm(this.components);
		((System.ComponentModel.ISupportInitialize)this.pictureBox1).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.pictureBox2).BeginInit();
		base.SuspendLayout();
		this.siticoneDragControl1.TargetControl = this;
		this.siticoneControlBox1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.siticoneControlBox1.BackColor = System.Drawing.Color.Transparent;
		this.siticoneControlBox1.BorderRadius = 10;
		this.siticoneTransition1.SetDecoration(this.siticoneControlBox1, Siticone.UI.AnimatorNS.DecorationType.None);
		this.siticoneControlBox1.FillColor = System.Drawing.Color.FromArgb(35, 39, 42);
		this.siticoneControlBox1.HoveredState.FillColor = System.Drawing.Color.FromArgb(232, 17, 35);
		this.siticoneControlBox1.HoveredState.IconColor = System.Drawing.Color.White;
		this.siticoneControlBox1.HoveredState.Parent = this.siticoneControlBox1;
		this.siticoneControlBox1.IconColor = System.Drawing.Color.White;
		this.siticoneControlBox1.Location = new System.Drawing.Point(227, 1);
		this.siticoneControlBox1.Name = "siticoneControlBox1";
		this.siticoneControlBox1.PressedColor = System.Drawing.Color.White;
		this.siticoneControlBox1.ShadowDecoration.Parent = this.siticoneControlBox1;
		this.siticoneControlBox1.Size = new System.Drawing.Size(22, 19);
		this.siticoneControlBox1.TabIndex = 1;
		this.siticoneControlBox1.Click += new System.EventHandler(siticoneControlBox1_Click);
		this.siticoneTransition1.AnimationType = Siticone.UI.AnimatorNS.AnimationType.Rotate;
		this.siticoneTransition1.Cursor = null;
		animation.AnimateOnlyDifferences = true;
		animation.BlindCoeff = (System.Drawing.PointF)resources.GetObject("animation1.BlindCoeff");
		animation.LeafCoeff = 0f;
		animation.MaxTime = 1f;
		animation.MinTime = 0f;
		animation.MosaicCoeff = (System.Drawing.PointF)resources.GetObject("animation1.MosaicCoeff");
		animation.MosaicShift = (System.Drawing.PointF)resources.GetObject("animation1.MosaicShift");
		animation.MosaicSize = 0;
		animation.Padding = new System.Windows.Forms.Padding(50);
		animation.RotateCoeff = 1f;
		animation.RotateLimit = 0f;
		animation.ScaleCoeff = (System.Drawing.PointF)resources.GetObject("animation1.ScaleCoeff");
		animation.SlideCoeff = (System.Drawing.PointF)resources.GetObject("animation1.SlideCoeff");
		animation.TimeCoeff = 0f;
		animation.TransparencyCoeff = 1f;
		this.siticoneTransition1.DefaultAnimation = animation;
		this.label1.AutoSize = true;
		this.siticoneTransition1.SetDecoration(this.label1, Siticone.UI.AnimatorNS.DecorationType.None);
		this.label1.Font = new System.Drawing.Font("Segoe UI Light", 10f);
		this.label1.ForeColor = System.Drawing.Color.White;
		this.label1.Location = new System.Drawing.Point(-1, 136);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(0, 19);
		this.label1.TabIndex = 22;
		this.label2.AutoSize = true;
		this.label2.BackColor = System.Drawing.Color.Transparent;
		this.siticoneTransition1.SetDecoration(this.label2, Siticone.UI.AnimatorNS.DecorationType.None);
		this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.label2.ForeColor = System.Drawing.Color.White;
		this.label2.Location = new System.Drawing.Point(5, 1);
		this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(82, 19);
		this.label2.TabIndex = 27;
		this.label2.Text = "Prynt Login";
		this.siticoneRoundedButton1.BorderColor = System.Drawing.Color.DodgerBlue;
		this.siticoneRoundedButton1.BorderThickness = 1;
		this.siticoneRoundedButton1.CheckedState.Parent = this.siticoneRoundedButton1;
		this.siticoneRoundedButton1.CustomImages.Parent = this.siticoneRoundedButton1;
		this.siticoneTransition1.SetDecoration(this.siticoneRoundedButton1, Siticone.UI.AnimatorNS.DecorationType.None);
		this.siticoneRoundedButton1.FillColor = System.Drawing.Color.FromArgb(35, 39, 42);
		this.siticoneRoundedButton1.Font = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.siticoneRoundedButton1.ForeColor = System.Drawing.Color.White;
		this.siticoneRoundedButton1.HoveredState.BorderColor = System.Drawing.Color.FromArgb(213, 218, 223);
		this.siticoneRoundedButton1.HoveredState.Parent = this.siticoneRoundedButton1;
		this.siticoneRoundedButton1.Location = new System.Drawing.Point(9, 276);
		this.siticoneRoundedButton1.Name = "siticoneRoundedButton1";
		this.siticoneRoundedButton1.ShadowDecoration.Parent = this.siticoneRoundedButton1;
		this.siticoneRoundedButton1.Size = new System.Drawing.Size(228, 34);
		this.siticoneRoundedButton1.TabIndex = 26;
		this.siticoneRoundedButton1.Text = "Login";
		this.siticoneRoundedButton1.Click += new System.EventHandler(siticoneRoundedButton1_Click);
		this.siticoneRoundedButton2.BorderColor = System.Drawing.Color.DodgerBlue;
		this.siticoneRoundedButton2.BorderThickness = 1;
		this.siticoneRoundedButton2.CheckedState.Parent = this.siticoneRoundedButton2;
		this.siticoneRoundedButton2.CustomImages.Parent = this.siticoneRoundedButton2;
		this.siticoneTransition1.SetDecoration(this.siticoneRoundedButton2, Siticone.UI.AnimatorNS.DecorationType.None);
		this.siticoneRoundedButton2.FillColor = System.Drawing.Color.FromArgb(35, 39, 42);
		this.siticoneRoundedButton2.Font = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.siticoneRoundedButton2.ForeColor = System.Drawing.Color.White;
		this.siticoneRoundedButton2.HoveredState.BorderColor = System.Drawing.Color.FromArgb(213, 218, 223);
		this.siticoneRoundedButton2.HoveredState.Parent = this.siticoneRoundedButton2;
		this.siticoneRoundedButton2.Location = new System.Drawing.Point(12, 316);
		this.siticoneRoundedButton2.Name = "siticoneRoundedButton2";
		this.siticoneRoundedButton2.ShadowDecoration.Parent = this.siticoneRoundedButton2;
		this.siticoneRoundedButton2.Size = new System.Drawing.Size(225, 38);
		this.siticoneRoundedButton2.TabIndex = 28;
		this.siticoneRoundedButton2.Text = "Register";
		this.siticoneRoundedButton2.Click += new System.EventHandler(siticoneRoundedButton2_Click);
		this.password.AllowDrop = true;
		this.password.BackColor = System.Drawing.Color.Transparent;
		this.password.BorderColor = System.Drawing.Color.White;
		this.password.Cursor = System.Windows.Forms.Cursors.IBeam;
		this.siticoneTransition1.SetDecoration(this.password, Siticone.UI.AnimatorNS.DecorationType.None);
		this.password.DefaultText = "";
		this.password.DisabledState.BorderColor = System.Drawing.Color.FromArgb(208, 208, 208);
		this.password.DisabledState.FillColor = System.Drawing.Color.FromArgb(226, 226, 226);
		this.password.DisabledState.ForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
		this.password.DisabledState.Parent = this.password;
		this.password.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
		this.password.FillColor = System.Drawing.Color.FromArgb(35, 39, 42);
		this.password.FocusedState.BorderColor = System.Drawing.Color.FromArgb(94, 148, 255);
		this.password.FocusedState.Parent = this.password;
		this.password.ForeColor = System.Drawing.Color.White;
		this.password.HoveredState.BorderColor = System.Drawing.Color.FromArgb(94, 148, 255);
		this.password.HoveredState.Parent = this.password;
		this.password.Location = new System.Drawing.Point(9, 236);
		this.password.Margin = new System.Windows.Forms.Padding(4);
		this.password.Name = "password";
		this.password.PasswordChar = '*';
		this.password.PlaceholderText = "Password";
		this.password.SelectedText = "";
		this.password.ShadowDecoration.Parent = this.password;
		this.password.Size = new System.Drawing.Size(228, 30);
		this.password.TabIndex = 30;
		this.password.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
		this.password.UseSystemPasswordChar = true;
		this.username.AllowDrop = true;
		this.username.BackColor = System.Drawing.Color.Transparent;
		this.username.BorderColor = System.Drawing.Color.White;
		this.username.Cursor = System.Windows.Forms.Cursors.IBeam;
		this.siticoneTransition1.SetDecoration(this.username, Siticone.UI.AnimatorNS.DecorationType.None);
		this.username.DefaultText = "";
		this.username.DisabledState.BorderColor = System.Drawing.Color.FromArgb(208, 208, 208);
		this.username.DisabledState.FillColor = System.Drawing.Color.FromArgb(226, 226, 226);
		this.username.DisabledState.ForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
		this.username.DisabledState.Parent = this.username;
		this.username.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
		this.username.FillColor = System.Drawing.Color.FromArgb(35, 39, 42);
		this.username.FocusedState.BorderColor = System.Drawing.Color.FromArgb(94, 148, 255);
		this.username.FocusedState.Parent = this.username;
		this.username.ForeColor = System.Drawing.Color.White;
		this.username.HoveredState.BorderColor = System.Drawing.Color.FromArgb(94, 148, 255);
		this.username.HoveredState.Parent = this.username;
		this.username.Location = new System.Drawing.Point(9, 198);
		this.username.Margin = new System.Windows.Forms.Padding(4);
		this.username.Name = "username";
		this.username.PasswordChar = '\0';
		this.username.PlaceholderText = "Username";
		this.username.SelectedText = "";
		this.username.ShadowDecoration.Parent = this.username;
		this.username.Size = new System.Drawing.Size(228, 30);
		this.username.TabIndex = 32;
		this.username.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
		this.siticoneImageButton1.BackColor = System.Drawing.Color.Transparent;
		this.siticoneImageButton1.BackgroundImage = (System.Drawing.Image)resources.GetObject("siticoneImageButton1.BackgroundImage");
		this.siticoneImageButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
		this.siticoneImageButton1.CheckedState.Parent = this.siticoneImageButton1;
		this.siticoneTransition1.SetDecoration(this.siticoneImageButton1, Siticone.UI.AnimatorNS.DecorationType.None);
		this.siticoneImageButton1.HoveredState.ImageSize = new System.Drawing.Size(200, 100);
		this.siticoneImageButton1.HoveredState.Parent = this.siticoneImageButton1;
		this.siticoneImageButton1.ImageSize = new System.Drawing.Size(200, 100);
		this.siticoneImageButton1.Location = new System.Drawing.Point(9, 25);
		this.siticoneImageButton1.Margin = new System.Windows.Forms.Padding(2);
		this.siticoneImageButton1.Name = "siticoneImageButton1";
		this.siticoneImageButton1.PressedState.ImageSize = new System.Drawing.Size(200, 100);
		this.siticoneImageButton1.PressedState.Parent = this.siticoneImageButton1;
		this.siticoneImageButton1.Size = new System.Drawing.Size(230, 167);
		this.siticoneImageButton1.TabIndex = 33;
		this.pictureBox1.BackgroundImage = (System.Drawing.Image)resources.GetObject("pictureBox1.BackgroundImage");
		this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
		this.siticoneTransition1.SetDecoration(this.pictureBox1, Siticone.UI.AnimatorNS.DecorationType.None);
		this.pictureBox1.Location = new System.Drawing.Point(313, 32);
		this.pictureBox1.Name = "pictureBox1";
		this.pictureBox1.Size = new System.Drawing.Size(226, 57);
		this.pictureBox1.TabIndex = 34;
		this.pictureBox1.TabStop = false;
		this.pictureBox1.Click += new System.EventHandler(pictureBox1_Click);
		this.pictureBox2.BackgroundImage = (System.Drawing.Image)resources.GetObject("pictureBox2.BackgroundImage");
		this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
		this.siticoneTransition1.SetDecoration(this.pictureBox2, Siticone.UI.AnimatorNS.DecorationType.None);
		this.pictureBox2.Location = new System.Drawing.Point(321, 95);
		this.pictureBox2.Name = "pictureBox2";
		this.pictureBox2.Size = new System.Drawing.Size(226, 55);
		this.pictureBox2.TabIndex = 40;
		this.pictureBox2.TabStop = false;
		this.pictureBox2.Click += new System.EventHandler(pictureBox2_Click);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
		this.BackColor = System.Drawing.Color.FromArgb(35, 39, 42);
		this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
		base.ClientSize = new System.Drawing.Size(250, 367);
		base.Controls.Add(this.pictureBox2);
		base.Controls.Add(this.pictureBox1);
		base.Controls.Add(this.siticoneImageButton1);
		base.Controls.Add(this.username);
		base.Controls.Add(this.password);
		base.Controls.Add(this.siticoneRoundedButton2);
		base.Controls.Add(this.label2);
		base.Controls.Add(this.siticoneRoundedButton1);
		base.Controls.Add(this.label1);
		base.Controls.Add(this.siticoneControlBox1);
		this.siticoneTransition1.SetDecoration(this, Siticone.UI.AnimatorNS.DecorationType.BottomMirror);
		this.DoubleBuffered = true;
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
		base.Name = "Login";
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Auth.GG Winform";
		base.TransparencyKey = System.Drawing.Color.Maroon;
		base.Load += new System.EventHandler(Login_Load);
		((System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
		((System.ComponentModel.ISupportInitialize)this.pictureBox2).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}
}
