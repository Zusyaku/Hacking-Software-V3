namespace Client.Modules.Passwords.Helpers;

internal struct Bookmark
{
	public string sUrl { get; set; }

	public string sTitle { get; set; }
}
