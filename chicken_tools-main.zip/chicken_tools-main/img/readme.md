
- `new menu bot views`

![](https://github.com/Bayu12345677/chicken_tools/blob/main/img/Screenshot_20220220-141423.png)
