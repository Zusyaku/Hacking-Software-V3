using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyTitle("IconExtractor")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("IconExtractor")]
[assembly: AssemblyCopyright("Copyright © J.Sakamoto 2015")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("0a4478b6-1ab6-419f-8a3b-9e404e85271a")]
[assembly: AssemblyVersion("1.0.0.0")]
