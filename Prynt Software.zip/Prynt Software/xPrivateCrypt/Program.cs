﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;

namespace PrivateCrypt
{
    static class Program
    {

        public static Form1 _MainFrm;
        public static Login _Login;

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            OnProgramStart.Initialize("privatecrypt", "135575", "UsQrbAow6kGZJcYSm4asgJtmT0ixLGXaxtJ", "1.0");
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            _Login = new Login();
            Application.Run(_Login);
        }
    }
}
