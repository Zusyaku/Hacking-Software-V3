
Spytector - the keylogger always ahead

Spytector is tracking all the activities of PC users (visited websites, all the
keystrokes, chat conversations, opened windows, applications etc.) and delivers
the logs to you via Email and FTP. In the delivered logs are also included the 
passwords stored in browsers (Google Chrome, Firefox, Edge, Opera, Vivaldi)
and URL history (visited websites).

Spytector keylogger is compatible with Windows 2k, XP, Vista, 7, 8, 10, 11 (32bit/64bit).

The trial version could be detected by your antivirus - it's somehow normal because it's
publicly available. For proper testing you should temporarily disable your AV (if there's
one running). Also, in the trial version, the keylogger shows warning messages at
every 15 minutes and the user must click YES to allow the monitoring.

Features:

 - stealth features
 - advanced firewall bypass techniques
 - the keylogger works on all account types (Guest, Administrator)
 - silent install (the keylogger bypasses Windows Defender and there is no problem
   with UAC or other regular Windows protections like DEP)
 - FTP and Email log delivery
 - option to include locally stored passwords in the log
 - chat recording
 - keylogger filter (only specific websites/windows are tracked)
 - option to restrict the access to specified websites
 - option to restrict the access to specified applications
 - clipboard monitoring
 - the logs can be received either when they reach a minimum size,
   at specified minutes interval or at specified days interval
 - option to change the keylogger icon
 - configurable keylogger name, log name, log size
 - melt option
 - warning message option
 - smart keylogger (BACKSPACE is applied)
 - clean log (CTRL, SHIFT, ALT, ESC etc. aren't included in the logs)
 - keylogger overwrite protection
 - password protection
 - delay feature (the keylogger will be active after a specified time or after boot)
 - option to uninstall the keylogger after a specific number of sent logs
 - option to uninstall the keylogger with a hotkey
 - option to uninstall the keylogger by checking HTTP
 - option to save the settings
 - GUI languages
 - local logfile retrieval function
 - good encryption for log and server settings

Website:

http://www.spytector.com

Email contacts:

Licensing:      licensing@spytector.com
Tech support:   support@spytector.com
General:        spy@spytector.com

For your convenience, you may also contact us with the instant messengers:

Skype:  spytector
ICQ:    122622
