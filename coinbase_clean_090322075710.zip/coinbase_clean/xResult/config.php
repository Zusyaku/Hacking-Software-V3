<?php
$send = "youremail.com";
?>