<div class="hero-unit compact-hero">
  <h1><?php echo LANG('WELCOME_TO').' '.safe_str($site_name); ?></h1>
  <p><?php echo LANG('TEXT_HERE', 3, ' '); ?></p>
</div>