using System;
using System.IO;

namespace TheDropper.Generators;

internal class ScriptGenerator
{
	public static string fileUrl { get; private set; }

	public static string fileName { get; private set; }

	public ScriptGenerator(string url)
	{
		Uri uri = new Uri(url);
		fileUrl = uri.AbsoluteUri;
		fileName = Path.GetFileName(uri.LocalPath);
	}

	public string Generate(string payloadContent, string outExtension)
	{
		string text = Path.Combine(Directory.GetCurrentDirectory(), "output." + outExtension);
		string contents = string.Format(payloadContent, fileName, fileUrl);
		File.WriteAllText(text, contents);
		return text;
	}
}
