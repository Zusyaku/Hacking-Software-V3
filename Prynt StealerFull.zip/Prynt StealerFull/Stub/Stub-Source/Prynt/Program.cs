using System;
using System.Runtime.CompilerServices;
using o4HuHur09QNlgH31H9;

namespace Prynt;

public static class Program
{
	[MethodImpl(MethodImplOptions.NoInlining)]
	private static void HWVxRjHWl(string[] _0020)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		Console.WriteLine(ajPWp7JpCnYwAxGgPj.g4tWycSQ4(0));
		LoadExecutor.SelfExecute();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static bool ErSj7LG072QoCnb5DE()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return true;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static bool lP3BQop5rPkhuim9Bv()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return false;
	}
}
