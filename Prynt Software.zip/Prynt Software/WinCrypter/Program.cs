﻿using System;
using System.Windows.Forms;
using System.Net;
namespace WinCrypter
{
    internal static class Program
    {
        public static MainFrm _MainFrm;
        public static Login _Login;
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        private static void Main()
        {
            ServicePointManager.Expect100Continue = true;
                   ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            OnProgramStart.Initialize("wwcrypt", "135575", "VSVxwpQvS0CVBnFDJnzyejh6DNcsNQxSUW0", "1.0");
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            _Login = new Login();
            Application.Run(_Login);
        }
    }
}