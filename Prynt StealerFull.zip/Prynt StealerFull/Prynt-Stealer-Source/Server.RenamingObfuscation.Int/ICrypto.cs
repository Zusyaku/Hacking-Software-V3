namespace Server.RenamingObfuscation.Interfaces;

public interface ICrypto
{
	string Encrypt(string dataPlain);
}
