﻿
- Disconnect the internet
- Use the keygen
- Connect to internet