using System;
using System.Collections;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using jfPEfaprJECxIKybwO;

namespace o4HuHur09QNlgH31H9;

internal class ajPWp7JpCnYwAxGgPj
{
	internal class f6km2k1IS01nF4ccyi : Attribute
	{
		internal class QfjfwyifZ5DYgArOj1<KtycSQM4UQQ0fMUYbp>
		{
			[MethodImpl(MethodImplOptions.NoInlining)]
			public QfjfwyifZ5DYgArOj1()
			{
				//Discarded unreachable code: IL_0002, IL_0006
				//IL_0003: Incompatible stack heights: 0 vs 1
				//IL_0007: Incompatible stack heights: 0 vs 1
				bU1FJSlOuQklahmsOY.xWjn6pazmLWZg();
				base._002Ector();
			}

			[MethodImpl(MethodImplOptions.NoInlining)]
			internal static bool lw9UsEcXlZwV8wU9CwS()
			{
				//Discarded unreachable code: IL_0002
				//IL_0003: Incompatible stack heights: 0 vs 1
				return true;
			}

			[MethodImpl(MethodImplOptions.NoInlining)]
			internal static bool l9BXVpcAJ4s2kuCXDLZ()
			{
				//Discarded unreachable code: IL_0002
				//IL_0003: Incompatible stack heights: 0 vs 1
				return false;
			}
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		[f6km2k1IS01nF4ccyi(typeof(QfjfwyifZ5DYgArOj1<object>[]))]
		public f6km2k1IS01nF4ccyi(object _0020)
		{
			//Discarded unreachable code: IL_0002, IL_0006
			//IL_0003: Incompatible stack heights: 0 vs 1
			//IL_0007: Incompatible stack heights: 0 vs 1
			pQlME4cfvqC2HFKR2M1();
			pAVpjHc74nmowJ5Yt23(this);
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void pQlME4cfvqC2HFKR2M1()
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			bU1FJSlOuQklahmsOY.xWjn6pazmLWZg();
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void pAVpjHc74nmowJ5Yt23(object P_0)
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			((Attribute)P_0)._002Ector();
		}
	}

	internal class kGu4owF47uYMiUIPFl
	{
		[MethodImpl(MethodImplOptions.NoInlining)]
		[f6km2k1IS01nF4ccyi(typeof(f6km2k1IS01nF4ccyi.QfjfwyifZ5DYgArOj1<object>[]))]
		internal static string dhjxcCyGUP(object _0020, object _0020)
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			byte[] array = (byte[])pKC674cFcQCi2WYC5TK(JYNCFRclY19OMUDt3e5(), _0020);
			byte[] array2 = array;
			byte[] array3 = new byte[32];
			cbDAWWcMELkjXOEsqH1(array3, (RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/);
			byte[] array4 = array3;
			byte[] array5 = (byte[])RLDPpjcCqmQIZnwTek4(pKC674cFcQCi2WYC5TK(JYNCFRclY19OMUDt3e5(), _0020));
			MemoryStream memoryStream = new MemoryStream();
			SymmetricAlgorithm symmetricAlgorithm = (SymmetricAlgorithm)rRKtyFcVispIKdqS5lF();
			NGHp1RcUt8Ff4IoOZZG(symmetricAlgorithm, array4);
			vZiFnhc5nHyYQULARB1(symmetricAlgorithm, array5);
			CryptoStream cryptoStream = new CryptoStream(memoryStream, (ICryptoTransform)tCaHd1cPlEPcW5enqai(symmetricAlgorithm), CryptoStreamMode.Write);
			sFIoR0cZOmjVuLi3g01(cryptoStream, array2, 0, array2.Length);
			vtno0bcQtaptJYJgqbw(cryptoStream);
			return (string)hMJYPGcKWMRnY8mIZT3(IRea7vc4p8HmYd09eDZ(memoryStream));
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		public kGu4owF47uYMiUIPFl()
		{
			//Discarded unreachable code: IL_0002, IL_0006
			//IL_0003: Incompatible stack heights: 0 vs 1
			//IL_0007: Incompatible stack heights: 0 vs 1
			VNYyTDcND8BF4891ylv();
			ll5d1LcJd47quAA6686(this);
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object JYNCFRclY19OMUDt3e5()
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			return Encoding.Unicode;
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object pKC674cFcQCi2WYC5TK(object P_0, object P_1)
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			return ((Encoding)P_0).GetBytes((string)P_1);
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void cbDAWWcMELkjXOEsqH1(object P_0, RuntimeFieldHandle P_1)
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			RuntimeHelpers.InitializeArray((Array)P_0, P_1);
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object RLDPpjcCqmQIZnwTek4(object P_0)
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			return hnFp4ccyi(P_0);
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object rRKtyFcVispIKdqS5lF()
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			return ngH331H9J();
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void NGHp1RcUt8Ff4IoOZZG(object P_0, object P_1)
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			((SymmetricAlgorithm)P_0).Key = (byte[])P_1;
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void vZiFnhc5nHyYQULARB1(object P_0, object P_1)
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			((SymmetricAlgorithm)P_0).IV = (byte[])P_1;
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object tCaHd1cPlEPcW5enqai(object P_0)
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			return ((SymmetricAlgorithm)P_0).CreateEncryptor();
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void sFIoR0cZOmjVuLi3g01(object P_0, object P_1, int P_2, int P_3)
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			((Stream)P_0).Write((byte[])P_1, P_2, P_3);
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void vtno0bcQtaptJYJgqbw(object P_0)
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			((Stream)P_0).Close();
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object IRea7vc4p8HmYd09eDZ(object P_0)
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			return ((MemoryStream)P_0).ToArray();
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object hMJYPGcKWMRnY8mIZT3(object P_0)
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			return Convert.ToBase64String((byte[])P_0);
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void VNYyTDcND8BF4891ylv()
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			bU1FJSlOuQklahmsOY.xWjn6pazmLWZg();
		}

		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void ll5d1LcJd47quAA6686(object P_0)
		{
			//Discarded unreachable code: IL_0002
			//IL_0003: Incompatible stack heights: 0 vs 1
			P_0._002Ector();
		}
	}

	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	internal delegate uint v3M5SuEuCV1lmBPpb8(IntPtr classthis, IntPtr comp, IntPtr info, [MarshalAs(UnmanagedType.U4)] uint flags, IntPtr nativeEntry, ref uint nativeSizeOfCode);

	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	private delegate IntPtr LO4X8M2I1CFFe1rB59();

	internal struct bUsTVJU0lf0bDwgCAy
	{
		internal bool LVmxP3LrER;

		internal byte[] P94xJe9xl3;
	}

	[Flags]
	private enum tyenO63H2jZnJFOsFh
	{

	}

	private static bool XqNqeed0Y;

	private static object Y5vLjSC9M;

	private static object Vxa430oAK;

	private static object Hw8kkX41b;

	private static IntPtr Xhj0vuAV5;

	private static object n5bCne8Aj;

	private static int ztfBgoVqB;

	private static bool NV9eFyUq1;

	internal static object UThRWct4d;

	private static bool iGZgWB2ZU;

	[f6km2k1IS01nF4ccyi(typeof(f6km2k1IS01nF4ccyi.QfjfwyifZ5DYgArOj1<object>[]))]
	private static bool yrBxdLaEYl;

	private static int MLAxsBlO2S;

	internal static object BlqxIRvyAv;

	private static long VihXtpAlh;

	private static bool j3UODjHZn;

	private static bool g3dHv3LuF;

	private static object T68nNUSkY;

	internal static object soiu7pqir;

	private static int zg3ty1KVr;

	private static object LdlA8kFpe;

	private static int W445LE72o;

	private static bool qRpzRCulb;

	private static object pZeaSKoQS;

	private static IntPtr o9cxxbmm5N;

	private static long jjpm17tFq;

	private static IntPtr B1Z97Gs11;

	private static object ihYViEaOJ;

	private static object aDyY24NGg;

	[MethodImpl(MethodImplOptions.NoInlining)]
	static ajPWp7JpCnYwAxGgPj()
	{
		//Discarded unreachable code: IL_0002, IL_0006
		//IL_0003: Incompatible stack heights: 0 vs 1
		//IL_0007: Incompatible stack heights: 0 vs 1
		XqNqeed0Y = false;
		Y5vLjSC9M = typeof(ajPWp7JpCnYwAxGgPj).Assembly;
		T68nNUSkY = new uint[64]
		{
			3614090360u, 3905402710u, 606105819u, 3250441966u, 4118548399u, 1200080426u, 2821735955u, 4249261313u, 1770035416u, 2336552879u,
			4294925233u, 2304563134u, 1804603682u, 4254626195u, 2792965006u, 1236535329u, 4129170786u, 3225465664u, 643717713u, 3921069994u,
			3593408605u, 38016083u, 3634488961u, 3889429448u, 568446438u, 3275163606u, 4107603335u, 1163531501u, 2850285829u, 4243563512u,
			1735328473u, 2368359562u, 4294588738u, 2272392833u, 1839030562u, 4259657740u, 2763975236u, 1272893353u, 4139469664u, 3200236656u,
			681279174u, 3936430074u, 3572445317u, 76029189u, 3654602809u, 3873151461u, 530742520u, 3299628645u, 4096336452u, 1126891415u,
			2878612391u, 4237533241u, 1700485571u, 2399980690u, 4293915773u, 2240044497u, 1873313359u, 4264355552u, 2734768916u, 1309151649u,
			4149444226u, 3174756917u, 718787259u, 3951481745u
		};
		j3UODjHZn = false;
		g3dHv3LuF = false;
		Vxa430oAK = new byte[0];
		aDyY24NGg = new byte[0];
		ihYViEaOJ = new byte[0];
		Hw8kkX41b = new byte[0];
		B1Z97Gs11 = IntPtr.Zero;
		Xhj0vuAV5 = IntPtr.Zero;
		n5bCne8Aj = new string[0];
		LdlA8kFpe = new int[0];
		ztfBgoVqB = 1;
		NV9eFyUq1 = false;
		pZeaSKoQS = new SortedList();
		W445LE72o = 0;
		VihXtpAlh = 0L;
		soiu7pqir = null;
		UThRWct4d = null;
		jjpm17tFq = 0L;
		zg3ty1KVr = 0;
		iGZgWB2ZU = false;
		qRpzRCulb = false;
		MLAxsBlO2S = 0;
		o9cxxbmm5N = IntPtr.Zero;
		yrBxdLaEYl = false;
		BlqxIRvyAv = new Hashtable();
		try
		{
			RSACryptoServiceProvider.UseMachineKeyStore = true;
		}
		catch
		{
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private void TwMn6paE8HQco()
	{
	}//Discarded unreachable code: IL_0002
	//IL_0003: Incompatible stack heights: 0 vs 1


	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static byte[] dsa1ggbkL(object _0020)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		uint[] array = new uint[16];
		int num = 448 - ((Array)_0020).Length * 8 % 512;
		uint num2 = (uint)((num + 512) % 512);
		if (num2 == 0)
		{
			num2 = 512u;
		}
		uint num3 = (uint)(((Array)_0020).Length + num2 / 8u + 8);
		ulong num4 = (ulong)((Array)_0020).Length * 8uL;
		byte[] array2 = new byte[num3];
		for (int i = 0; i < ((Array)_0020).Length; i++)
		{
			array2[i] = ((byte[])_0020)[i];
		}
		array2[((Array)_0020).Length] |= 128;
		for (int num5 = 8; num5 > 0; num5--)
		{
			array2[num3 - num5] = (byte)((num4 >> (8 - num5) * 8) & 0xFF);
		}
		uint num6 = (uint)(array2.Length * 8) / 32u;
		uint num7 = 1732584193u;
		uint num8 = 4023233417u;
		uint num9 = 2562383102u;
		uint num10 = 271733878u;
		for (uint num11 = 0u; num11 < num6 / 16u; num11++)
		{
			uint num12 = num11 << 6;
			for (uint num13 = 0u; num13 < 61; num13 += 4)
			{
				array[num13 >> 2] = (uint)((array2[num12 + (num13 + 3)] << 24) | (array2[num12 + (num13 + 2)] << 16) | (array2[num12 + (num13 + 1)] << 8) | array2[num12 + num13]);
			}
			uint num14 = num7;
			uint num15 = num8;
			uint num16 = num9;
			uint num17 = num10;
			RLgiZ1lA3(ref num7, num8, num9, num10, 0u, 7, 1u, array);
			RLgiZ1lA3(ref num10, num7, num8, num9, 1u, 12, 2u, array);
			RLgiZ1lA3(ref num9, num10, num7, num8, 2u, 17, 3u, array);
			RLgiZ1lA3(ref num8, num9, num10, num7, 3u, 22, 4u, array);
			RLgiZ1lA3(ref num7, num8, num9, num10, 4u, 7, 5u, array);
			RLgiZ1lA3(ref num10, num7, num8, num9, 5u, 12, 6u, array);
			RLgiZ1lA3(ref num9, num10, num7, num8, 6u, 17, 7u, array);
			RLgiZ1lA3(ref num8, num9, num10, num7, 7u, 22, 8u, array);
			RLgiZ1lA3(ref num7, num8, num9, num10, 8u, 7, 9u, array);
			RLgiZ1lA3(ref num10, num7, num8, num9, 9u, 12, 10u, array);
			RLgiZ1lA3(ref num9, num10, num7, num8, 10u, 17, 11u, array);
			RLgiZ1lA3(ref num8, num9, num10, num7, 11u, 22, 12u, array);
			RLgiZ1lA3(ref num7, num8, num9, num10, 12u, 7, 13u, array);
			RLgiZ1lA3(ref num10, num7, num8, num9, 13u, 12, 14u, array);
			RLgiZ1lA3(ref num9, num10, num7, num8, 14u, 17, 15u, array);
			RLgiZ1lA3(ref num8, num9, num10, num7, 15u, 22, 16u, array);
			GjgMHjksC(ref num7, num8, num9, num10, 1u, 5, 17u, array);
			GjgMHjksC(ref num10, num7, num8, num9, 6u, 9, 18u, array);
			GjgMHjksC(ref num9, num10, num7, num8, 11u, 14, 19u, array);
			GjgMHjksC(ref num8, num9, num10, num7, 0u, 20, 20u, array);
			GjgMHjksC(ref num7, num8, num9, num10, 5u, 5, 21u, array);
			GjgMHjksC(ref num10, num7, num8, num9, 10u, 9, 22u, array);
			GjgMHjksC(ref num9, num10, num7, num8, 15u, 14, 23u, array);
			GjgMHjksC(ref num8, num9, num10, num7, 4u, 20, 24u, array);
			GjgMHjksC(ref num7, num8, num9, num10, 9u, 5, 25u, array);
			GjgMHjksC(ref num10, num7, num8, num9, 14u, 9, 26u, array);
			GjgMHjksC(ref num9, num10, num7, num8, 3u, 14, 27u, array);
			GjgMHjksC(ref num8, num9, num10, num7, 8u, 20, 28u, array);
			GjgMHjksC(ref num7, num8, num9, num10, 13u, 5, 29u, array);
			GjgMHjksC(ref num10, num7, num8, num9, 2u, 9, 30u, array);
			GjgMHjksC(ref num9, num10, num7, num8, 7u, 14, 31u, array);
			GjgMHjksC(ref num8, num9, num10, num7, 12u, 20, 32u, array);
			zlcFjgxjP(ref num7, num8, num9, num10, 5u, 4, 33u, array);
			zlcFjgxjP(ref num10, num7, num8, num9, 8u, 11, 34u, array);
			zlcFjgxjP(ref num9, num10, num7, num8, 11u, 16, 35u, array);
			zlcFjgxjP(ref num8, num9, num10, num7, 14u, 23, 36u, array);
			zlcFjgxjP(ref num7, num8, num9, num10, 1u, 4, 37u, array);
			zlcFjgxjP(ref num10, num7, num8, num9, 4u, 11, 38u, array);
			zlcFjgxjP(ref num9, num10, num7, num8, 7u, 16, 39u, array);
			zlcFjgxjP(ref num8, num9, num10, num7, 10u, 23, 40u, array);
			zlcFjgxjP(ref num7, num8, num9, num10, 13u, 4, 41u, array);
			zlcFjgxjP(ref num10, num7, num8, num9, 0u, 11, 42u, array);
			zlcFjgxjP(ref num9, num10, num7, num8, 3u, 16, 43u, array);
			zlcFjgxjP(ref num8, num9, num10, num7, 6u, 23, 44u, array);
			zlcFjgxjP(ref num7, num8, num9, num10, 9u, 4, 45u, array);
			zlcFjgxjP(ref num10, num7, num8, num9, 12u, 11, 46u, array);
			zlcFjgxjP(ref num9, num10, num7, num8, 15u, 16, 47u, array);
			zlcFjgxjP(ref num8, num9, num10, num7, 2u, 23, 48u, array);
			rp7EpCnYw(ref num7, num8, num9, num10, 0u, 6, 49u, array);
			rp7EpCnYw(ref num10, num7, num8, num9, 7u, 10, 50u, array);
			rp7EpCnYw(ref num9, num10, num7, num8, 14u, 15, 51u, array);
			rp7EpCnYw(ref num8, num9, num10, num7, 5u, 21, 52u, array);
			rp7EpCnYw(ref num7, num8, num9, num10, 12u, 6, 53u, array);
			rp7EpCnYw(ref num10, num7, num8, num9, 3u, 10, 54u, array);
			rp7EpCnYw(ref num9, num10, num7, num8, 10u, 15, 55u, array);
			rp7EpCnYw(ref num8, num9, num10, num7, 1u, 21, 56u, array);
			rp7EpCnYw(ref num7, num8, num9, num10, 8u, 6, 57u, array);
			rp7EpCnYw(ref num10, num7, num8, num9, 15u, 10, 58u, array);
			rp7EpCnYw(ref num9, num10, num7, num8, 6u, 15, 59u, array);
			rp7EpCnYw(ref num8, num9, num10, num7, 13u, 21, 60u, array);
			rp7EpCnYw(ref num7, num8, num9, num10, 4u, 6, 61u, array);
			rp7EpCnYw(ref num10, num7, num8, num9, 11u, 10, 62u, array);
			rp7EpCnYw(ref num9, num10, num7, num8, 2u, 15, 63u, array);
			rp7EpCnYw(ref num8, num9, num10, num7, 9u, 21, 64u, array);
			num7 += num14;
			num8 += num15;
			num9 += num16;
			num10 += num17;
		}
		byte[] array3 = new byte[16];
		Array.Copy(BitConverter.GetBytes(num7), 0, array3, 0, 4);
		Array.Copy(BitConverter.GetBytes(num8), 0, array3, 4, 4);
		Array.Copy(BitConverter.GetBytes(num9), 0, array3, 8, 4);
		Array.Copy(BitConverter.GetBytes(num10), 0, array3, 12, 4);
		return array3;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static void RLgiZ1lA3(ref uint _0020, uint _0020, uint _0020, uint _0020, uint _0020, ushort _0020, uint _0020, object _0020)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		_0020 += QxG2gPjp4(_0020 + ((_0020 & _0020) | (~_0020 & _0020)) + ((uint[])_0020)[_0020] + ((uint[])T68nNUSkY)[_0020 - 1], _0020);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static void GjgMHjksC(ref uint _0020, uint _0020, uint _0020, uint _0020, uint _0020, ushort _0020, uint _0020, object _0020)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		_0020 += QxG2gPjp4(_0020 + ((_0020 & _0020) | (_0020 & ~_0020)) + ((uint[])_0020)[_0020] + ((uint[])T68nNUSkY)[_0020 - 1], _0020);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static void zlcFjgxjP(ref uint _0020, uint _0020, uint _0020, uint _0020, uint _0020, ushort _0020, uint _0020, object _0020)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		_0020 += QxG2gPjp4(_0020 + (_0020 ^ _0020 ^ _0020) + ((uint[])_0020)[_0020] + ((uint[])T68nNUSkY)[_0020 - 1], _0020);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static void rp7EpCnYw(ref uint _0020, uint _0020, uint _0020, uint _0020, uint _0020, ushort _0020, uint _0020, object _0020)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		_0020 += QxG2gPjp4(_0020 + (_0020 ^ (_0020 | ~_0020)) + ((uint[])_0020)[_0020] + ((uint[])T68nNUSkY)[_0020 - 1], _0020);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static uint QxG2gPjp4(uint _0020, ushort _0020)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return (_0020 >> 32 - _0020) | (_0020 << (int)_0020);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static bool JuHUu09QN()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		if (!j3UODjHZn)
		{
			Akml2kIS0();
			j3UODjHZn = true;
		}
		return g3dHv3LuF;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static SymmetricAlgorithm ngH331H9J()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		SymmetricAlgorithm symmetricAlgorithm = null;
		if (JuHUu09QN())
		{
			return new AesCryptoServiceProvider();
		}
		try
		{
			return new RijndaelManaged();
		}
		catch
		{
			return (SymmetricAlgorithm)Activator.CreateInstance("System.Core, Version=3.5.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089", "System.Security.Cryptography.AesCryptoServiceProvider").Unwrap();
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void Akml2kIS0()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		try
		{
			g3dHv3LuF = CryptoConfig.AllowOnlyFipsAlgorithms;
		}
		catch
		{
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static byte[] hnFp4ccyi(object _0020)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		if (!JuHUu09QN())
		{
			return new MD5CryptoServiceProvider().ComputeHash((byte[])_0020);
		}
		return dsa1ggbkL(_0020);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static uint TDYTgArOj(uint _0020)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return (uint)"{11111-22222-10009-11112}".Length;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	[f6km2k1IS01nF4ccyi(typeof(f6km2k1IS01nF4ccyi.QfjfwyifZ5DYgArOj1<object>[]))]
	internal static string g4tWycSQ4(int _0020)
	{
		//Discarded unreachable code: IL_0002, IL_293f, IL_3b10
		//IL_0003: Incompatible stack heights: 0 vs 1
		//IL_37b7: Incompatible stack heights: 0 vs 1
		//IL_37c1: Incompatible stack heights: 0 vs 1
		//IL_37eb: Incompatible stack heights: 0 vs 1
		//IL_37f5: Incompatible stack heights: 0 vs 1
		//IL_37ff: Incompatible stack heights: 0 vs 1
		//IL_3809: Incompatible stack heights: 0 vs 1
		//IL_3813: Incompatible stack heights: 0 vs 1
		//IL_381d: Incompatible stack heights: 0 vs 1
		//IL_3827: Incompatible stack heights: 0 vs 1
		//IL_3831: Incompatible stack heights: 0 vs 1
		//IL_3845: Incompatible stack heights: 0 vs 1
		//IL_384f: Incompatible stack heights: 0 vs 1
		//IL_3859: Incompatible stack heights: 0 vs 1
		//IL_3863: Incompatible stack heights: 0 vs 1
		//IL_3877: Incompatible stack heights: 0 vs 1
		//IL_3881: Incompatible stack heights: 0 vs 1
		//IL_388b: Incompatible stack heights: 0 vs 1
		//IL_389f: Incompatible stack heights: 0 vs 1
		//IL_38b3: Incompatible stack heights: 0 vs 1
		//IL_38bd: Incompatible stack heights: 0 vs 1
		//IL_38c7: Incompatible stack heights: 0 vs 1
		//IL_38d1: Incompatible stack heights: 0 vs 1
		//IL_38db: Incompatible stack heights: 0 vs 1
		//IL_38e5: Incompatible stack heights: 0 vs 1
		//IL_38ef: Incompatible stack heights: 0 vs 1
		//IL_38f9: Incompatible stack heights: 0 vs 1
		//IL_3903: Incompatible stack heights: 0 vs 1
		//IL_390d: Incompatible stack heights: 0 vs 1
		//IL_3917: Incompatible stack heights: 0 vs 1
		//IL_392b: Incompatible stack heights: 0 vs 1
		//IL_3935: Incompatible stack heights: 0 vs 1
		//IL_393f: Incompatible stack heights: 0 vs 1
		//IL_3949: Incompatible stack heights: 0 vs 1
		//IL_3953: Incompatible stack heights: 0 vs 1
		//IL_395d: Incompatible stack heights: 0 vs 2
		//IL_3967: Incompatible stack heights: 0 vs 1
		//IL_3971: Incompatible stack heights: 0 vs 1
		//IL_397b: Incompatible stack heights: 0 vs 1
		//IL_398f: Incompatible stack heights: 0 vs 1
		//IL_3999: Incompatible stack heights: 0 vs 1
		//IL_39a3: Incompatible stack heights: 0 vs 1
		//IL_39ad: Incompatible stack heights: 0 vs 1
		//IL_39b7: Incompatible stack heights: 0 vs 1
		//IL_39c1: Incompatible stack heights: 0 vs 2
		//IL_39cb: Incompatible stack heights: 0 vs 1
		//IL_39d5: Incompatible stack heights: 0 vs 1
		//IL_39df: Incompatible stack heights: 0 vs 1
		//IL_39e9: Incompatible stack heights: 0 vs 1
		//IL_39f3: Incompatible stack heights: 0 vs 1
		//IL_39fd: Incompatible stack heights: 0 vs 1
		//IL_3a11: Incompatible stack heights: 0 vs 1
		//IL_3a1b: Incompatible stack heights: 0 vs 1
		//IL_3a25: Incompatible stack heights: 0 vs 1
		//IL_3a2f: Incompatible stack heights: 0 vs 1
		//IL_3a39: Incompatible stack heights: 0 vs 1
		//IL_3a43: Incompatible stack heights: 0 vs 1
		//IL_3a4d: Incompatible stack heights: 0 vs 1
		//IL_3a57: Incompatible stack heights: 0 vs 1
		//IL_3a61: Incompatible stack heights: 0 vs 1
		//IL_3a6b: Incompatible stack heights: 0 vs 1
		//IL_3a75: Incompatible stack heights: 0 vs 1
		//IL_3a7f: Incompatible stack heights: 0 vs 1
		//IL_3a89: Incompatible stack heights: 0 vs 1
		//IL_3a93: Incompatible stack heights: 0 vs 1
		//IL_3a9d: Incompatible stack heights: 0 vs 1
		//IL_3aa7: Incompatible stack heights: 0 vs 1
		//IL_3ab1: Incompatible stack heights: 0 vs 1
		//IL_3abb: Incompatible stack heights: 0 vs 1
		//IL_3ac5: Incompatible stack heights: 0 vs 1
		//IL_3acf: Incompatible stack heights: 0 vs 1
		//IL_3ad9: Incompatible stack heights: 0 vs 1
		//IL_3ae3: Incompatible stack heights: 0 vs 1
		//IL_3aed: Incompatible stack heights: 0 vs 1
		//IL_3af7: Incompatible stack heights: 0 vs 1
		//IL_3b01: Incompatible stack heights: 0 vs 1
		//IL_3b0b: Incompatible stack heights: 0 vs 1
		int num = 76;
		if (false)
		{
			goto IL_0013;
		}
		goto IL_2948;
		IL_2948:
		int num4 = default(int);
		byte[] array = default(byte[]);
		byte[] array2 = default(byte[]);
		int num7 = default(int);
		byte[] array3 = default(byte[]);
		byte[] array4 = default(byte[]);
		int num30 = default(int);
		byte[] array7 = default(byte[]);
		byte[] array6 = default(byte[]);
		int num10 = default(int);
		uint num34 = default(uint);
		int num37 = default(int);
		uint num14 = default(uint);
		SymmetricAlgorithm symmetricAlgorithm = default(SymmetricAlgorithm);
		byte[] array5 = default(byte[]);
		CryptoStream cryptoStream = default(CryptoStream);
		int num5 = default(int);
		uint num15 = default(uint);
		uint num11 = default(uint);
		int num16 = default(int);
		BinaryReader binaryReader = default(BinaryReader);
		int num32 = default(int);
		uint num8 = default(uint);
		uint num31 = default(uint);
		int num36 = default(int);
		int num33 = default(int);
		ICryptoTransform transform = default(ICryptoTransform);
		uint num13 = default(uint);
		int num9 = default(int);
		int num12 = default(int);
		uint num17 = default(uint);
		MemoryStream memoryStream = default(MemoryStream);
		int num3 = default(int);
		while (true)
		{
			IL_2948_2:
			int num2 = num;
			while (true)
			{
				int num6;
				switch (num2)
				{
				case 87:
					break;
				case 180:
					goto IL_0030;
				case 221:
					goto IL_0045;
				case 114:
					num4 = 38 + 92;
					num = 170;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 170;
				case 170:
					array[30] = (byte)num4;
					num2 = 268;
					continue;
				case 28:
					array2[3] = (byte)num7;
					num6 = 331;
					goto IL_2944;
				case 402:
					num4 = 224 - 74;
					num2 = 278;
					continue;
				case 390:
					num4 = 210 - 96;
					num = 100;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_0101: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 202;
				case 74:
					array[7] = (byte)num4;
					num2 = 308;
					continue;
				case 383:
					array[28] = 127;
					num6 = 209;
					goto IL_2944;
				case 19:
					array[27] = 106;
					num6 = 360;
					goto IL_2944;
				case 414:
					array[26] = 159;
					num6 = 105;
					goto IL_2944;
				case 36:
					num7 = 192 - 64;
					num2 = 313;
					continue;
				case 399:
					num4 = 87 + 24;
					num = 285;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 416;
				case 416:
					num7 = 249 - 83;
					num = 205;
					goto IL_2948_2;
				case 60:
					array2[1] = (byte)num7;
					num6 = 115;
					goto IL_2944;
				case 81:
					array3[1] = array4[0];
					num2 = 405;
					continue;
				case 72:
					array[10] = (byte)num4;
					num2 = 293;
					continue;
				case 371:
					num30 = array7.Length / 4;
					num = 236;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_022c: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 16;
				case 191:
					array[7] = 110;
					num = 165;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 62;
				case 62:
					num7 = 179 - 59;
					num = 32;
					goto IL_2948_2;
				case 207:
					array[8] = (byte)num4;
					num = 277;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 83;
				case 83:
					array[31] = 88;
					num2 = 244;
					continue;
				case 3:
					num4 = 232 - 77;
					num2 = 250;
					continue;
				case 141:
					array2[10] = 140;
					num6 = 351;
					goto IL_2944;
				case 59:
					num4 = 93 + 91;
					num2 = 152;
					continue;
				case 53:
					array2[7] = 221;
					num2 = 88;
					continue;
				case 310:
					array2[6] = (byte)num7;
					num = 96;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 71;
				case 71:
					num4 = 186 - 62;
					num = 144;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 266;
				case 266:
					array[16] = (byte)num4;
					num = 147;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_037a: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 384;
				case 101:
					array[22] = 139;
					num = 280;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 165;
				case 165:
					num4 = 229 - 114;
					num2 = 210;
					continue;
				case 27:
					array[18] = (byte)num4;
					num = 320;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 304;
				case 304:
					array[29] = (byte)num4;
					num2 = 287;
					continue;
				case 257:
					array2[15] = 190;
					num = 283;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 372;
				case 372:
					array6[num10 + 1] = (byte)((num34 & 0xFF00) >> 8);
					num6 = 253;
					goto IL_2944;
				case 397:
					array[25] = 142;
					num6 = 43;
					goto IL_2944;
				case 230:
					array[31] = 56;
					num6 = 168;
					goto IL_2944;
				case 82:
					array2[12] = 224;
					num = 36;
					goto IL_2948_2;
				case 300:
					array3[7] = array4[3];
					num = 66;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 326;
				case 326:
					num4 = 239 - 79;
					num6 = 109;
					goto IL_2944;
				case 226:
					array[23] = 159;
					num6 = 298;
					goto IL_2944;
				case 184:
					array[18] = 105;
					num6 = 110;
					goto IL_2944;
				case 100:
					array[6] = (byte)num4;
					num6 = 262;
					goto IL_2944;
				case 58:
					num37 += 8;
					num6 = 7;
					goto IL_2944;
				case 426:
					array[14] = (byte)num4;
					num = 350;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_0549: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 370;
				case 277:
					array[9] = 152;
					num6 = 208;
					goto IL_2944;
				case 159:
					array[31] = (byte)num4;
					num = 83;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 129;
				case 129:
					num14 = 0u;
					num2 = 148;
					continue;
				case 161:
					array[6] = 148;
					num = 322;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_05bf: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 197;
				case 224:
					num4 = 174 + 64;
					num2 = 18;
					continue;
				case 350:
					num4 = 230 - 76;
					num2 = 377;
					continue;
				case 174:
					num4 = 136 + 30;
					num = 265;
					goto IL_2948_2;
				case 322:
					array[6] = 123;
					num6 = 399;
					goto IL_2944;
				case 338:
					array[22] = 179;
					num6 = 316;
					goto IL_2944;
				case 160:
					array[10] = (byte)num4;
					num6 = 349;
					goto IL_2944;
				case 346:
					array2[8] = 142;
					num = 245;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_0691: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 315;
				case 323:
					array[26] = (byte)num4;
					num2 = 19;
					continue;
				case 246:
					num37 = 0;
					num = 347;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_06c4: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 245;
				case 245:
					num7 = 133 - 44;
					num6 = 324;
					goto IL_2944;
				case 417:
					array[9] = (byte)num4;
					num2 = 121;
					continue;
				case 284:
					num7 = 112 + 79;
					num6 = 91;
					goto IL_2944;
				case 102:
					num4 = 36 + 28;
					num6 = 135;
					goto IL_2944;
				case 240:
					num4 = 26 + 48;
					num = 27;
					goto IL_2948_2;
				case 364:
					num7 = 123 + 57;
					num = 202;
					goto IL_2948_2;
				case 76:
					if (((Array)ihYViEaOJ).Length == 0)
					{
						num = 1;
						if (true)
						{
							goto IL_2948_2;
						}
						goto case 190;
					}
					goto case 65;
				case 190:
					array2[2] = 98;
					num = 340;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_07a4: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 73;
				case 216:
					array[11] = (byte)num4;
					num2 = 157;
					continue;
				case 79:
					array[6] = (byte)num4;
					num = 161;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 198;
				case 198:
					array[30] = (byte)num4;
					num2 = 333;
					continue;
				case 379:
					array[5] = (byte)num4;
					num = 41;
					goto IL_2948_2;
				case 63:
					array[4] = (byte)num4;
					num = 243;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 427;
				case 427:
					array2[9] = (byte)num7;
					num2 = 292;
					continue;
				case 374:
					array[18] = 148;
					num2 = 240;
					continue;
				case 43:
					array[26] = 123;
					num2 = 118;
					continue;
				case 349:
					num4 = 166 - 56;
					num = 321;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 239;
				case 239:
					num4 = 166 + 23;
					num6 = 381;
					goto IL_2944;
				case 297:
					WbXiklFKlAFcbLag47(symmetricAlgorithm, CipherMode.CBC);
					num = 139;
					goto IL_2948_2;
				case 176:
					array[28] = 30;
					num6 = 239;
					goto IL_2944;
				case 377:
					array[14] = (byte)num4;
					num = 366;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_0912: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 275;
				case 260:
					num4 = 151 - 50;
					num6 = 325;
					goto IL_2944;
				case 66:
					array3[9] = array4[4];
					num6 = 357;
					goto IL_2944;
				case 84:
					num14 = 0u;
					num = 337;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_0959: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 142;
				case 142:
					array5 = (byte[])ihYViEaOJ;
					num2 = 248;
					continue;
				case 369:
					num4 = 16 + 92;
					num6 = 335;
					goto IL_2944;
				case 234:
					array2[0] = (byte)num7;
					num = 334;
					goto IL_2948_2;
				case 325:
					array[1] = (byte)num4;
					num2 = 279;
					continue;
				case 178:
					array[9] = (byte)num4;
					num2 = 221;
					continue;
				case 287:
					num4 = 21 - 13;
					num2 = 343;
					continue;
				case 294:
					num4 = 163 - 83;
					num6 = 162;
					goto IL_2944;
				case 210:
					array[7] = (byte)num4;
					num = 156;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_0a22: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 160;
				case 378:
					array2[7] = 112;
					num = 284;
					goto IL_2948_2;
				case 39:
					array[22] = (byte)num4;
					num2 = 226;
					continue;
				case 181:
					num7 = 0 + 80;
					num = 51;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 25;
				case 25:
					array2[6] = (byte)num7;
					num = 57;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_0aa1: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 376;
				case 8:
					array[24] = (byte)num4;
					num = 315;
					goto IL_2948_2;
				case 212:
					uyothYMrOoaG7SRlg9(cryptoStream);
					num2 = 419;
					continue;
				case 103:
					array[1] = (byte)num4;
					num2 = 291;
					continue;
				case 52:
					array2[13] = (byte)num7;
					num2 = 288;
					continue;
				case 14:
					array[20] = (byte)num4;
					num6 = 232;
					goto IL_2944;
				case 90:
				case 130:
					array[17] = (byte)num4;
					num = 301;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 312;
				case 312:
					array[18] = (byte)num4;
					num6 = 369;
					goto IL_2944;
				case 250:
					array[12] = (byte)num4;
					num2 = 336;
					continue;
				case 138:
					array[8] = (byte)num4;
					num = 111;
					goto IL_2948_2;
				case 305:
					num4 = 105 + 90;
					num = 415;
					goto IL_2948_2;
				case 150:
					array[15] = 135;
					num = 21;
					goto IL_2948_2;
				case 134:
					array[24] = 24;
					num2 = 330;
					continue;
				case 7:
					array6[num10 + num5] = (byte)((num15 & num11) >> num37);
					num = 92;
					goto IL_2948_2;
				case 408:
					array2[0] = (byte)num7;
					num = 384;
					goto IL_2948_2;
				case 37:
					num4 = 192 - 64;
					num = 200;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_0c43: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 258;
				case 197:
					array[3] = (byte)num4;
					num6 = 86;
					goto IL_2944;
				case 340:
					num7 = 93 + 91;
					num2 = 235;
					continue;
				case 203:
					array[26] = (byte)num4;
					num2 = 299;
					continue;
				case 271:
					array6[num10 + 3] = (byte)((num34 & 0xFF000000u) >> 24);
					num = 373;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_0cb7: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 321;
				case 321:
					array[10] = (byte)num4;
					num2 = 329;
					continue;
				case 177:
					num4 = 134 + 12;
					num = 164;
					goto IL_2948_2;
				case 115:
					array2[1] = 96;
					num = 263;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_0d14: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 316;
				case 316:
					num4 = 11 + 20;
					num6 = 182;
					goto IL_2944;
				case 149:
					MYUlDwsCB7bKYCLIvt(cryptoStream);
					num = 142;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 93;
				case 93:
					num16 = array5.Length / 4;
					num = 290;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 280;
				case 280:
					array[22] = 98;
					num2 = 338;
					continue;
				case 73:
					S9XIwC8X4Cfadjpcgt(binaryReader);
					rDXNr7H0Ej0c6PK0am((object)/*Error near IL_38a9: Stack underflow*/, 0L);
					num2 = 274;
					continue;
				case 418:
					num32++;
					num2 = 430;
					continue;
				case 97:
					num8 = (uint)((array7[num31 + 3] << 24) | (array7[num31 + 2] << 16) | (array7[num31 + 1] << 8) | array7[num31]);
					num6 = 179;
					goto IL_2944;
				case 251:
					array[21] = 235;
					num2 = 101;
					continue;
				case 235:
					array2[2] = (byte)num7;
					num6 = 218;
					goto IL_2944;
				case 336:
					num4 = 180 - 60;
					num = 80;
					goto IL_2948_2;
				case 116:
					num7 = 95 + 3;
					num = 219;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_0e4c: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 188;
				case 366:
					array[14] = 37;
					num = 387;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 380;
				case 380:
					array2[14] = 115;
					num2 = 192;
					continue;
				case 228:
					array[27] = 138;
					num = 224;
					goto IL_2948_2;
				case 146:
					array[0] = (byte)num4;
					num = 125;
					goto IL_2948_2;
				case 154:
					ihYViEaOJ = array6;
					num6 = 65;
					goto IL_2944;
				case 120:
					KOrJp8DZjogHAAy4du(Y5vLjSC9M);
					N9giqV6ZRD5gyYRqyE((object)/*Error near IL_38db: Stack underflow*/);
					array4 = (byte[])/*Error near IL_0f4f: Stack underflow*/;
					num = 358;
					goto IL_2948_2;
				case 54:
					num31 = (uint)(num36 * 4);
					num = 97;
					goto IL_2948_2;
				case 30:
					array2[2] = 139;
					num = 190;
					goto IL_2948_2;
				case 211:
					array[25] = (byte)num4;
					num6 = 394;
					goto IL_2944;
				case 356:
					array[7] = 191;
					num6 = 191;
					goto IL_2944;
				case 238:
					array[15] = (byte)num4;
					num2 = 393;
					continue;
				case 48:
					array7 = array;
					num = 50;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 357;
				case 357:
					array3[11] = array4[5];
					num = 306;
					goto IL_2948_2;
				case 359:
					array[20] = (byte)num4;
					num2 = 98;
					continue;
				case 164:
					array[31] = (byte)num4;
					num6 = 48;
					goto IL_2944;
				case 328:
					array[13] = (byte)num4;
					num2 = 171;
					continue;
				case 171:
					array[13] = 158;
					num = 406;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 254;
				case 254:
					num4 = 87 - 54;
					num = 252;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_109d: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 396;
				case 396:
					num33 = 0;
					num6 = 194;
					goto IL_2944;
				case 139:
					a8sSenh1KZI5SZ3iaC(symmetricAlgorithm, array7, array3);
					transform = (ICryptoTransform)/*Error near IL_10b7: Stack underflow*/;
					num6 = 407;
					goto IL_2944;
				case 20:
					array[3] = (byte)num4;
					num2 = 137;
					continue;
				case 339:
					array[15] = (byte)num4;
					num = 150;
					goto IL_2948_2;
				case 273:
					array2[6] = (byte)num7;
					num2 = 378;
					continue;
				case 185:
					num31 = (uint)num10;
					num = 70;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_1124: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 194;
				case 409:
					num7 = 85 + 32;
					num = 223;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 236;
				case 236:
					num13 = 0u;
					num6 = 424;
					goto IL_2944;
				case 13:
				case 421:
					num4 = 243 - 81;
					num2 = 103;
					continue;
				case 405:
					array3[3] = array4[1];
					num2 = 204;
					continue;
				case 196:
					array2[9] = 62;
					num2 = 117;
					continue;
				case 95:
					num7 = 116 + 90;
					num2 = 425;
					continue;
				case 38:
					array[19] = (byte)num4;
					num = 294;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_11d8: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 330;
				case 330:
					num4 = 114 + 55;
					num = 211;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_11fa: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 419;
				case 403:
					array[2] = (byte)num4;
					num = 318;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_1220: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 234;
				case 145:
					array[5] = 61;
					num = 201;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 12;
				case 12:
					if (_0020 == -1)
					{
						num2 = 282;
						continue;
					}
					goto case 248;
				case 57:
					array2[6] = 132;
					num6 = 68;
					goto IL_2944;
				case 425:
					array2[11] = (byte)num7;
					num = 269;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 289;
				case 289:
					array[9] = (byte)num4;
					num = 42;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 311;
				case 311:
					num4 = 67 + 110;
					num2 = 8;
					continue;
				case 276:
					num7 = 94 + 96;
					num2 = 26;
					continue;
				case 17:
					array[21] = 111;
					num6 = 251;
					goto IL_2944;
				case 195:
				case 373:
					num9++;
					num = 281;
					goto IL_2948_2;
				case 10:
					YucSGKpr1AbaXAWZQu(cryptoStream, array5, 0, array5.Length);
					num6 = 212;
					goto IL_2944;
				case 218:
					num7 = 102 + 105;
					num6 = 49;
					goto IL_2944;
				case 411:
					array[5] = (byte)num4;
					num6 = 206;
					goto IL_2944;
				case 395:
					num4 = 253 - 84;
					num2 = 160;
					continue;
				case 175:
					num16++;
					num6 = 341;
					goto IL_2944;
				case 68:
					num7 = 104 + 111;
					num6 = 310;
					goto IL_2944;
				case 344:
					array[21] = 106;
					num = 17;
					goto IL_2948_2;
				case 299:
					array[26] = 160;
					num2 = 368;
					continue;
				case 404:
					array[30] = (byte)num4;
					num2 = 370;
					continue;
				case 188:
					array[10] = (byte)num4;
					num2 = 395;
					continue;
				case 337:
					num13 += num8;
					num = 396;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_142f: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 215;
				case 215:
					num7 = 212 + 28;
					num = 2;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_1451: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 280;
				case 400:
					num14 <<= 8;
					num = 128;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 187;
				case 187:
					array[23] = (byte)num4;
					num6 = 89;
					goto IL_2944;
				case 41:
					num4 = 208 - 95;
					num = 411;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 23;
				case 23:
					array[0] = (byte)num4;
					num6 = 354;
					goto IL_2944;
				case 47:
					array2[13] = (byte)num7;
					num6 = 332;
					goto IL_2944;
				case 342:
					array6[num10] = (byte)(num34 & 0xFFu);
					num = 372;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_1508: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 23;
				case 208:
					num4 = 139 - 46;
					num2 = 417;
					continue;
				case 248:
					num12 = array5.Length % 4;
					num6 = 93;
					goto IL_2944;
				case 15:
					num7 = 103 + 93;
					num6 = 131;
					goto IL_2944;
				case 9:
					num4 = 80 + 60;
					num2 = 216;
					continue;
				case 423:
					if (num9 != num16 - 1)
					{
						goto IL_0067;
					}
					num = 286;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 18;
				case 18:
					array[27] = (byte)num4;
					num6 = 383;
					goto IL_2944;
				case 85:
					array[9] = (byte)num4;
					num = 241;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_15bd: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 65;
				case 162:
					array[19] = (byte)num4;
					num6 = 69;
					goto IL_2944;
				case 137:
					array[3] = 98;
					num2 = 59;
					continue;
				case 44:
				case 281:
					if (num9 < num16)
					{
						num36 = num9 % num30;
						num = 412;
						jdT9K1aeNeX1SwHsZK();
						if ((int)/*Error near IL_0f39: Stack underflow*/ != 0)
						{
							goto IL_2948_2;
						}
						goto case 214;
					}
					num6 = 154;
					goto IL_2944;
				case 118:
					num4 = 208 - 69;
					num = 319;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 329;
				case 329:
					array[11] = 129;
					num2 = 386;
					continue;
				case 295:
					array2[3] = (byte)num7;
					num6 = 428;
					goto IL_2944;
				case 205:
					array2[12] = (byte)num7;
					num6 = 261;
					goto IL_2944;
				case 220:
					num4 = 104 + 66;
					num2 = 39;
					continue;
				case 80:
					array[12] = (byte)num4;
					num6 = 402;
					goto IL_2944;
				case 204:
					array3[5] = array4[2];
					num = 300;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 152;
				case 152:
					array[3] = (byte)num4;
					num = 305;
					goto IL_2948_2;
				case 274:
				{
					S9XIwC8X4Cfadjpcgt(binaryReader);
					aLTNtNGdf1ODJWEbKP((object)/*Error near IL_3967: Stack underflow*/);
					int num35 = (int)/*Error near IL_16ec: Stack underflow*/;
					e5sTbB4JOgx53F2eiG((object)/*Error near IL_3971: Stack underflow*/, num35);
					array5 = (byte[])/*Error near IL_16f3: Stack underflow*/;
					num2 = 222;
					continue;
				}
				case 32:
					array2[3] = (byte)num7;
					num = 33;
					goto IL_2948_2;
				case 55:
					array[5] = (byte)num4;
					num = 145;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_173a: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 324;
				case 324:
					array2[8] = (byte)num7;
					num2 = 389;
					continue;
				case 217:
					num7 = 152 - 50;
					num6 = 408;
					goto IL_2944;
				case 42:
					num4 = 39 + 8;
					num6 = 85;
					goto IL_2944;
				case 22:
					num4 = 249 - 83;
					num = 328;
					goto IL_2948_2;
				case 158:
					TbXCclALQR6ZN4cwvK(array3);
					num = 120;
					goto IL_2948_2;
				case 233:
					num4 = 202 - 67;
					num2 = 138;
					continue;
				case 50:
					array2 = new byte[16];
					num = 217;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 308;
				case 308:
					array[7] = 131;
					num2 = 317;
					continue;
				case 219:
					array2[5] = (byte)num7;
					num6 = 272;
					goto IL_2944;
				case 298:
					array[23] = 150;
					num6 = 355;
					goto IL_2944;
				case 394:
					array[25] = 133;
					num2 = 397;
					continue;
				case 64:
					array2[5] = (byte)num7;
					num2 = 276;
					continue;
				case 252:
					array[17] = (byte)num4;
					num6 = 132;
					goto IL_2944;
				case 172:
					array2[1] = (byte)num7;
					num = 237;
					goto IL_2948_2;
				case 268:
					array[30] = 65;
					num6 = 230;
					goto IL_2944;
				case 105:
					num4 = 8 + 97;
					num6 = 203;
					goto IL_2944;
				case 113:
					array2[1] = (byte)num7;
					num6 = 133;
					goto IL_2944;
				case 202:
					array2[6] = (byte)num7;
					num2 = 189;
					continue;
				case 389:
					array2[8] = 1;
					num = 186;
					goto IL_2948_2;
				case 285:
					array[6] = (byte)num4;
					num = 390;
					goto IL_2948_2;
				case 117:
					array2[10] = 58;
					num6 = 141;
					goto IL_2944;
				case 111:
					num4 = 214 - 97;
					num = 207;
					goto IL_2948_2;
				case 183:
					array2[15] = (byte)num7;
					num6 = 257;
					goto IL_2944;
				case 428:
					array2[4] = 188;
					num = 119;
					goto IL_2948_2;
				case 343:
					array[29] = (byte)num4;
					num6 = 385;
					goto IL_2944;
				case 155:
					num4 = 26 + 91;
					num = 146;
					goto IL_2948_2;
				case 156:
					array[8] = 31;
					num = 375;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 123;
				case 123:
				case 143:
					if (num5 >= num12)
					{
						num2 = 195;
						continue;
					}
					if (num5 > 0)
					{
						num = 46;
						goto IL_2948_2;
					}
					goto case 7;
				case 163:
					array[8] = (byte)num4;
					num = 255;
					goto IL_2948_2;
				case 147:
					array[17] = 98;
					num6 = 56;
					goto IL_2944;
				case 4:
					array2[4] = 231;
					num6 = 362;
					goto IL_2944;
				case 391:
					array2[11] = 98;
					num = 367;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 317;
				case 317:
					array[7] = 112;
					num = 356;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_1add: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 263;
				case 263:
					num7 = 71 + 64;
					num2 = 172;
					continue;
				case 429:
					array2[2] = (byte)num7;
					num = 15;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_1b17: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 56;
				case 56:
					num4 = 87 + 13;
					goto case 90;
				case 253:
					array6[num10 + 2] = (byte)((num34 & 0xFF0000) >> 16);
					num2 = 271;
					continue;
				case 345:
					num33++;
					num = 314;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 267;
				case 267:
					array2[7] = (byte)num7;
					num6 = 53;
					goto IL_2944;
				case 112:
					array2[10] = 223;
					num6 = 391;
					goto IL_2944;
				case 388:
					array[30] = (byte)num4;
					num = 114;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 232;
				case 232:
					num4 = 26 + 53;
					num = 359;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 307;
				case 307:
					array[2] = 116;
					num2 = 31;
					continue;
				case 327:
					num32 = 0;
					num = 151;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 262;
				case 262:
					num4 = 104 + 111;
					num = 74;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_1c31: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 244;
				case 244:
					array[31] = 70;
					num = 177;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_1c59: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 297;
				case 231:
				case 259:
					num17 = num13;
					num2 = 214;
					continue;
				case 386:
					array[11] = 86;
					num = 9;
					goto IL_2948_2;
				case 360:
					array[27] = 135;
					num = 102;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_1cb7: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 287;
				case 247:
					num13 = num17;
					num6 = 423;
					goto IL_2944;
				case 286:
					if (num12 <= 0)
					{
						goto IL_0067;
					}
					num6 = 45;
					goto IL_2944;
				case 331:
					num7 = 203 - 124;
					num = 295;
					goto IL_2948_2;
				case 67:
					num4 = 223 - 74;
					num6 = 55;
					goto IL_2944;
				case 351:
					array2[10] = 92;
					num = 5;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 241;
				case 241:
					num4 = 96 + 65;
					num2 = 178;
					continue;
				case 354:
					array[0] = 209;
					_ = 1;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_1d6f: Stack underflow*/ != 0)
					{
						num = 90;
						goto IL_2948_2;
					}
					num6 = 421;
					goto IL_2944;
				case 186:
					num7 = 226 - 75;
					num2 = 11;
					continue;
				case 365:
					num7 = 108 + 66;
					num = 234;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_1db5: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 283;
				case 283:
					array3 = array2;
					num = 158;
					goto IL_2948_2;
				case 258:
					new CryptoStream(memoryStream, transform, CryptoStreamMode.Write);
					cryptoStream = (CryptoStream)/*Error near IL_1dd5: Stack underflow*/;
					num2 = 10;
					continue;
				case 370:
					num4 = 87 + 101;
					num = 388;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_1e01: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 149;
				case 199:
					array3[15] = array4[7];
					num6 = 327;
					goto IL_2944;
				case 264:
					array = new byte[32];
					num = 155;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_1e3a: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 240;
				case 376:
					array[17] = 153;
					num2 = 326;
					continue;
				case 86:
					num4 = 202 - 67;
					num2 = 63;
					continue;
				case 387:
					num4 = 35 + 33;
					num = 339;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 272;
				case 272:
					array2[5] = 116;
					num2 = 398;
					continue;
				case 34:
					num4 = 126 - 56;
					num = 266;
					goto IL_2948_2;
				case 255:
					array[8] = 121;
					num2 = 40;
					continue;
				case 108:
					array2[13] = 132;
					num2 = 213;
					continue;
				case 192:
					array2[15] = 108;
					num2 = 107;
					continue;
				case 375:
					num4 = 192 - 64;
					num6 = 163;
					goto IL_2944;
				case 148:
					if (num12 > 0)
					{
						num = 175;
						dUBVH0mxoHZWLYi54O();
						if ((int)/*Error near IL_1f62: Stack underflow*/ == 0)
						{
							goto IL_2948_2;
						}
						goto case 21;
					}
					goto case 341;
				case 21:
					num4 = 190 + 53;
					num = 238;
					goto IL_2948_2;
				case 410:
					num4 = 128 + 71;
					num2 = 24;
					continue;
				case 119:
					array2[4] = 120;
					num = 124;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_1fc0: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 64;
				case 222:
					r3q3S53eOrh7l8TyeD(binaryReader);
					num6 = 264;
					goto IL_2944;
				case 242:
					array[3] = 148;
					num6 = 75;
					goto IL_2944;
				case 77:
					num4 = 250 - 83;
					num6 = 420;
					goto IL_2944;
				case 291:
					array[1] = 110;
					num2 = 126;
					continue;
				case 51:
					array2[11] = (byte)num7;
					num = 95;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_204e: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 355;
				case 355:
					num4 = 156 - 52;
					num = 187;
					goto IL_2948_2;
				case 223:
					array2[12] = (byte)num7;
					num = 82;
					goto IL_2948_2;
				case 270:
					array2[14] = 150;
					num = 136;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_20af: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 250;
				case 382:
					if (array4.Length <= 0)
					{
						goto case 327;
					}
					num6 = 81;
					goto IL_2944;
				case 182:
					array[22] = (byte)num4;
					num2 = 77;
					continue;
				case 31:
					num4 = 106 + 19;
					num6 = 403;
					goto IL_2944;
				case 0:
					array[21] = 146;
					num = 344;
					goto IL_2948_2;
				case 35:
					num7 = 31 + 121;
					num2 = 427;
					continue;
				case 107:
					num7 = 1 + 81;
					num6 = 183;
					goto IL_2944;
				case 292:
					array2[9] = 105;
					num2 = 196;
					continue;
				case 124:
					num7 = 160 - 53;
					num = 87;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 133;
				case 133:
					num7 = 106 + 19;
					num2 = 429;
					continue;
				case 269:
					array2[11] = 84;
					num2 = 215;
					continue;
				case 5:
					array2[10] = 162;
					num2 = 229;
					continue;
				case 296:
					array2[8] = (byte)num7;
					num = 346;
					goto IL_2948_2;
				case 169:
					num4 = 142 - 76;
					num = 197;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 70;
				case 70:
					num14 = (uint)((array5[num31 + 3] << 24) | (array5[num31 + 2] << 16) | (array5[num31 + 1] << 8) | array5[num31]);
					num6 = 259;
					goto IL_2944;
				case 40:
					num4 = 199 - 66;
					num6 = 363;
					goto IL_2944;
				case 88:
					array2[8] = 98;
					num = 6;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_2292: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 320;
				case 320:
					num4 = 118 + 63;
					num6 = 312;
					goto IL_2944;
				case 136:
					array2[14] = 135;
					num = 380;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_22d3: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 68;
				case 94:
				{
					uint num18 = num17;
					uint num19 = num17;
					uint num20 = 189040444u;
					uint num21 = 1281464036u;
					uint num22 = 1050350262u;
					uint num23 = num19;
					uint num24 = 2011369730u;
					uint num25 = 664971646u;
					num20 = num24 ^ (num21 - 511142071);
					if ((double)num22 == 0.0)
					{
						num22--;
					}
					uint num26 = (uint)(934325112.0 / (double)num22 + (double)num22);
					num22 = (uint)((int)((long)num21 - 22305L) + (int)num26) + num21;
					uint num27 = num21 & 0xF0F0F0Fu;
					uint num28 = num21 & 0xF0F0F0F0u;
					num27 = ((num27 >> 4) | (num28 << 4)) ^ num20;
					num21 = (num21 >> 12) | (num21 << 20);
					ulong num29 = 18446744073671565251uL;
					if (num29 == 0)
					{
						num29--;
					}
					num24 = (uint)(num24 * num24 % num29);
					num25 += num20;
					num23 ^= num23 >> 11;
					num23 += num21;
					num23 ^= num23 >> 16;
					num23 += num24;
					num23 ^= num23 << 7;
					num23 += num25;
					num23 = (((num22 << 8) + num22) ^ num21) - num23;
					num17 = num18 + (uint)(double)num23;
					num2 = 247;
					continue;
				}
				case 173:
					num4 = 112 + 9;
					num6 = 38;
					goto IL_2944;
				case 352:
					num7 = 93 + 47;
					num6 = 113;
					goto IL_2944;
				case 225:
					array[28] = (byte)num4;
					num = 176;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 122;
				case 122:
					num4 = 228 - 76;
					num6 = 198;
					goto IL_2944;
				case 302:
					num4 = 8 + 26;
					num6 = 426;
					goto IL_2944;
				case 214:
					num13 = 0u;
					num6 = 94;
					goto IL_2944;
				case 189:
					num7 = 215 - 71;
					num2 = 25;
					continue;
				case 261:
					array2[12] = 145;
					num6 = 153;
					goto IL_2944;
				case 140:
					array[19] = 130;
					num2 = 173;
					continue;
				case 24:
					array[13] = (byte)num4;
					num = 302;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_2584: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 16;
				case 16:
					array[12] = 91;
					num2 = 3;
					continue;
				case 89:
					array[23] = 178;
					num6 = 311;
					goto IL_2944;
				case 319:
					array[26] = (byte)num4;
					num = 414;
					goto IL_2948_2;
				case 127:
					array[0] = (byte)num4;
					num = 167;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 153;
				case 153:
					array2[12] = 147;
					num2 = 78;
					continue;
				case 301:
					array[17] = 208;
					num = 376;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_2662: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 206;
				case 206:
					num4 = 113 + 46;
					num = 79;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_2684: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 243;
				case 243:
					array[4] = 178;
					num = 174;
					goto IL_2948_2;
				case 413:
					num4 = 221 - 73;
					num = 304;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_26c9: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 358;
				case 358:
					if (array4 == null)
					{
						goto case 327;
					}
					num = 382;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_26e3: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 347;
				case 347:
					if (num9 == num16 - 1)
					{
						num = 193;
						dUBVH0mxoHZWLYi54O();
						if ((int)/*Error near IL_2701: Stack underflow*/ == 0)
						{
							goto IL_2948_2;
						}
						goto case 350;
					}
					goto IL_3215;
				case 318:
					array[2] = 118;
					num = 242;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 125;
				case 125:
					num4 = 109 + 9;
					num6 = 127;
					goto IL_2944;
				case 334:
					array2[1] = 128;
					num2 = 401;
					continue;
				case 45:
					num15 = num13 ^ num14;
					num2 = 361;
					continue;
				case 106:
					array[12] = (byte)num4;
					num6 = 22;
					goto IL_2944;
				case 96:
					num7 = 69 + 69;
					num = 273;
					goto IL_2948_2;
				case 104:
					num4 = 219 - 73;
					num2 = 29;
					continue;
				case 363:
					array[8] = (byte)num4;
					num6 = 233;
					goto IL_2944;
				case 166:
					num7 = 227 - 75;
					num6 = 267;
					goto IL_2944;
				case 362:
					num7 = 50 + 84;
					num6 = 64;
					goto IL_2944;
				case 393:
					num4 = 141 - 47;
					num = 61;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_282d: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 315;
				case 315:
					array[24] = 102;
					num = 104;
					goto IL_2948_2;
				case 341:
					num31 = 0u;
					num = 422;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 69;
				case 69:
					num4 = 71 + 40;
					num = 14;
					goto IL_2948_2;
				case 332:
					array2[14] = 108;
					num6 = 270;
					goto IL_2944;
				case 200:
					array[13] = (byte)num4;
					num2 = 410;
					continue;
				case 98:
					array[20] = 104;
					num = 0;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_28de: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 402;
				case 256:
					array[12] = 154;
					num = 353;
					goto IL_2948_2;
				case 275:
					array2[7] = 65;
					num6 = 166;
					goto IL_2944;
				case 385:
					array[30] = 87;
					goto case 122;
				default:
					num2 = 122;
					continue;
				case 144:
					array[29] = (byte)num4;
					num2 = 413;
					continue;
				case 398:
					array2[5] = 1;
					num6 = 364;
					goto IL_2944;
				case 288:
					num7 = 5 + 120;
					num2 = 47;
					continue;
				case 151:
				case 430:
					goto IL_306b;
				case 367:
					num7 = 200 - 66;
					num = 249;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_30a2: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 36;
				case 121:
					num4 = 25 + 111;
					num = 289;
					goto IL_2948_2;
				case 313:
					array2[13] = (byte)num7;
					num = 108;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 381;
				case 381:
					array[28] = (byte)num4;
					num2 = 71;
					continue;
				case 227:
					num7 = 9 + 60;
					num2 = 309;
					continue;
				case 126:
					array[1] = 133;
					num6 = 260;
					goto IL_2944;
				case 279:
					array[1] = 147;
					num2 = 307;
					continue;
				case 179:
					num11 = 255u;
					num = 246;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_316a: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 91;
				case 91:
					array2[7] = (byte)num7;
					num = 275;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_318b: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 377;
				case 29:
					array[24] = (byte)num4;
					num2 = 134;
					continue;
				case 65:
					jpQNi5tC4c1ld9V30U(ihYViEaOJ, _0020);
					num3 = (int)/*Error near IL_31d0: Stack underflow*/;
					num6 = 431;
					goto IL_2944;
				case 415:
					array[3] = (byte)num4;
					num = 169;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 368;
				case 368:
					num4 = 94 + 51;
					num6 = 323;
					goto IL_2944;
				case 348:
					array[16] = 39;
					num6 = 34;
					goto IL_2944;
				case 92:
					num5++;
					num = 143;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 290;
				case 290:
					array6 = new byte[array5.Length];
					num2 = 371;
					continue;
				case 167:
					num4 = 13 + 66;
					num6 = 23;
					goto IL_2944;
				case 406:
					array[13] = 124;
					num = 37;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 109;
				case 109:
					array[17] = (byte)num4;
					num2 = 254;
					continue;
				case 293:
					num4 = 52 + 90;
					num = 188;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_32e6: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 204;
				case 193:
					if (num12 > 0)
					{
						num6 = 84;
						goto IL_2944;
					}
					goto IL_3215;
				case 26:
					array2[5] = (byte)num7;
					num = 116;
					goto IL_2948_2;
				case 335:
					array[18] = (byte)num4;
					num2 = 184;
					continue;
				case 333:
					num4 = 207 - 69;
					num = 404;
					goto IL_2948_2;
				case 309:
					array2[0] = (byte)num7;
					num = 365;
					goto IL_2948_2;
				case 132:
					array[18] = 234;
					num2 = 374;
					continue;
				case 75:
					num4 = 208 - 69;
					num6 = 20;
					goto IL_2944;
				case 384:
					array2[0] = 136;
					num = 227;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 131;
				case 131:
					array2[2] = (byte)num7;
					num6 = 30;
					goto IL_2944;
				case 46:
					num11 <<= 8;
					num6 = 58;
					goto IL_2944;
				case 209:
					num4 = 159 - 53;
					num2 = 225;
					continue;
				case 392:
					num4 = 224 - 74;
					num2 = 379;
					continue;
				case 110:
					array[19] = 77;
					num = 140;
					if (true)
					{
						goto IL_2948_2;
					}
					goto case 422;
				case 422:
					num9 = 0;
					num = 44;
					goto IL_2948_2;
				case 420:
					array[22] = (byte)num4;
					num = 220;
					goto IL_2948_2;
				case 278:
					array[12] = (byte)num4;
					num = 256;
					goto IL_2948_2;
				case 249:
					array2[11] = (byte)num7;
					num = 181;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 168;
				case 168:
					num4 = 250 - 83;
					num = 159;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_34cc: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 149;
				case 6:
					num7 = 224 - 74;
					num6 = 296;
					goto IL_2944;
				case 401:
					num7 = 197 - 65;
					num2 = 60;
					continue;
				case 2:
					array2[11] = (byte)num7;
					num2 = 416;
					continue;
				case 303:
					array[27] = 73;
					num6 = 228;
					goto IL_2944;
				case 412:
					num10 = num9 * 4;
					num = 54;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_3553: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 196;
				case 78:
					array2[12] = 166;
					num = 409;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 157;
				case 157:
					array[11] = 232;
					num6 = 16;
					goto IL_2944;
				case 99:
					array2[10] = (byte)num7;
					num = 112;
					dUBVH0mxoHZWLYi54O();
					if ((int)/*Error near IL_35bc: Stack underflow*/ == 0)
					{
						goto IL_2948_2;
					}
					goto case 61;
				case 61:
					array[16] = (byte)num4;
					num = 348;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 229;
				case 229:
					num7 = 181 - 60;
					num2 = 99;
					continue;
				case 11:
					array2[9] = (byte)num7;
					num6 = 35;
					goto IL_2944;
				case 353:
					num4 = 179 - 85;
					num6 = 106;
					goto IL_2944;
				case 306:
					array3[13] = array4[6];
					num6 = 199;
					goto IL_2944;
				case 1:
					akgGF2Ogev68VSRsIK(Y5vLjSC9M, "OA08DgR6FCg4d9T9fe.Uy2umUGGvicO0DvncQ");
					new BinaryReader((Stream)/*Error near IL_3aed: Stack underflow*/);
					binaryReader = (BinaryReader)/*Error near IL_364c: Stack underflow*/;
					num = 73;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_365f: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 352;
				case 33:
					num7 = 156 - 52;
					num6 = 28;
					goto IL_2944;
				case 237:
					array2[1] = 106;
					num = 352;
					jdT9K1aeNeX1SwHsZK();
					if ((int)/*Error near IL_36a5: Stack underflow*/ != 0)
					{
						goto IL_2948_2;
					}
					goto case 213;
				case 213:
					num7 = 26 + 66;
					num6 = 52;
					goto IL_2944;
				case 424:
					num8 = 0u;
					num2 = 129;
					continue;
				case 419:
					vRGmjlBA8fSas2iAkN(memoryStream);
					ihYViEaOJ = (object)/*Error near IL_36d7: Stack underflow*/;
					num6 = 180;
					goto IL_2944;
				case 201:
					array[5] = 196;
					num = 392;
					goto IL_2948_2;
				case 194:
				case 314:
					if (num33 < num12)
					{
						if (num33 > 0)
						{
							num = 400;
							jdT9K1aeNeX1SwHsZK();
							if ((int)/*Error near IL_263a: Stack underflow*/ != 0)
							{
								goto IL_2948_2;
							}
							goto case 301;
						}
						goto case 128;
					}
					num2 = 231;
					continue;
				case 49:
					array2[2] = (byte)num7;
					num6 = 62;
					goto IL_2944;
				case 265:
					array[4] = (byte)num4;
					num6 = 67;
					goto IL_2944;
				case 135:
					array[27] = (byte)num4;
					num2 = 303;
					continue;
				case 128:
					num14 |= array5[array5.Length - (1 + num33)];
					num = 345;
					goto IL_2948_2;
				case 361:
					num5 = 0;
					num = 123;
					goto IL_2948_2;
				case 431:
					try
					{
						oQdWPulKxWAlB0Hgjg();
						object obj = ihYViEaOJ;
						vqyisyWVA0Hsl6LlU3((object)/*Error near IL_37b7: Stack underflow*/, obj, _0020 + 4, num3);
						return (string)/*Error near IL_37c6: Stack underflow*/;
					}
					catch
					{
					}
					return "";
				case 407:
					new MemoryStream();
					memoryStream = (MemoryStream)/*Error near IL_0ebb: Stack underflow*/;
					num = 258;
					if (0 == 0)
					{
						goto IL_2948_2;
					}
					goto case 228;
				case 282:
					{
						BLCAUNib7BYlDO8eSw();
						symmetricAlgorithm = (SymmetricAlgorithm)/*Error near IL_148a: Stack underflow*/;
						num = 297;
						if (0 == 0)
						{
							goto IL_2948_2;
						}
						goto case 41;
					}
					IL_3215:
					num13 += num8;
					num2 = 185;
					continue;
					IL_0067:
					num34 = num13 ^ num14;
					num6 = 342;
					goto IL_2944;
					IL_2944:
					num = num6;
					goto IL_2948_2;
				}
				break;
				IL_306b:
				if (num32 < array3.Length)
				{
					array7[num32] = (byte)(array7[num32] ^ array3[num32]);
					num2 = 418;
				}
				else
				{
					num2 = 12;
				}
				continue;
				IL_0045:
				num4 = 13 + 56;
				num = 72;
				goto IL_2948_2;
			}
			break;
		}
		goto IL_0013;
		IL_0013:
		array2[4] = (byte)num7;
		num = 4;
		if (false)
		{
			goto IL_0030;
		}
		goto IL_2948;
		IL_0030:
		MYUlDwsCB7bKYCLIvt(memoryStream);
		num = 149;
		goto IL_2948;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	[f6km2k1IS01nF4ccyi(typeof(f6km2k1IS01nF4ccyi.QfjfwyifZ5DYgArOj1<object>[]))]
	internal static string lQQy0fMUY(object _0020)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		"{11111-22222-50001-00000}".Trim();
		byte[] array = Convert.FromBase64String((string)_0020);
		return Encoding.Unicode.GetString(array, 0, array.Length);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static int CpEwGu4ow()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return 5;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static void K7uZYMiUI()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		try
		{
			RSACryptoServiceProvider.UseMachineKeyStore = true;
		}
		catch
		{
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static Delegate eFljS3M5S(IntPtr _0020, Type _0020)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return (Delegate)typeof(Marshal).GetMethod("GetDelegateForFunctionPointer", new Type[2]
		{
			typeof(IntPtr),
			typeof(Type)
		}).Invoke(null, new object[2] { _0020, _0020 });
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object UuCSV1lmB(object _0020)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		try
		{
			if (File.Exists(((Assembly)_0020).Location))
			{
				return ((Assembly)_0020).Location;
			}
		}
		catch
		{
		}
		try
		{
			if (File.Exists(((Assembly)_0020).GetName().CodeBase.ToString().Replace("file:///", "")))
			{
				return ((Assembly)_0020).GetName().CodeBase.ToString().Replace("file:///", "");
			}
		}
		catch
		{
		}
		try
		{
			if (File.Exists(_0020.GetType().GetProperty("Location").GetValue(_0020, new object[0])
				.ToString()))
			{
				return _0020.GetType().GetProperty("Location").GetValue(_0020, new object[0])
					.ToString();
			}
		}
		catch
		{
		}
		return "";
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	[f6km2k1IS01nF4ccyi(typeof(f6km2k1IS01nF4ccyi.QfjfwyifZ5DYgArOj1<object>[]))]
	private static byte[] epbK8VO4X(object _0020)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		using FileStream fileStream = new FileStream((string)_0020, FileMode.Open, FileAccess.Read, FileShare.Read);
		int num = 0;
		long length = fileStream.Length;
		int num2 = (int)length;
		byte[] array = new byte[num2];
		while (num2 > 0)
		{
			int num3 = fileStream.Read(array, num, num2);
			num += num3;
			num2 -= num3;
		}
		return array;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	[f6km2k1IS01nF4ccyi(typeof(f6km2k1IS01nF4ccyi.QfjfwyifZ5DYgArOj1<object>[]))]
	private static byte[] FMIh1CFFe(object _0020)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		MemoryStream memoryStream = new MemoryStream();
		SymmetricAlgorithm symmetricAlgorithm = ngH331H9J();
		symmetricAlgorithm.Key = new byte[32]
		{
			51, 93, 50, 48, 107, 122, 41, 170, 124, 106,
			101, 88, 44, 157, 30, 71, 138, 8, 111, 162,
			214, 39, 202, 59, 172, 58, 133, 161, 190, 250,
			77, 93
		};
		symmetricAlgorithm.IV = new byte[16]
		{
			251, 224, 179, 57, 209, 89, 92, 248, 242, 129,
			73, 6, 7, 208, 162, 244
		};
		CryptoStream cryptoStream = new CryptoStream(memoryStream, symmetricAlgorithm.CreateDecryptor(), CryptoStreamMode.Write);
		cryptoStream.Write((byte[])_0020, 0, ((Array)_0020).Length);
		cryptoStream.Close();
		return memoryStream.ToArray();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private byte[] hrBD59xUs()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return null;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private byte[] qVJG0lf0b()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return null;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private byte[] xwgfCAywy()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		string text = "{11111-22222-20001-00001}";
		if (text.Length > 0)
		{
			return new byte[2] { 1, 2 };
		}
		return new byte[2] { 1, 2 };
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private byte[] SnO66H2jZ()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		string text = "{11111-22222-20001-00002}";
		if (text.Length > 0)
		{
			return new byte[2] { 1, 2 };
		}
		return new byte[2] { 1, 2 };
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private byte[] HJFQOsFhx()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		string text = "{11111-22222-30001-00001}";
		if (text.Length > 0)
		{
			return new byte[2] { 1, 2 };
		}
		return new byte[2] { 1, 2 };
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private byte[] m1FoJSOuQ()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		string text = "{11111-22222-30001-00002}";
		if (text.Length > 0)
		{
			return new byte[2] { 1, 2 };
		}
		return new byte[2] { 1, 2 };
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal byte[] MlabhmsOY()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		string text = "{11111-22222-40001-00001}";
		if (text.Length > 0)
		{
			return new byte[2] { 1, 2 };
		}
		return new byte[2] { 1, 2 };
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal byte[] jfP7EfarJ()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		string text = "{11111-22222-40001-00002}";
		if (text.Length > 0)
		{
			return new byte[2] { 1, 2 };
		}
		return new byte[2] { 1, 2 };
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal byte[] kCxNIKybw()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		string text = "{11111-22222-50001-00001}";
		if (text.Length > 0)
		{
			return new byte[2] { 1, 2 };
		}
		return new byte[2] { 1, 2 };
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal byte[] IcA8bXK10()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		string text = "{11111-22222-50001-00002}";
		if (text.Length > 0)
		{
			return new byte[2] { 1, 2 };
		}
		return new byte[2] { 1, 2 };
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public ajPWp7JpCnYwAxGgPj()
	{
	}//Discarded unreachable code: IL_0002, IL_0006
	//IL_0003: Incompatible stack heights: 0 vs 1
	//IL_0007: Incompatible stack heights: 0 vs 1


	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object akgGF2Ogev68VSRsIK(object P_0, object P_1)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return ((Assembly)P_0).GetManifestResourceStream((string)P_1);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object S9XIwC8X4Cfadjpcgt(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return ((BinaryReader)P_0).BaseStream;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void rDXNr7H0Ej0c6PK0am(object P_0, long P_1)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		((Stream)P_0).Position = P_1;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static long aLTNtNGdf1ODJWEbKP(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return ((Stream)P_0).Length;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object e5sTbB4JOgx53F2eiG(object P_0, int P_1)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return ((BinaryReader)P_0).ReadBytes(P_1);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void r3q3S53eOrh7l8TyeD(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		((BinaryReader)P_0).Close();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void TbXCclALQR6ZN4cwvK(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		Array.Reverse((Array)P_0);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object KOrJp8DZjogHAAy4du(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return ((Assembly)P_0).GetName();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object N9giqV6ZRD5gyYRqyE(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return ((AssemblyName)P_0).GetPublicKeyToken();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object BLCAUNib7BYlDO8eSw()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return ngH331H9J();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void WbXiklFKlAFcbLag47(object P_0, CipherMode P_1)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		((SymmetricAlgorithm)P_0).Mode = P_1;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object a8sSenh1KZI5SZ3iaC(object P_0, object P_1, object P_2)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return ((SymmetricAlgorithm)P_0).CreateDecryptor((byte[])P_1, (byte[])P_2);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void YucSGKpr1AbaXAWZQu(object P_0, object P_1, int P_2, int P_3)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		((Stream)P_0).Write((byte[])P_1, P_2, P_3);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void uyothYMrOoaG7SRlg9(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		((CryptoStream)P_0).FlushFinalBlock();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object vRGmjlBA8fSas2iAkN(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return ((MemoryStream)P_0).ToArray();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void MYUlDwsCB7bKYCLIvt(object P_0)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		((Stream)P_0).Close();
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static int jpQNi5tC4c1ld9V30U(object P_0, int P_1)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return BitConverter.ToInt32((byte[])P_0, P_1);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object oQdWPulKxWAlB0Hgjg()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return Encoding.Unicode;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static object vqyisyWVA0Hsl6LlU3(object P_0, object P_1, int P_2, int P_3)
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return ((Encoding)P_0).GetString((byte[])P_1, P_2, P_3);
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static bool jdT9K1aeNeX1SwHsZK()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return true;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static bool dUBVH0mxoHZWLYi54O()
	{
		//Discarded unreachable code: IL_0002
		//IL_0003: Incompatible stack heights: 0 vs 1
		return false;
	}
}
