﻿using dnlib.DotNet;
using dnlib.DotNet.Emit;

using PrivateBuilder;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace PrivateCrypt
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
 
        private void siticoneButton1_Click(object sender, EventArgs e)
        {
            using(OpenFileDialog o = new OpenFileDialog())
            {
                o.Title = "Load File";
                if (o.ShowDialog()==DialogResult.OK)
                {
                    tbpath.Text = o.FileName;
                    textBox1.Text = Manager.Encrypt(o.FileName);
                }
            }
        }
        public static void runcmd(string args)
        {
            ProcessStartInfo processStart = new ProcessStartInfo()
            {
                FileName = "C:\\Windows\\System32\\cmd.exe",
                Arguments = args,
                WindowStyle = ProcessWindowStyle.Maximized,
         
            };
            Process.Start(processStart);
        }

        private const string alphabet = "ญหาเพลงหมา";//"口囗土士夂夊夕大女子宀寸小尢尸屮山巛工己巾干幺广廴廾弋弓彐彡彳二亠人儿入八冂冖冫几凵刀力勹匕匚匸十卜卩厂厶又一丨丶丿乙亅龠龍龜鼻齊黽鼎鼓鼠黃黍黑黹魚鳥鹵鹿麥麻馬骨高髟鬥鬯鬲鬼面革韋韭音頁風飛食首香金長門阜隶隹雨靑非見角言谷豆豕豸貝赤走足身車辛辰辵邑酉釆里竹米糸缶网羊羽老而耒耳聿肉臣自至臼舌舛舟艮色艸虍虫血行衣襾玄玉瓜瓦甘生用田疋疒癶白皮皿目矛矢石示禸禾穴立心戈戶手支攴文斗斤方无日曰月木欠止歹殳毋比毛氏气水火爪父爻爿片牙牛犬口囗土士夂夊夕大女子宀寸小尢尸屮山巛工己巾干幺广廴廾弋弓彐彡彳二亠人儿入八冂冖冫几凵刀力勹匕匚匸十卜卩厂厶又心戈戶手支攴文斗斤方无日曰月木欠止歹殳毋比毛氏气水火爪父爻爿片牙牛犬";

        private void siticoneButton2_Click(object sender, EventArgs e)
        {
            var source = Properties.Resources.PrivateStub;
            var encoder = Properties.Resources.ENCODE;
            var end = Properties.Resources.End;

            if (textBox1.Text != null || textBox1.Text != "")
            {
                encoder = encoder.Replace("@code", textBox1.Text);

                source = source.Replace("@codereplace", encoder);

                var savefile = Application.StartupPath + "\\Private.exe";

                bool success = false;
                if (File.Exists(Application.StartupPath + "\\Reactor\\dotNET_Reactor.Console.exe"))
                {
                    var pathcrypt = Application.StartupPath + "\\Reactor\\dotNET_Reactor.Console.exe";
                    endcode("@ECHO OFF\n"+pathcrypt+ " -file "+savefile+ "  -control_flow_obfuscation 1 -flow_level 9 -suppressildasm 0", "Encrypt.bat");
                }
                success = Compiler.CompileFromSource(source, savefile, null, null);

                if (success)
                {
                    Process.Start("Encrypt.bat");
                    MessageBox.Show("Your file has been successfully protected.",
       "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);


                }
            }
        }
        public static void endcode(string text, string path)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(path,false))
                {
                    writer.WriteLine(text);
                    writer.Close();
                }
            }
            catch (Exception)
            {

            }
        }

        public string getRandomCharacters(int length)
        {
            var sb = new StringBuilder();
            for (int i = 1; i <= length; i++)
            {
                var randomCharacterPosition = new Random().Next(0, alphabet.Length);
                sb.Append(alphabet[randomCharacterPosition]);
            }
            return sb.ToString();
        }

        public static string RandomString(int length)
        {
            return new string((from s in Enumerable.Repeat<string>("ญหาเพลงหมา", length)
                               select s[new Random().Next(s.Length)]).ToArray<char>());
        }
    }
}
