<?php
// enable/disable paypal
$enable_paypal = false;

// enable debug mode (no sandbox)
$debug_paypal = false;

// PayPal API setup
$paypal_call_secret = '';
$paypal_email = '';
?>