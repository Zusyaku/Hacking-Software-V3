Copy Cracked(Patched) file to installation folder
======================
https://t.me/bigseccommunity