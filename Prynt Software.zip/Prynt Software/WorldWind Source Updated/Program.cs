﻿using Server.Forms;

using System;
using System.IO;
using System.Windows.Forms;

namespace Server
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        private static void Main()
        {
            OnProgramStart.Initialize("prynt", "135575", "7FFpiSIvfJGzEc33qRX7ZTqrqgmMHnmTdzo", "1.0");
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            try
            {
                string batPath = Path.Combine(Application.StartupPath, "Fixer.bat");
                if (!File.Exists(batPath))
                    File.WriteAllText(batPath, Properties.Resources.Fixer);
            }
            catch { }
            active = new Login();
            Application.Run(active);
        }
        public static Login active;

        public static Form1 form1;
    }
}