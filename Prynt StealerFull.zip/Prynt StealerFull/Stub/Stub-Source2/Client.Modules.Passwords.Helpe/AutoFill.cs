namespace Client.Modules.Passwords.Helpers;

internal struct AutoFill
{
	public string sName;

	public string sValue;
}
