﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Macro_Example;
namespace Macro
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            OnProgramStart.Initialize("xlsmacro", "135575", "O5wq8yqmgLI7eqy48OoRscO5b6sGiuo1oXY", "1.0");
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form2());
        }
    }
}
