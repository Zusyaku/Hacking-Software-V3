﻿using dnlib.DotNet;

namespace ModernGUI_V3.RenamingObfuscation.Interfaces
{
    public interface IRenaming
   {
        ModuleDefMD Rename(ModuleDefMD module);
    }
}
