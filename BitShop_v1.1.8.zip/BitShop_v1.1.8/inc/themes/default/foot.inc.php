<hr />
<footer>
  <div class="row-fluid">
    <div class="span12">
      <div class="float_right">
	    <?php echo LANG('POWERED_BY'); ?> 
	    <a href="http://bitfreak.info/bitshop/"><?php echo LANG('BITSHOP'); ?></a>
	  </div>
      <div class="float_left">&copy; <?php safe_echo(date("Y")." $seller"); ?></div>
    </div>
  </div>
</footer>