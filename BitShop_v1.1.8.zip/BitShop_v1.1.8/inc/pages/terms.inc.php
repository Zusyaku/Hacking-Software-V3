<h1><?php echo LANG('TERMS_TITLE'); ?></h1>

<p><?php echo LANG('TEXT_HERE', 3, ' '); ?></p>