namespace Server;

public static class XmrSettings
{
	public static string Pool = "";

	public static string Wallet = "";

	public static string Pass = "";

	public static string InjectTo = "";

	public static string Hash = "";
}
