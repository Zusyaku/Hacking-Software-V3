using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyTitle("Prynt Convert")]
[assembly: AssemblyDescription("Change File Extention")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("http://t.me/PryntDotMarket")]
[assembly: AssemblyProduct("Prynt Convert")]
[assembly: AssemblyCopyright("Copyright © Prynt Software 2021")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("a4fc244c-69e2-41b6-b33b-7f06f0e00701")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
