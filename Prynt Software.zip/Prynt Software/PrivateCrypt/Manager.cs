﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrivateCrypt
{
    public static class Manager
    {
        public static string Encrypt(string path)
        {
            byte[] array = File.ReadAllBytes(path);
            StringBuilder stringBuilder = new StringBuilder();
            byte[] array2 = array;
            for (int i = 0; i < array2.Length; i++)
            {
                byte b = array2[i];
                stringBuilder.Append(b.ToString() + " ");
            }
 
            return stringBuilder.ToString().Remove(stringBuilder.ToString().Length - 1);
        }
    }
}
