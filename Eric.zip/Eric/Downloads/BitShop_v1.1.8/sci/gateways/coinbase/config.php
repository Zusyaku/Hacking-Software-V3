<?php
// enable/disable coinbase
$enable_coinbase = false;

// enable debug mode
$debug_coinbase = false;

// Coinbase API setup
$coinbase_api_key = '';
$coinbase_api_secret = '';
$coinbase_call_secret = '';
?>