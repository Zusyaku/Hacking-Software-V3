<p align="center"> 

![applehat](https://i.imgur.com/FrTqRpq.png)
</p>

# Required :leftwards_arrow_with_hook:	
:heavy_plus_sign:	 Required = **Python 3.9+** 
- :heavy_plus_sign:	 Library = fake_useragent, url_parser, requests, colorama
# APPLE HAT VALID EMAIL CHECKER :arrow_left:	
- :eight_spoked_asterisk:		 Usage : **python main.py**
- :eight_spoked_asterisk:		 Option1 = **listname.txt**
- :eight_spoked_asterisk:		 Option2 = **proxylist.txt**
# Saved Rzlt :leftwards_arrow_with_hook:
- :eight_spoked_asterisk:	 always in **/rzlt** file 
- :eight_spoked_asterisk:	 Configuration in **/inc/api.py**
# Contact Me :leftwards_arrow_with_hook:	
> [Telegram](https://t.me/DsWeb19778)
# Version 8.0 - Whats new? :leftwards_arrow_with_hook:	
- :eight_spoked_asterisk:	 Add Threads x10 faster
- :eight_spoked_asterisk:	 Add counter to delay the request for unlimited checking
- :eight_spoked_asterisk:	 Add Proxy. Only Frech 
- :eight_spoked_asterisk:	 Add Timeout Emails [NOT CHECKED]
- :eight_spoked_asterisk:	 Fixing Bugs !!NEW :fire:	 
- :eight_spoked_asterisk:	 Update !!NEW :fire:	 
# Donate :leftwards_arrow_with_hook:	
> Me : **[Paypal.me](https://paypal.me/wecandoittogheter)**

