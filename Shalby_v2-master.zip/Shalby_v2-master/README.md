
# Shalby V2

```bash

$ python 3.x

$ python main.py

```

### Don't forget install

```bash

$ pip install requests

$ pip install colorama

```
# How to use
 - Run Script
 - Select Tool Number
 - And Enjoy !


![](./img.png)


# What's New
- Tools Updated
- speed up
- Bug fixes
### More Tools In My Facebook
Link : https://www.facebook.com/Amr.v7
